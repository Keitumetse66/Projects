
# def brush_teeth():
#     print("open tap")
#     print("brush teeth")
#     print("close tap")

# def brush_hair():
#     print("brush hair")

# def wake_up():
#     print("get up")
#     print("make the bed")

# def switch_off_alarm(): 
#     print("stop alarm")

# def snooze_alarm():
#     print("snooze alarm")


# def get_dressed():
#     print("open the cupboard")
#     print("take out clothes")
#     print("put on clothes")
#     print("close cupboard")

# def make_breakfast():
#     print("fry eggs")
#     print("make toast")
#     print("butter the toast")
#     print("make coffee")

# def eat_breakfast():
#     print("eat eggs&toast")
#     print("drink coffee")
#     print("eat breakfast")

# def do_dishes():
#     print("wash plate")

# if __name__ == "__main__":
#     snooze_alarm()
#     switch_off_alarm()
#     wake_up()
#     brush_teeth()
#     get_dressed()
#     brush_hair()
#     make_breakfast()
#     eat_breakfast()
#     do_dishes()


def multiply(a,b):
    print(a +b)

add(5,7)