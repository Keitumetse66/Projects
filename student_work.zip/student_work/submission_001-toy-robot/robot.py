

# TODO: Decompose into functions

def move_left_turn_right(length, degrees):
    print("* Move Forward "+str(length))
    print("* Turn Right "+str(degrees)+" degrees")



def move_square(size=10):
    """
    Move the toy in a shape of a square with a size of 10
    """
    print("Moving in a square of size "+str(size))
    for i in range(4):
        degrees = 90
        move_left_turn_right(size, degrees)


def move_rectangle():
    """
    Move the toy in a shape of a rectangle with has a length of 20 and breadth of 10 
    """
    length = 20
    width = 10
    print("Moving in a rectangle of "+str(length)+" by "+str(width))
    for i in range(2):
        degrees = 90
        move_left_turn_right(length, degrees)
        move_left_turn_right(width, degrees)

       
def  move_circle():
    """
    Move the toy in a shape of a circle of 360 degrees for 360 times
    """ 
    print("Moving in a circle")
    degrees = 1
    for i in range(360):
        length = 1
        move_left_turn_right(length, degrees)



def square_dance():
    """
    Make the toy move in a around a square of length 20 3 times
    """
    print("Square dancing - 3 squares of size 20")
    for i in range(3):
        length = 20
        print("* Move Forward "+str(length))
        move_square(20)


def crop_circles():
    """
    Make the square rotate in a circle 1440 times   
    """
    length = 20
    print("Crop circles - 4 circles")
    for i in range(4):
        print("* Move Forward "+str(length))
        move_circle()

def move():
    move_square()
    move_rectangle()
    move_circle()
    square_dance()
    crop_circles()

def robot_start():
    move()


if __name__ == "__main__":
    robot_start()
