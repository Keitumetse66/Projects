import random


def random_four_digit_code():
    """
    Randomly selects 4 digits,
    adds them to a list and returns them  
    """
    code = [0,0,0,0]
    for i in range(4):
        value = random.randint(1, 8) # 8 possible digits
        while value in code:
            value = random.randint(1, 8)  # 8 possible digits
        code[i] = value
    return code


def user_input():
    """
    Get user input and return it
    """
    user = input("Input 4 digit code: ")

    if check_input_length_is_4_digits(user):
        return user
    else:
        return user_input()


def check_input_length_is_4_digits(user):
    """
    Check whether input length is exactly four digits 
    """     
    if len(user) != 4:
        print("Please enter exactly 4 digits.")
        return False
    else:
        return True


def compare_user_input_with_generated_code(code_gen, user_code):
    """
    Compares user input with randomly generated code
    """
    correct_digits_and_position = 0
    correct_digits_only = 0
    
    for i in range(len(user_code)):
        if code_gen[i] == int(user_code[i]):
            correct_digits_and_position += 1
        elif user_code[i] in code_gen:
            correct_digits_only +=1
    
    return (correct_digits_and_position, correct_digits_only)


def display_correct_digits_only_in_correct_position(correct_digits_position, correct_digits):
    """
    Prints correct digits in the correct position as well as
    the ones not in correct position
    """
    print('Number of correct digits in correct place:     '+str(correct_digits_position))
    print('Number of correct digits not in correct place: '+str(correct_digits))


def correct_digits_guessed(correct_digits_in_correct_position, chances, generated_code, true_correct):
    """
    Checks whether correct digits are guessed
    """
    if correct_digits_in_correct_position == 4:
        true_correct == True
        print('Congratulations! You are a codebreaker!')
        print('The code was: '+str(generated_code))
    else:
        print('Turns left: '+str(chances))



def looping_through_twelve_turns(gen_code):
    """
    Keeps track of turns if user input does not match with generated code
    and returns number of turns left 
    """
    correct = False
    turns = 12
    while not correct and turns > 0:
        answer = user_input()
        user_digits = check_input_length_is_4_digits(answer)
        in_correct_position, not_in_correct = compare_user_input_with_generated_code(gen_code, user_digits)
        turns -= 1 
        display_correct_digits_only_in_correct_position(in_correct_position, not_in_correct)
        correct_digits_guessed(in_correct_position, turns, gen_code, correct)
        if turns == 0 or correct == True:
            print('The code was: '+str(gen_code))
            break
        else:
            continue
    return turns, correct


# TODO: Decompose into functions
def run_game():
    """
    Runs the entire game
    """
    code_gen = random_four_digit_code()
    #print(code)
    print('4-digit Code has been set. Digits in range 1 to 8. You have 12 turns to break it.')
    turns = looping_through_twelve_turns(code_gen)
    display_correct_digits_only_in_correct_position(turns)

if __name__ == "__main__":
    # run_game()
    print(compare_user_input_with_generated_code('1234', '1234'))



