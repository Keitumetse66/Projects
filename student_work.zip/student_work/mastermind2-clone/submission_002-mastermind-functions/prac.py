import random

def random_four_digit_code():
    code = [0,0,0,0]
    for i in range(4):
        value = random.randint(1, 8) # 8 possible digits
        while value in code:
            value = random.randint(1, 8)  # 8 possible digits
        code[i] = value
    return code

def user_input():
    """
    Get user input and return it
    """
    return input("Input 4 digit code: ")

def check_input_length_is_4_digits(input):
    """
    Check whether input length is exactly four digits 
    """ 
    if len(input) < 4 or len(input) > 4:
        print("Please enter exactly 4 digits.")
    return input

def compare_user_input_with_generated_code(code_gen, user_input):
    correct_digits_and_position = 0
    correct_digits_only = 0
    
    code_gen = ''.join([str(i) for i in code_gen])

    for i in range(len(user_input)):
        if code_gen[i] == str(user_input[i]):
            correct_digits_and_position += 1
        elif str(user_input[i]) in code_gen:
            correct_digits_only +=1
    print('Number of correct digits in correct place:     '+str(correct_digits_and_position))
    print('Number of correct digits not in correct place: '+str(correct_digits_only))

def run_game():
    gen_code = random_four_digit_code()
    answer = user_input()
    lenght = check_input_length_is_4_digits(answer)
    compare_user_input_with_generated_code(gen_code, answer)


if __name__ == "__main__":
    run_game()