
# TODO: Step 1 - return shape from user input (it can't be blank and must be a valid shape!)     
def get_shape():

    shape = (input('shape?:'))
    return shape.lower()


# TODO: Step 1 - return height from user input (it must be int!)
#       The maximum possible height must be 80
def get_height():
    height = int(input('height:'))
    if height > 81:
        return get_height()
    return height


# TODO: Step 3 Complete the required shapes below
#       with reference to the unittests
def draw_square(height):
    for i in range(height):
        print('*', end='')
        for k in range(i+1):
            print('*')
    # for j in range(height):
    #     print('*')
    print('')
    

def draw_triangle_reversed(height):
    for i in range(height):
        print('*', end='')
        for k in range(i -1):
            print('*')
    print('*')

def draw_triangle(height):
    for i in range(0, height+1):
        print("*")
    for j in range(i +1):
        print('*')

def draw_triangle_multiplication(height):
    for i in range(height+1):
        print('*', end='')
        for k in range(i+1):
            print(' ')
    print('*')

def draw_pyramid(height):
    for i in range(height+1):
        print('*', end=' ')
        for k in range(i+1):
            print(' ')
    print('*')


def draw_triangle_prime(height):
    for i in range(height+1):
        print('*', end=' ')
        for k in range(i+1):
            print(' ')
    print('*')
         
                
# TODO: 4 - add support for other shapes
def draw(shape, height):
    if shape == "pyramid":
        draw_pyramid(height)
    if shape == "square":
        draw_square(height)
    if shape == "triangle":
        draw_triangle(height)
    if shape == "triangle-reversed":
        draw_pyramid(height)
    if shape == "prime":
        draw_triangle_prime(height)
    # if shape == "pyramid":
    #     draw_pyramid(height)



if __name__ == "__main__":
    shape_param = get_shape()
    height_param = get_height()
    draw(shape_param, height_param)