import unittest
import robot
from unittest.mock import patch
from io import StringIO
import sys
from test_base import run_unittests
from test_base import captured_io

class TestClassToyRobot2(unittest.TestCase):

    @patch('sys.stdin', StringIO('HAL\n'))
    def test_ask_bot_name(self):
        """
        Tests the whether the ask-bot-name works as intended
        """
        
        self.assertEqual(robot.ask_bot_name(), "HAL")

    def test_help_command(self):
        """
        Tests whether all the help commands appear and works as intended
        """
        with captured_io(StringIO('HAL\nhelp\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? HAL: Hello kiddo!
HAL: What must I do next? I can understand these commands:
OFF  - Shut down robot
HELP - provide information about commands
""", output[:179])

if __name__ == '__main__':
    unittest.main()