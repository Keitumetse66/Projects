# import itertools

# s = 'help'

# list_1 = list(map(''.join, itertools.product(*zip(s.upper(), s.lower()))))

# print(list_1)
def bot_naqme():
    bot_name='HAL'
    turn_off = input(f'{bot_name}: What must I do next? ').upper()

    while True:
        off_list = ['OFF','HELP']
        # turn_off.upper()
        if turn_off== off_list[0]:
            print(f'{bot_name}: Shutting down..\n')
            break
        elif turn_off== off_list[-1]:
            print("I can understand these commands: \n OFF - Shut down robot\n HELP - Provide information about commands\n\n")
            return 
        else:
            print(f"{bot_name}: Sorry, I did not understand '{turn_off}'.")
            return turn_off

if __name__ == '__main__':
    bot_naqme()