#Step 1
def ask_bot_name():
    """
    Prompts child to give the bot a name
    """
    bot_name = input("What do you want to name your robot? ").upper()
    display_bot_name(bot_name)

    return bot_name


def display_bot_name(bot_name):
    """
    Displays the bot name
    """
    
    print(f'{bot_name}: Hello kiddo!')

#step2
def user_command(bot_name, command_list):
    """
    Handles off input from child 
    """
    command = input(f'{bot_name}: What must I do next? ').lower()
    while command.split()[0] not in command_list:
        other_command(bot_name, command)
        command = input(f'{bot_name}: What must I do next? ')
    return command


def other_command(bot_name, user_input):
    """
    Handles other commands entered except off and help
    """
    print(f"{bot_name}: Sorry, I did not understand '{user_input.capitalize()}'.")


def help_command():
    """
    Help command function
    """
    hepl = "I can understand these commands:\n\
OFF  - Shut down robot\n\
HELP - provide information about commands\n\
FORWARD - moves the robot forward\n\
BACK - moves the robot backwards\n\
LEFT - turns the robot to the left\n\
RIGHT - turns the robot to the left\n\
SPRINT - moves the robot forward with an increased speed"

    print(hepl)

def command_valuation(bot_name, command, foward_steps, back_steps, direction, bot_position):
    """
    Evaluates all comands
    """
    

    command_list = ['off', 'help', 'forward', 'back', 'right', 'left', 'sprint']
    while True:
        if command.lower() == command_list[0]:
            off_command(bot_name, command)
            return False, direction
        elif command.lower() == command_list[1]:
            help_command()
        elif command.lower() == command_list[4]:
            direction = turn_right(direction)
        elif command.lower() == command_list[5]:
            direction = turn_left(direction)
        elif foward_steps[0].lower() == command_list[2] or foward_steps[0].lower() == command_list[6]:
            foward_position(bot_name, direction, foward_steps, bot_position)
        elif back_steps[0].lower() == command_list[3]:
            backward_position(bot_name, direction, back_steps, bot_position)
        elif foward_steps.lower() == command_list[6]:
            steps = int(foward_steps[1])
            sprint_list = []
            sprint_foward = sprint(bot_name, foward_steps[0].lower(), steps, sprint_list)
            print(sprint_foward)
        if command.lower() == command_list[4] or command.lower() == command_list[5]:
            print(f' > {bot_name} turned {command}.')
            print(f" > {bot_name} now at position ({bot_position['x']},{bot_position['y']}).")
        return True, direction
    

def move_foward(command):
    """
    Moves the robot foward by specified steps
    """
    if " " in command:
        move = command.split()[0]
        steps = command.split()[1]
    else:
        move = command
        steps = 0

    return move, steps

def move_backward(command):
    """
    Moves the robot backwards by specified steps
    """
    if " " in command:
        move = command.split()[0]
        steps = command.split()[1]
    else:
        move = command
        steps = 0
    return move, steps

def off_command(bot_name, command):
    """
    Handles the off command
    """
    if command.lower() == 'off':
        print(f'{bot_name}: Shutting down..')
    else:
        pass

def turn_right(direction):
    """
    Handles the movement of the robot to the right
    """
    direction += 1
    if direction == 5:
        direction -= 4
    return direction

def turn_left(direction):
    """
    Handles the movement of the robot to the left
    """
    direction -= 1
    if direction == 0:
        direction += 4
    return direction

def sprint(command, steps, bot_name, sprint_list):
    """
    Handles the increased speed of the robot fowards
    """
    sprint_list.append(steps)
    print(f' > {bot_name} moved forward by {steps} steps.')
    if steps == 1:
        return 1
    else:
        sprint(command, steps-1, bot_name, sprint_list)
    return sum(sprint_list)


def foward_position(bot_name, direction, foward_steps, bot_position):
    """
    Handles foward commands and positions for in each catesian quadrant
    """

    if direction == 1 and bot_position['y'] + int(foward_steps[1]) <= 200:
        if foward_steps[0].lower() == 'sprint':
            steps = int(foward_steps[1])
            sprint_list = []
            sprint_foward = sprint(foward_steps[0].lower(), steps, bot_name, sprint_list)
            bot_position['y'] += sprint_foward
            print(f" > {bot_name} now at position ({bot_position['x']},{bot_position['y']}).")
        else:
            bot_position['y'] += int(foward_steps[1])
            print(f" > {bot_name} moved forward by {foward_steps[1]} steps.\n\
 > {bot_name} now at position ({bot_position['x']},{bot_position['y']}).")
    elif direction == 2 and bot_position['x'] + int(foward_steps[1]) >= -100:
        if foward_steps[0].lower() == 'sprint':
            steps = int(foward_steps[1])
            sprint_list = []
            sprint_foward = sprint(foward_steps[0].lower(), steps, bot_name, sprint_list)
            bot_position['x'] += sprint_foward
            print(f" > {bot_name} now at position ({bot_position['x']},{bot_position['y']}).")
        else:
            bot_position['x'] += int(foward_steps[1])
            print(f" > {bot_name} moved forward by {foward_steps[1]} steps.\n\
 > {bot_name} now at position ({bot_position['x']},{bot_position['y']}).")
    elif direction == 3 and bot_position['y'] - int(foward_steps[1]) >= -200:
        if foward_steps[0].lower() == 'sprint':
            steps = int(foward_steps[1])
            sprint_list = []
            sprint_foward = sprint(foward_steps[0].lower(), steps, bot_name, sprint_list)
            bot_position['y'] += sprint_foward
            print(f" > {bot_name} now at position ({bot_position['x']},{bot_position['y']})")
        else:
            bot_position['y'] -= int(foward_steps[1])
            print(f" > {bot_name} moved forward by {foward_steps[1]} steps.\n\
 > {bot_name} now at position ({bot_position['x']},{bot_position['y']}).")
    elif direction == 4 and bot_position['x'] - int(foward_steps[1]) >= -100:
        if foward_steps[0].lower() == 'sprint':
            steps = int(foward_steps[1])
            sprint_list = []
            sprint_foward = sprint(foward_steps[0].lower(), steps, bot_name, sprint_list)
            bot_position['x'] += sprint_foward
            print(f" > {bot_name} now at position ({bot_position['x']},{bot_position['y']}).")
        else:
            bot_position['x'] -= int(foward_steps[1])
            print(f" > {bot_name} moved forward by {foward_steps[1]} steps.\n\
 > {bot_name} now at position ({bot_position['x']},{bot_position['y']}).")

    if (direction == 1 and bot_position['y'] + int(foward_steps[1]) > 200) or (direction == 4\
        and bot_position['x'] + int(foward_steps[1]) < -100) or (direction == 3 and bot_position['y']\
        - int(foward_steps[1]) < -200) or (direction == 4 and bot_position['x'] + int(foward_steps[1]) > 100):

        print(f'{bot_name}: Sorry, I cannot go outside my safe zone.')
        print(f" > {bot_name} now at position ({bot_position['x']},{bot_position['y']}).")

    return bot_position


def backward_position(bot_name, direction, back_steps, bot_position):
    """
    Handles backward commands and positions for in each catesian quadrant
    """
    if direction == 1 and bot_position['y'] - int(back_steps[1]) >= -200:
        bot_position['y'] -= int(back_steps[1])
        print(f" > {bot_name} moved back by {back_steps[1]} steps.\n\
 > {bot_name} now at position ({ bot_position['x']},{bot_position['y']}).")
    elif direction == 2 and bot_position['x'] - int(back_steps[1]) >= -100:
        bot_position['x'] -= int(back_steps[1])
        print(f" > {bot_name} moved back by {back_steps[1]} steps.\n\
 > {bot_name} now at position ({ bot_position['x']},{bot_position['y']}).")
    elif direction == 3 and bot_position['y'] + int(back_steps[1]) <= 200:
        bot_position['y'] -= int(back_steps[1])
        print(f" > {bot_name} moved back by {back_steps[1]} steps.\n\
 > {bot_name} now at position ({ bot_position['x']},{bot_position['y']}).")
    elif direction == 4 and bot_position['x'] + int(back_steps[1]) <= 100:
        bot_position['x'] += int(back_steps[1])
        print(f" > {bot_name} moved back by {back_steps[1]} steps.\n\
 > {bot_name} now at position ({ bot_position['x']},{bot_position['y']}).")


    if (direction == 1 and bot_position['y'] - int(back_steps[1]) < -200) or (direction == 4\
        and bot_position['x'] + int(back_steps[1]) > 100) or (direction == 3 and bot_position['y']\
        - int(back_steps[1]) > 200) or (direction == 4 and bot_position['x'] + int(back_steps[1]) > 100):

        print(f'{bot_name}: Sorry, I cannot go outside my safe zone.')
        print(f"> {bot_name}: now at position ({bot_position['x']},{bot_position['y']}).")

    return bot_position


def robot_start():
    """This is the entry function, do not change"""

    direction = 1
    bot_position = {'x': 0, 'y': 0}
    command_list = ['off', 'help', 'forward', 'back', 'right', 'left', 'sprint'] 
    
    start = True
    bot_name = ask_bot_name()
    while start:
        next_command = user_command(bot_name, command_list)
        foward_steps = move_foward(next_command)
        back_steps = move_backward(next_command)
        start, direction = command_valuation(bot_name, next_command, foward_steps, back_steps, direction, bot_position)

if __name__ == "__main__":
    robot_start()
