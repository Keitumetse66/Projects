
import sys
import unittest
import mastermind
from unittest.mock import patch
from io import StringIO


def get_answer_input():
    """
    Prompts user to enter a 4 digit code
    """
    return input("Enter 4 digit code: ")



class TestClassMastermindFunctions(unittest.TestCase):

    def test_create_code(self):
        """
        Returns True if len of code == 4
        and index of code is ni range of 1 to 8
        """
        code = mastermind.create_code()
        for i in range(100):
            self.assertEqual(len(code), 4)
            self.assertTrue(isinstance(code, list))
          
            for i in range(4):
                self.assertTrue(code[i] in range(1,9))

    
    def test_check_correctness(self):
        """
        Tests the validity of the correctness of the generated code against
        the user input, as well as as the functionality of the turns
        """
        turns = mastermind.check_correctness(12, 4)
        correct_position_digits = mastermind.check_correctness(11, 3)
        self.assertTrue(turns)
        self.assertFalse(correct_position_digits)


    @patch("sys.stdin", StringIO("7623")) # mocks a user input using the patch annotation
    def test_answer_input(self):
        """
        tests whether there's input from user,
        Fails if there's none
        """
        self.assertEqual(get_answer_input(), "7623")

    @patch('mastermind.take_turn', side_effect=[
        (4, 0),
        (2, 0),
        (2, 2)
    ])
    def test_take_turn(self, check_take_turn):
        """
        Tests if several mock outputs matches the generated code,
        retuns the answer as a tuple of correct digits in correct position
        as well as correct digits only
        """
        self.assertEqual(mastermind.take_turn([7,6,2,3], 7623), (4, 0))
        self.assertEqual(mastermind.take_turn([7,6,2,3], 7614), (2, 0))
        self.assertEqual(mastermind.take_turn([4,8,1,5], 4851), (2, 2))

        # self.assertTrue(isinstance(mastermind.take_turn('7623'), tuple))

sys.stdout = StringIO()
if __name__ == '__main__':
    unittest.main()