

# TODO: Step 1 - get shape (it can't be blank and must be a valid shape!)
from logging import exception


def get_shape():
    shapetype = input('Shape?: ').lower()
    
    if shapetype == 'pyramid':
        return shapetype
    if shapetype == 'square':
        return shapetype
    if shapetype == 'triangle':
        return shapetype
    if shapetype == 'reverse_pyramid':
        return shapetype
    if shapetype == 'descending_triangle':
        return shapetype
    else:
        return get_shape()
        
 


# TODO: Step 1 - get height (it must be int!)
def get_height():
    try:
        shape_height = int(input('Height?: '))
    
        if shape_height < 81:
            return shape_height
    except Exception as err:
        return get_height()

    return 0


# TODO: Step 2
def draw_pyramid(height, outline):
    if outline == False:
        for i in range(height):
            for j in range(i, height-1):
                print("", end=" ")
            for j in range(2*i+1):
                print("*", end="")

            print()
    else:
        for i in range(height):
            for j in range(i, height -1):
                print(' ', end='')
        
            for j in range(2*i +1):
                if j == 0 or j == 2*i:
                    print('*', end='')
                else:
                    if i == height -1:
                        print('*', end='')
                    else:
                        print(' ', end='')
            print()

#------------------- Reverse Pyramid -------------------
def draw_reverse_pyramid(height, outline):
    if outline == False:
        for i in range(height):
            for j in range(i):
                print(' ', end='')
            for j in range(2*i-height-1):
                print('*', end='')
            print()
    else:
        for i in range(height):
            for j in range(i+1):
                print(' ', end='')
            for j in range(i, height-1):
                if i == 0 or j == 0 or j == height -1 or j == i or i == height-1:
                    print('*', end='')
                else:
                    print(' ', end='')    
            for j in range(i, height):
                if i == 0 or j == 0 or i == height-1:
                    print('*', end='')
                else:
                    if i+j == 2*height or j == height-1:
                        print('*', end='')
                    else:
                        print(' ', end='')
            print()


#----------Descending triangle

def draw_descending_triangle(height, outline):
    if outline == False:
        for i in range(height):
            for j in range(i, height):
                print('*', end='')
            print()
    else:
        for i in range(height):
            for j in range(i, height):
                if i == 0 or j ==i or j==height -1:
                    print('*', end='')
                else:
                    print(' ', end='')
            print()





# TODO: Step 3
def draw_square(height, outline):
    if outline == False:
        for i in range(height):
            for j in range(height):
                print('*', end='')

            print()
    else:
        for i in range(height):
            for j in range(height):
                if i == 0 or j == height - 1 or j == 0 or i == height - 1:
                    print('*', end="")
                else:
                    print(' ', end="")
            print()


# TODO: Step 4
def draw_triangle(height, outline):
    if outline == False:
        for i in range(height):
            for j in range(i+1):
                print("*", end="")
            print()
    else:
        for i in range(height):
            for j in range(i+1):
                if i == height - 1 or j == 0 or j == i:
                    print("*", end="")
                else:
                    print(' ', end='')
            print()



# TODO: Steps 2 to 4, 6 - add support for other shapes
def draw(shapetype, height, outline):
    if shapetype == "pyramid":
       return draw_pyramid(height, outline)
    if shapetype == "sqaure":
        return draw_square(height, outline)
    if shapetype == "triangle":
        return draw_triangle(height, outline)
    if shapetype == "reverse_pyramid":
        return draw_reverse_pyramid(height, outline)
    if shapetype == "descending_triangle":
        return draw_descending_triangle(height, outline)


# TODO: Step 5 - get input from user to draw outline or solid
def get_outline():
    shape_outline = input("Outline only? (y/N):")
    if shape_outline == 'y':
        return True
    else:
        return False
        


if __name__ == "__main__":
    shape_param = get_shape()
    height_param = get_height()
    outline_param = get_outline()
    draw(shape_param, height_param, outline_param)

