import random


def run_game():
    """
        Defines a list with a sample range of 1 to 8, then
        randomly selects and returns the numbers in a new list of length 4
        without any char repetition
    """
    #Step 1
    master_list = []

    while len(master_list) < 4:
        random_num = random.randint(1,8)
        if random_num not in master_list:
            master_list.append(random_num)
        
    
    


    print("4-digit Code has been set. Digits in range 1 to 8. You have 12 turns to break it.")


    #Step 2 - 4
    turns = 12

    while turns > 0:
        user_input = input("Input 4 digit code: ")
        if len(user_input) == 4:
            res = "".join(str(i) for i in master_list)
            if user_input.isdigit() == True and "0" not in user_input and "9" not in user_input:
                corrrect_item = 0
                incorrect_item = 0
                for i in user_input:
                    if i in res and res.index(i) == user_input.index(i):
                        corrrect_item += 1
                    elif i in res and res.index(i) != user_input.index(i):
                        incorrect_item += 1
                print(f"Number of correct digits in correct place:     {str(corrrect_item)}")
                print(f"Number of correct digits not in correct place: {str(incorrect_item)}")

                if user_input == res:
                    print("Congratulations! You are a codebreaker!")
                    print("The code was: " + res)
                    break
        else:
            print("Please enter exactly 4 digits.")
            continue

        turns -= 1
        print(f"Turns left: {turns}")
        if turns == 0:
            print("The code was: " + res)

if __name__ == "__main__":
    run_game()
    