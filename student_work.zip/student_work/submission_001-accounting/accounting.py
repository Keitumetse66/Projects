from user.authentication import * 
from transactions.journal import *
# from banking import reconciliation as bank_recon
import banking.fvb.reconciliation as recon

# import banking.ubsa.reconciliation as bank_ubfcdsa_recon
# from banking import reconciliation as bank_recon
import sys



if __name__ == '__main__':
    for i, j in enumerate(sys.argv[1:]):
        print(j)
    authenticate_user()
    receive_income(100)
    pay_expense(100)
    # bank_recon.do_reconciliation()
    recon.do_reconciliation()
    # bank_ubsa_recon.do_reconciliation()
    # online_recon.do_reconciliation()
    # print('(ignoring all the previous module load and initialization messages)')
    
    
    # print('(and the rest of the output)')