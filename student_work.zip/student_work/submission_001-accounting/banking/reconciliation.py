print('[Module] Reconciliation loaded.')

def do_reconciliation():
    """
    Bank Reconciliation
    """
    print('Doing bank reconciliation.')