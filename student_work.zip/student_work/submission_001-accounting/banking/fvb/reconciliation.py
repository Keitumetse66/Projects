print('[Module] fvb.Reconciliation loaded.')

def do_reconciliation():
    """
    First Virtual Bank Recon
    """
    print('Doing First Virtual Bank reconciliation.')