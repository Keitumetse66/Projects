import requests

print('[Module] online.Reconciliation loaded.')


def do_reconciliation():
    """
    online bank recon which makes a request to a webpage:
    returns a 200 if request was successful
    returns a 404 if the url is invalid
    returns a 500 if an internal server error occured
    """
    print('Doing Online Bank reconciliation.')
    response = requests.get('https://www.wethinkcode.co.za')
    print(response.status_code)