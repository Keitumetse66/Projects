
print('[Module] User Authentication loaded.')

def authenticate_user():
    """
    Authenticates user
    """
    print('Authenticating User')
    return True