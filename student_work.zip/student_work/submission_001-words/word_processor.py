from collections import Counter
from string import ascii_letters

def split(delimiters, text):
    """
    Splits a string using all the delimiters supplied as input string
    :param delimiters:
    :param text: string containing delimiters to use to split the string, e.g. `,;? `
    :return: a list of words from splitting text using the delimiters
    """

    import re
    regex_pattern = '|'.join(map(re.escape, delimiters))
    return re.split(regex_pattern, text, 0)


def convert_to_word_list(text):
    """
    Converts sentence to a list and removes any unwanted characters
    """
    words = split(",?.; ", text.lower())
    word = list(filter(None, words))
    return word
    

def words_longer_than(length, text):
    """
    Returns a list of words that are longer than the
    specified length
    """
    text = convert_to_word_list(text)
    word_length = list(map(lambda word: word, filter(lambda word: len(word) > length, text)))
    return word_length
    
def words_lengths_map(text):
    """
    Maps word lenght to the number of words that has the same length as that word
    """
    words = convert_to_word_list(text)
    words_lengths = list(set(map(len, words)))
    dictionary = dict()

    for l in words_lengths:
        n = len([word for word in words if len(word) == l])
        dictionary[l] = n

    return dictionary

def letters_count_map(text):
    """
    Maps each alphabet letter to the number of times that letter
    occurs in the text
    """
    alphabets = ascii_letters[:26]
    dictionary = {}

    for char in alphabets:
        dictionary[char] = text.lower().count(char)

    return dictionary


def most_used_character(text):
    """
    r
    """
    alpha_map = letters_count_map(text)

    if text == '': 
        return None

    max_v= max(alpha_map.values())
    most_used = [letter for letter in alpha_map.keys() if alpha_map.get(letter) == max_v]
    return most_used[0]
    



if __name__ == '__main__':
    convert_to_word_list('These are indeed interesting, an obvious understatement, times. What say you?')
    words_longer_than(10, 'These are indeed interesting, an obvious understatement, times. What say you?')
    words_lengths_map('These are indeed interesting, an obvious understatement, times. What say you?')
    letters_count_map('These are indeed interesting, an obvious understatement, times. What say you?')
