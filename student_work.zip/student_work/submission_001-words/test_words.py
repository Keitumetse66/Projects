import unittest
from  unittest.mock import _patch
import word_processor


class TestClassWords(unittest.TestCase):
    
    def test_convert_to_word_list(self):
        text = word_processor.convert_to_word_list('Nemo enim ipsam voluptatem? voluptas aspernatur odit fugit, consequuntur magni; dolores ratione voluptatem sequi.')
    
        self.assertEqual(['nemo', 'enim', 'ipsam', 'voluptatem', 'voluptas', 'aspernatur', 'odit', 'fugit', 'consequuntur', 'magni', 'dolores', 'ratione', 'voluptatem', 'sequi'], text)


    def test_words_longer_than(self):
        text = word_processor.words_longer_than(10, 'These are indeed interesting, an obvious understatement, times. What say you?')
        word = word_processor.words_longer_than(8, 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.')
        self.assertEqual(['interesting', 'understatement'], text)
        self.assertEqual(['mountains', 'countries', 'consonantia'], word)

    def test_words_legnth_map(self):
        text = word_processor.words_lengths_map('These are indeed interesting, an obvious understatement, times. What say you?')
        word = word_processor.words_lengths_map('Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.')


        self.assertEqual({2: 1, 3: 3, 4: 1, 5: 2, 6: 1, 7: 1, 11: 1, 14: 1}, text)
        self.assertEqual({3: 7, 4: 4, 5: 3, 6: 1, 7: 1, 9: 2, 11: 1}, word)


    def test_letter_count_map(self):
        text = word_processor.letters_count_map('These are indeed interesting, an obvious understatement, times. What say you?')
        word = word_processor.letters_count_map('Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.')

        self.assertEqual({'a': 5, 'b': 1, 'c': 0, 'd': 3, 'e': 11, 'f': 0, 'g': 1, 'h': 2, 'i': 5, 'j': 0, 'k': 0, 'l': 0, 'm': 2, 'n': 6, 'o': 3, 'p': 0, 'q': 0, 'r'
: 3, 's': 6, 't': 8, 'u': 3, 'v': 1, 'w': 1, 'x': 0, 'y': 2, 'z': 0}, text)
        self.assertEqual({'a': 11, 'b': 2, 'c': 2, 'd': 4, 'e': 9, 'f': 4, 'g': 0, 'h': 5, 'i': 7, 'j': 0, 'k': 1, 'l': 3, 'm': 2, 'n': 9, 'o': 7, 'p': 0, 'q': 0, 'r'
: 7, 's': 4, 't': 9, 'u': 2, 'v': 2, 'w': 2, 'x': 1, 'y': 1, 'z': 0}, word)

    def test_most_used_character(self):
        text = word_processor.most_used_character('These are indeed interesting, an obvious understatement, times. What say you?')
        word = word_processor.most_used_character('Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.')


        self.assertEqual('e', text)
        self.assertEqual('a', word)
if __name__ == '__main__':
    unittest.main()