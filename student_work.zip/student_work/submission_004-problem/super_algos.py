
def find_min(element):
    """
    Recursive function that finds and returns the 
    minimum element in a list of integers
    """
    for i in element:
        if type(i) != int:
            return -1
    if len(element) == 0:
        return -1
    elif len(element) == 1:
        return element[0]
    else:
        mini = find_min(element[1:])
        minimum = element[0]
        if mini < minimum:
            minimum = mini
        return minimum



def sum_all(element):
    """TODO: complete for Step 2"""
    for i in element:
        if type(i) != int:
            return -1
    if len(element) == 0:
        return -1
    elif len(element) == 1:
        return element[0]
    else:
        return element[0] + sum_all(element[1:])


def find_possible_strings(character_set, n):
    """TODO: complete for Step 3"""
    for i in character_set:
        if type(i) != str:
            return []
    k = len(character_set)
    newPrefix = []
    return  possible_stringsRec(character_set, "", k, n, newPrefix)


def possible_stringsRec(char_set, prefix, k, n, newPrefix):
    if n == 0:
        newPrefix.append(prefix)
        return
    
    for i in range(k):
        new_prefix = prefix + char_set[i]
        possible_stringsRec(char_set, new_prefix, k, n-1, newPrefix)
    return newPrefix

if __name__ == '__main__':
    print(find_possible_strings(['j','k','l'], 2))