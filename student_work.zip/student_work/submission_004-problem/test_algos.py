import unittest
import sys
import super_algos

class TestClassAlgos(unittest.TestCase):

    def test_step1_find_min(self):
        """
        * Tests if it retruns -1 when list is empty, 
            or list contains non integer data types.
        * Tests if it can find a min even on negative
            elements
        """
        empty_list = super_algos.find_min([])
        self.assertEqual(-1, empty_list)

        normal = super_algos.find_min([1,3,4,6,23])
        self.assertEqual(1, normal)

        non_int_types = super_algos.find_min(['a',100,True,-1,0.2])
        self.assertEqual(-1, non_int_types)

        min_negative_elements = super_algos.find_min([100,12,-3,-2,9])
        self.assertEqual(-3, min_negative_elements)

    def test_step2_sum_all(self):
        """
        * Tests if it retruns -1 when list is empty, 
            or list contains non integer data types.
        * Tests if it can find the sum even of negative
            elements
        """
        empty_list = super_algos.sum_all([])
        self.assertEqual(-1, empty_list)

        normal = super_algos.sum_all([2,3,6,8,19])
        self.assertEqual(38, normal)
    
        non_int_types = super_algos.sum_all(['a',100,True,-1,0.2])
        self.assertEqual(-1, non_int_types)

        min_negative_elements = super_algos.sum_all([-3,-7,-4,10,-5])
        self.assertEqual(-9, min_negative_elements)

    def test_step3_find_possible_strings(self):

        empty_list = super_algos.find_possible_strings([], 3)
        self.assertEqual([], empty_list)

        non_string_type = super_algos.find_possible_strings([2,3,5,True,0.2], 2)
        self.assertEqual([], non_string_type)

        one_char_string_combinations = super_algos.find_possible_strings(['g','h','i'], 1)
        self.assertEqual(['g','h','i'], one_char_string_combinations)

        two_char_string_combinations = super_algos.find_possible_strings(['j','k','l'], 2)
        self.assertEqual(['jj', 'jk', 'jl', 'kj', 'kk', 'kl', 'lj', 'lk', 'll'], two_char_string_combinations)




if __name__ == '__main__':
    unittest.main()