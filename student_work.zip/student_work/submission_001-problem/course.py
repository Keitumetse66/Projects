

from logging import exception


def create_outline():
    """
    TODO: implement your code here
    """
    
    #step 1
    """
        Create a set with a list as an iterable
    """
    topics = set(["Introduction to Python", "Tools of the Trade", "How to make decisions", "How to repeat code", "How to structure data", "Functions", "Modules"])
    print("Course Topics:")
    
    """
        Loop through each topic in topics and print them along with 
        an asterick
    """
    #Step 4
    topics = list(topics)
    topics.sort()

    
    for items in topics:
        print("*", items)

    print("Problems:")

    #step 2
    """
        create a list of problems and an empty dictionary
    """
    problems = ['Problem 1', ' Problem 2' ,' Problem 3']
    topic_problem_dict = dict()

    """
        Loop through each topic in topics and map it to a list of 
        problems
    """
    for topic in topics:
        topic_problem_dict[topic] = problems
    """
        Loop through each item in the new dictionary and convert
        the list of problems to strings using the map() func
        then print the outcome
    """
    for i in topic_problem_dict:
        topi_problem = ','.join(map(str,topic_problem_dict[i]))
        print('*',i,':', topi_problem)


    #step 3
    print("Student Progress:")
    students = ["Tom", "Dick", "Harry"]
    topic = ["How to make decisions", "How to structure data", "Tools of the Trade"]
    problem = ["problem 1", "problem 2", "problem 3"]
    statuses = ["STARTED", "GRADED", "COMPLETED"]

    new_student_record = []

    for index in range(len(students)):
        new_student_record.append((students[index], topic[index], problem[index], statuses[index]))
        
        new_student_record.sort(key=lambda status: status[-1], reverse=True)

    for index, record in enumerate(new_student_record):
        print(f'{index+1}. {record[0]} - {record[1]} - {record[2]} [{record[3]}]')

if __name__ == "__main__":
    create_outline()
