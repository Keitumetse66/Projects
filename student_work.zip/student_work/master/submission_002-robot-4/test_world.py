# import unittest
# import robot
# import sys
# from unittest.mock import patch
# from io import StringIO

# class MyTest(unittest.TestCase):
#     @patch("sys.stdin", StringIO("HAL\nMPHO\n"))
#     def test_
