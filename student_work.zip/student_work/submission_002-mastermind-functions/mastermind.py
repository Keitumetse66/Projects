import random

def generate_code():
    """
    Randomly selects 4 digits,
    adds them to a list and returns them  
    """
    gen_code = []
    
    while len(gen_code) < 4 :
        i = random.randint(1,8)
        if i not in gen_code:
            gen_code.append(i)
        

    print ("4-digit Code has been set. Digits in range 1 to 8. You have 12 turns to break it.")
    return gen_code


def user_input():
    """
    Get user input, checks if all of them are digits,
    and are within the range of 1 to 8 and returns it as a list
    """
    user_guess=input("Input 4 digit code: ")

    if user_guess.isdigit()== False or len(user_guess) !=4 or "0" in user_guess or "9" in user_guess:
        print("Please enter exactly 4 digits.")
        return user_input()

    else:
        user_guess = list(map(int, list(user_guess)))
        return user_guess



def check_correct_digits_in_correct_and_incorrect_positions(user_guess, guess_list):
    """
    Checks which digits are in the correct positions and which are not in 
    correct places but exists in the list and prints them
    """
    correct_position = 0
    incorrect_position = 0

    for i in range(len(user_guess)):
        if user_guess[i] in guess_list and user_guess[i] == guess_list[i]:
            correct_position = correct_position +1
        elif user_guess[i] in guess_list and user_guess[i] != guess_list[i]:   
            incorrect_position = incorrect_position +1


    print(f'Number of correct digits in correct place:     {correct_position}' )
    print(f'Number of correct digits not in correct place: {incorrect_position}')


def run_game():
    """
    Runs the whole game
    """
    guess_list = generate_code()
    
    count = 12
    while count != 0:
        user_guess = user_input()

        check_correct_digits_in_correct_and_incorrect_positions(user_guess, guess_list)

        if user_guess == guess_list:
            print("Congratulations! You are a codebreaker!")
            print(f'The code was: {guess_list}')
            break

            
        count = count -1
        print(f"Turns left: {count}")
        if count == 0:
            break 
            


if __name__ == "__main__":
    run_game()
