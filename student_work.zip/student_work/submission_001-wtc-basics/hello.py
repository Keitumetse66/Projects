def print_hello():
    # modify this code so it prints out 'Hello World!'
    print("Hello World!")


if __name__ == "__main__":
    print_hello()
