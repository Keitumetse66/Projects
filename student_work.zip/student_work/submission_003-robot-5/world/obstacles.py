# -------------------------------------------------------------------------------------------------
#
# TODO: Please replace this placeholder code with your solution for Toy Robot 4, and work from there.
#
# -------------------------------------------------------------------------------------------------

import random

def get_obstacle():
   

    obs_x=random.randint(0,0)
    obs_y=random.randint(0,0)

    position=([obs_x,obs_y], [obs_x+4, obs_y], [obs_x+4, obs_y+4], [obs_x, obs_y+4])


    return position


def is_position_blocked(obs_list, random_obs):
    """
    Checks if there is a direct colision with the obstacle and the robots end location
    """
    for obs_x,obs_y in random_obs:
        if obs_x in range(obs_x,obs_x+4) and obs_y in range(obs_y,obs_y+4):
            print("Sorry, there is an obstacle in the way.")
            return True
    return False 

def print_obstacles(obstacles):

    if obstacles[0][0] != 0 and obstacles[0][1] != 0:

        print("There are some obstacles:")
        print(f"- At position {obstacles[0][0]},{obstacles[0][1]} (to {obstacles[2][0]},{obstacles[2][1]})")



