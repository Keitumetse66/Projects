# -------------------------------------------------------------------------------------------------
#
# TODO: Please replace this placeholder code with your solution for Toy Robot 4, and work from there.
#
# -------------------------------------------------------------------------------------------------


import turtle
from world import obstacles as obs

# spud = object
# s = object
is_sprint = False
is_obstructed = False

position_x = 0
position_y = 0
directions = ['forward', 'right', 'back', 'left']
current_direction_index = 0



# area limit vars
min_y, max_y = -200, 200
min_x, max_x = -100, 100


# list of valid command names
valid_commands = ['off', 'help', 'replay', 'forward', 'back', 'right', 'left', 'sprint']
move_commands = valid_commands[3:]

def list_obstacles():
    """
    Prints a list of coordinates of ostacles
    """

    obstacles = obs.get_obstacle()
    

def is_int(value):
    """
    Tests if the string value is an int or not
    :param value: a string value to test
    :return: True if it is an int
    """
    try:
        int(value)
        return True
    except ValueError:
        return False


def split_command_input(command):
    """
    Splits the string at the first space character, to get the actual command, as well as the argument(s) for the command
    :return: (command, argument)
    """
    args = command.split(' ', 1)
    if len(args) > 1:
        return args[0], args[1]
    return args[0], ''

def show_position(robot_name):
    print(' > '+robot_name+' now at position ('+str(position_x)+','+str(position_y)+').')


def is_position_allowed(new_x, new_y):
    """
    Checks if the new position will still fall within the max area limit
    :param new_x: the new/proposed x position
    :param new_y: the new/proposed y position
    :return: True if allowed, i.e. it falls in the allowed area, else False
    """

    return min_x <= new_x <= max_x and min_y <= new_y <= max_y


def update_position(steps):
    """
    Update the current x and y positions given the current direction, and specific nr of steps
    :param steps:
    :return: True if the position was updated, else False
    """

    global position_x, position_y, is_obstructed
    new_x = position_x
    new_y = position_y

    if directions[current_direction_index] == 'forward':
        new_y = new_y + steps
    elif directions[current_direction_index] == 'right':
        new_x = new_x + steps
    elif directions[current_direction_index] == 'back':
        new_y = new_y - steps
    elif directions[current_direction_index] == 'left':
        new_x = new_x - steps
    
    if obs.is_position_blocked(new_x, new_y) or obs.is_position_blocked(position_x, position_y, new_x, new_y):
        is_obstructed = True
        return True

def initialize_objects():
    """
    Initializes turtle graphics' objects
    """
    global s
    global spud

    s = turtle.getscreen()

    spud = turtle.Turtle()
    s.setworldcoordinates(-250, -250, 250, 250)


def setup_graphics():
    """
    Initializes the settings and colors of the turtle.
    """

    global spud

    turtle.title("Toy Robot 5")
    turtle.bgcolor("white")
    spud.turtlesize(1.5)
    spud.speed(1)
    spud.color("black","cyan3")


def constrain_turtle():

    global spud

    spud.speed(0)
    spud.pencolor("cyan4")
    spud.penup()
    spud.goto(-100, -200)
    spud.pendown()
    spud.goto(-100, 200)
    spud.goto(100, 200)
    spud.goto(100, -200)
    spud.goto(-100, -200)
    spud.penup()
    spud.goto(0, 0)
    spud.setheading(90)


def draw_obstacles():
    """
    Draws all obstacles on the turtle graphics
    """

    global spud

    spud.pencolor("red")
    spud.speed(0)
    
    for item in obs.get_obstacle:
        spud.fillcolor("red")
        spud.penup()
        spud.goto(item[0], item[1])
        spud.begin_fill()
        spud.pendown()
        spud.goto(item[0], item[1] + 4)
        spud.goto(item[0] + 4, item[1] + 4)
        spud.goto(item[0] + 4, item[1])
        spud.goto(item[0], item[1])
        spud.end_fill()


def do_forward(robot_name, steps):
    """
    Moves the robot forward the number of steps
    :param robot_name:
    :param steps:
    :return: (True, forward output text)
    """

    global spud, is_sprint, is_obstructed 

    if update_position(steps):
        if is_sprint == True:
            spud.speed(9)
        else:
            spud.speed(1)
            spud.fd(steps)


        return True, ' > '+robot_name+' moved forward by '+str(steps)+' steps.'
    else:
        if is_obstructed == True:
            return True, ''+robot_name+'Sorry there is an obstacle in the way.'
        return True, ''+robot_name+': Sorry, I cannot go outside my safe zone.'


def do_back(robot_name, steps):
    """
    Moves the robot forward the number of steps
    :param robot_name:
    :param steps:
    :return: (True, forward output text)
    """

    global spud, is_obstructed

    spud.speed(1)
    if update_position(-steps):
        spud.bk(steps)
        return True, ' > '+robot_name+' moved back by '+str(steps)+' steps.'
    else:
        if is_obstructed == True:
            return True, ''+robot_name+'Sorry there is an obstacle in the way.'
       
        return True, ''+robot_name+': Sorry, I cannot go outside my safe zone.'

def do_right_turn(robot_name):
    """
    Do a 90 degree turn to the right
    :param robot_name:
    :return: (True, right turn output text)
    """
    global current_direction_index, spud

    current_direction_index += 1
    if current_direction_index > 3:
        current_direction_index = 0
        spud.rt(90)
    return True, ' > '+robot_name+' turned right.'


def do_left_turn(robot_name):
    """
    Do a 90 degree turn to the left
    :param robot_name:
    :return: (True, left turn output text)
    """
    global current_direction_index

    current_direction_index -= 1
    if current_direction_index < 0:
        current_direction_index = 3

    return True, ' > '+robot_name+' turned left.'


def show_position(robot_name):
    print(' > '+robot_name+' now at position ('+str(position_x)+','+str(position_y)+').')


def is_position_allowed(new_x, new_y):
    """
    Checks if the new position will still fall within the max area limit
    :param new_x: the new/proposed x position
    :param new_y: the new/proposed y position
    :return: True if allowed, i.e. it falls in the allowed area, else False
    """

    return min_x <= new_x <= max_x and min_y <= new_y <= max_y


def update_position(steps):
    """
    Update the current x and y positions given the current direction, and specific nr of steps
    :param steps:
    :return: True if the position was updated, else False
    """

    global position_x, position_y
    new_x = position_x
    new_y = position_y

    if directions[current_direction_index] == 'forward':
        new_y = new_y + steps
    elif directions[current_direction_index] == 'right':
        new_x = new_x + steps
    elif directions[current_direction_index] == 'back':
        new_y = new_y - steps
    elif directions[current_direction_index] == 'left':
        new_x = new_x - steps

    if is_position_allowed(new_x, new_y):
        position_x = new_x
        position_y = new_y
        spud.forward(steps)
        return True
    return False