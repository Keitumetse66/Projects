
import string
import re
def split(delimiters, text):
    """
    Splits a string using all the delimiters supplied as input string
    :param delimiters:
    :param text: string containing delimiters to use to split the string, e.g. `,;? `
    :return: a list of words from splitting text using the delimiters
    """

    import re
    regex_pattern = '|'.join(map(re.escape, delimiters))
    return re.split(regex_pattern, text, 0)


def convert_to_word_list(text):
    '''
    function that separates the sentance on commas, full stop, question mark in to list of word and turns the list to lowercase
    '''
    
    text_list = split(",.?; ", text)
    while '' in  text_list:
        text_list.remove('')
        
    newlist = list(map(lambda text: text.lower(), text_list))
    
    
    return newlist
    

def words_longer_than(length, text):
    '''
    this function filters the words on length and returns the filtered list
    '''
    text_list = convert_to_word_list (text)
    filtered_list = {}
    filtered_list = filter(lambda text: len(text) > length, text_list)
    filtered_list = list(filtered_list)
    
    return filtered_list
    

def words_lengths_map(text):
    '''
    function returns a dictionary that maps a word length to the number of word in the text of that length
    '''
    
    text_list = convert_to_word_list(text)
    counter = {}
    lengths = sorted(list(map(lambda word: len(word), text_list)))
    counter = {key:lengths.count(key) for key in lengths}
    
    return counter
    
    
    
def letters_count_map(text):
    '''
    this function returns a dictionary that maps each alphabet letter a to z to the number of
    times that letter occurs in the text
    '''
    
    
    letters = dict((map(lambda x : (x, text.lower().count(x)), string.ascii_lowercase)))
    
    
    return letters


def most_used_character(text):
    '''
    function reuses letters_count_map function to get the count of letters.
    reduce that to the letter that occurs the most, and returns that letter.
    for empty text "" it's returning None.
    '''
    if text == '':
        return None
    else:
        words = { x: key for key, x in letters_count_map(text).items()}
        most_used = words[max(letters_count_map(text).values())]
                           
        return most_used
                           
    
if __name__ == "__main__":
    print(convert_to_word_list('These are indeed interesting, an obvious understatement, times. What say you?'))

    print(words_longer_than(10, 'These are indeed interesting, an obvious understatement, times. What say you?'))

    print(words_lengths_map('These are indeed interesting, an obvious understatement, times. What say you?'))

    char_count = letters_count_map('These are indeed interesting, an obvious understatement, times. What say you?')
    print(char_count)