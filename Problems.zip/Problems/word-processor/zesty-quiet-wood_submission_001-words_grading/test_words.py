import word_processor
import unittest
class myTest(unittest.TestCase):
    def test_convert_to_word_list(self):
        data = "These are indeed interesting, an obvious understatement, times. What say you?"
        result = data.split(",.?; ")
        self.assertEqual(result, data.split(",.?; "))
        
    
    def test_words_longer_than(self):
        words = word_processor.words_longer_than(10, "These are indeed interesting, an obvious understatement, times. What say you?")
        longer_words = ['interesting','understatement']
        self.assertEqual(longer_words, words)
        
        
    def test_words_lengths_map(self):
        words = word_processor.words_lengths_map("These are indeed interesting, an obvious understatement, times. What say you?")
        results = {2: 1, 3: 3, 4: 1, 5: 2, 6: 1, 7: 1, 11: 1, 14: 1}
        self.assertEqual(results, words)
        
        
    def test_letters_count_map(self):
        words = word_processor.letters_count_map("These are indeed interesting, an obvious understatement, times. What say you?")
        results = {'a':5, 'b': 1, 'c':0, 'd': 3, 'e': 11, 'f': 0, 'g': 1, 'h': 2, 'i': 5, 'j': 0, 'k': 0, 'l': 0, 'm': 2, 'n': 6, 'o': 3, 'p': 0, 'q': 0, 'r': 3, 's': 6, 't': 8, 'u': 3, 'v': 1, 'w': 1, 'x': 0, 'y': 2, 'z': 0}
        self.assertEqual(results, words)
        
    def test_most_used_character(self):
        words = word_processor.most_used_character("These are indeed interesting, an obvious understatement, times. What say you?")
        results = "e"
        self.assertEqual(results, words)
        
        
    
        
    
        
     






if __name__ == '__main__':
    unittest.main()