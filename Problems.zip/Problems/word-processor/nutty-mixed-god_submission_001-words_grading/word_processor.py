import string
def split(delimiters, text):
    """
    Splits a string using all the delimiters supplied as input string
    :param delimiters:
    :param text: string containing delimiters to use to split the string, e.g. `,;? `
    :return: a list of words from splitting text using the delimiters
    """

    import re
    regex_pattern = '|'.join(map(re.escape, delimiters))
    return re.split(regex_pattern, text, 0)

def convert_to_word_list(text):
    '''cleaning the list to be in lower cases and removing panctuation '''
    strip_text = text.strip()
    lower_cases_text = strip_text.lower()
    punctuation = ' ,;?.'
    words_list = split(punctuation, lower_cases_text,)

    for word in words_list:
        if word == '': words_list.remove(word)
    return words_list      
    

def words_longer_than(length, text):
    '''Checking for the longest word in the list'''
    words_list = convert_to_word_list(text)
    long_words = []  
    for n in words_list: 
        if len(n) > length: long_words.append(n)   
    return long_words


def words_lengths_map(text):
    '''Function for checking for the the longest word in words'''
    my_list = convert_to_word_list(text)
    words_length = [len(word) for word in my_list if len(word) != 0]
    dict = {len(word):words_length.count(len(word)) for word in my_list}
    return dict 
    


def letters_count_map(text):
    '''Functiong for common letters in words in the list'''
    alphabets = string.ascii_lowercase
    text = text.lower()
    return {word:text.count(word) for word in alphabets}


def most_used_character(text):
    '''FUnction for mostly used letter'''
    if text == "":
     return
    new_dict = letters_count_map(text)
    most_used = max(new_dict, key = new_dict.get)
    return most_used



if __name__ == '__main__':
    text = 'param text: string containing delimiters to use to split the string'
    convert_to_word_list(text)
    words_longer_than(5, text)
    words_lengths_map(text)
    letters_count_map(text)
    most_used_character(text)