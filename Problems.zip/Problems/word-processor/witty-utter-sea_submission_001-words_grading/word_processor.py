import string
import re

def split(delimiters, text):
    """
    Splits a string using all the delimiters supplied as input string
    :param delimiters:
    :param text: string containing delimiters to use to split the string, e.g. `,;? `
    :return: a list of words from splitting text using the delimiters
    """
    regex_pattern = '|'.join(map(re.escape, delimiters))
    return re.split(regex_pattern, text, 0)

    
def convert_to_word_list(text):
    """the function converts a string into a list, using what the list contains"""
    marks = ",;?."
    the_string = "".join(alphabet for alphabet in  text if alphabet not in marks)
    the_split = (the_string.lower()).split()
    print(the_split)
    return the_split


def words_longer_than(length, text):
    """"handles number of words, then return words that matches the specified length"""
    my_list = []
    for iterm in convert_to_word_list(text):
        if len(iterm)>length:
            my_list.append(iterm)
    print(my_list)
    return my_list


def words_lengths_map(text):
    """the function maps the word in the string, and gives the number of how many times that length appears"""
    my_list = convert_to_word_list(text)
    word_list = list(map(lambda x: len(x), my_list))
    dictionery = {len(iterm):word_list.count(len(iterm)) for iterm in my_list}
    print(dictionery)
    return dictionery


def letters_count_map(text):
    """the function tells how many times an alphabet appears and maps it"""
    alphabets = string.ascii_lowercase
    marks = ",:?.;"
    the_string = "".join(alphabet.lower() for alphabet in text if alphabet not in marks)
    dictionery = {alphabet:the_string.count(alphabet) for alphabet in alphabets}
    print(dictionery)
    return dictionery   


def most_used_character(text):
    "the function returns the alphabet that is mostly used"
    highest = max(letters_count_map(text).keys(), key=letters_count_map(text).get)
    if text == "":
        return None
    print(highest)
    return highest
    

if __name__ == '__main__':
    texts = "These are indeed interesting, an obvious understatement, times. What say you?"
    convert_to_word_list(texts)
    words_longer_than(5,texts)
    words_lengths_map(texts)
    letters_count_map(texts)
    most_used_character(texts)
