print("[Module] Reconciliation loaded.")

def do_reconciliation():
    """
    prints provided information 
    """
    print("Doing bank reconciliation.")
    