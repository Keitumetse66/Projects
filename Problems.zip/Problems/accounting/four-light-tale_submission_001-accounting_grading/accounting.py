# #TODO
# import sys
# import banking
# terms = sys.argv

# for i in terms[1:]:
#     print(i)

import user.authentication as authentication
import transactions.journal as journal
from banking import *

import sys
import banking
terms = sys.argv

for i in terms[1:]:
    print(i)



if __name__ == "__main__":
    authentication.authenticate_user()
    journal.receive_income(100)
    journal.pay_expense(100)
    banking.reconciliation.do_reconciliation()
    # reconciliation.do_reconciliation()
    # fvb_reconciliation.do_reconciliation()
    # ubsa_reconciliation.do_reconciliation()