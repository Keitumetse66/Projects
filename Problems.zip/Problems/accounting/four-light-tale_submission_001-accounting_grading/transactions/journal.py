

print("[Module] Journal loaded.")


def receive_income(amount):
    """
    prints amount received and cents in 2 decimal places 
    """
    print("[Journal] Received R"+format(amount,".2f"))


def pay_expense(amount):
    """
    prints amount paid
    """
    print("[Journal] Paid R"+format(amount,".2f"))
