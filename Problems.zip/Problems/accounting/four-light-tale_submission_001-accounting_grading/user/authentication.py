# from ..accounting import authenticate_user  # import accounting as accounting # import accounting
# print("[Module] User Authentication loaded.")

print("[Module] User Authentication loaded.")

def authenticate_user():
    print("Authenticating User")
    return True

