def authenticate_user():
    print("Authenticating User")
    return True

print('[Module] User Authentication loaded.')
