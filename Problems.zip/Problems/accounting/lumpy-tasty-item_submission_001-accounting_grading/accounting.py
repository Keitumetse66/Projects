import user.authentication as authentication
import transactions.journal as journal
# import banking.reconciliation as reconciliation
from __init__  import *
import banking.fvb.reconciliation as reconciliation
# import banking.ubsa.reconciliation as reconciliation
# import banking.online.reconciliation as reconciliation
import sys




if __name__ == '__main__':
    if len(sys.argv) > 2:
        for item in range(1, len(sys.argv)):
            print(sys.argv[item])
    authentication.authenticate_user()
    journal.receive_income(100)
    journal.pay_expense(100)
    reconciliation.do_reconciliation()
    # reconciliation.do_reconciliation()
    # reconciliation.do_reconciliation()
    # reconciliation.do_reconciliation()
    

    

