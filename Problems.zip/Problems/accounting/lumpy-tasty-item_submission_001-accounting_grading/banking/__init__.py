print("[Package] Banking package loaded.")
# print("[Module] Reconciliation loaded.")
import banking.fvb.reconciliation as reconciliation

# def do_reconciliation():
#     print("Doing First Virtual Bank reconciliation.")
# if __name__ == '__main__':
#     reconciliation.do_reconciliation()