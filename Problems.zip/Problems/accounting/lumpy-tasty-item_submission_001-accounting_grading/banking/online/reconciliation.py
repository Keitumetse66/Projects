
import sys
from os.path import dirname
from urllib import request
sys.path.append(dirname('/home/wethinkcode/.local/lib/python3.10/site-packages/requests'))

import requests

print("[Module] online.Reconciliation loaded.")
def do_reconciliation():
    print("Doing Online Bank reconciliation.")
    response = requests.get('https://www.wethinkcode.co.za')
    print(response.status_code)
