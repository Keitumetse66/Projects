print("[Module] Journal loaded.")

def receive_income(amount):
    print(f'[Journal] Received R{amount:.2f}')

def pay_expense(amount):
    print(f'[Journal] Paid R{amount:.2f}')