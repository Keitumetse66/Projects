
def find_min(element):
    """TODO: complete for Step 1"""
   
    if len(element) == 0 or any (not isinstance(i, int) for i in element):
        return -1
    elif len(element) == 1:
        return element[0]
    elif element[0]> element[1]:
        element.remove(element[0])
    else:
        element.remove(element[1])
    return find_min(element)    
    

def sum_all(element):
    """TODO: complete for Step 2"""

    if len(element) == 0 or any (not isinstance(i, int) for i in element):
        return -1
    elif len(element) == 1:
        return element [0]
    else:
        element[0] = element[0] + element[-1]
        element.pop()
    return sum_all(element)
    
    

def find_possible_strings(character_set, n):
    """TODO: complete for Step 3"""
    if len(character_set) == 0 or any (not isinstance(i, str) for i in character_set):
        return []
    lst = []
    k = len(character_set)
    return possible_stringsRec(character_set, "", k, n, lst)


def possible_stringsRec(char_set, prefix, k, n, lst):

    
    if n == 0:
        
        lst.append(prefix)
        return 
        
    
    for i in range(k):
        newPrefix = prefix + char_set[i]
        possible_stringsRec(char_set, newPrefix, k, n - 1, lst)

    return lst
# char_set = ['a','b','c']
# possible_strings = find_possible_strings(char_set, len(char_set),3)
# print(possible_strings) # prints our result: a, b, c
    

    #pass


if __name__ == "__main__":
    print(find_possible_strings(["a", "b", "c", "d"], 1))