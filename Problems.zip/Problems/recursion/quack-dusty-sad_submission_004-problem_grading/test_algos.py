import unittest
import random
import sys
from test_base import run_unittests
import super_algos

class TestAlgos(unittest.TestCase):
    
    def test_find_min(self):
        my_list = [2,8,3,9]
        min_value = super_algos.find_min(my_list)
        self.assertIsInstance(min_value, int)
        result = super_algos.find_min(my_list)
        self.assertEqual(result, 2)
        my_list = [True, 2.5, "food"]
        self.assertEqual(super_algos.find_min(my_list), -1)
        
    def test_sum_all(self):
        result = super_algos.sum_all([3,5,7,9,4])
        self.assertEqual(result, 28)
        result = super_algos.sum_all([])
        self.assertEqual(result, -1)
        
    def test_find_possible_strings(self):
        result = super_algos.find_possible_strings(['a','b'], 2)
        self.assertEqual(result, ['aa','ab','ba','bb'])
        result = super_algos.find_possible_strings(['x','y'], 3)
        self.assertEqual(result, ['xxx','xxy','xyx','xyy','yxx','yxy','yyx','yyy'])
        result = super_algos.find_possible_strings([], 3)
        self.assertEqual(result,[])
        result = super_algos.find_possible_strings([1,2,3,4], 3)
        self.assertEqual(result, [])
        
    