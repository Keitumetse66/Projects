# element = [3,4,6,8,-1]
    # print(find_min(element))

def find_min(element):
    """This function identifies as well as assigns the least amount of each element in a list of integers. """
    
    #if len(element) == 0 or not all(isinstance(i,int) for i in element):
        #return -1

    for i in element:
        if type(i) != int:
            return -1

    if len(element) == 0:
        return -1

    if len(element) == 1:
        return element[0]

    if element[0] > element[1]:
        element.pop(0)
        return find_min(element)

    else:
        element[0] < element[1]
        element.pop(1)
        return find_min(element)
              


def sum_all(element):
    """This function called sum all(elements) computes and returns the total of every element in a list of integers. """

    #if len(element) == 0 or not all(isinstance(i,int) for i in element):
        #return -1

    for i in element:
        if type(i) != int:
            return -1
    if len(element) == 0:
        return -1

    elif len(element)== 1:
        return element[0]
    else:
        return element[0] + sum_all(element[1:])
        


def find_possible_strings(character_set, n):
    """This function prints every n-character string that can be created with the supplied set. """

    k = len(character_set)
    return possible_stringsRec(character_set, "", k, n, list__ = [])

def possible_stringsRec(character_set, prefix, k, n,list__):
    for i in character_set:
        if type(i) != str:
            return []
    if n == 0:
        list__.append(prefix)
        return list__
    
    for i in range(k):
        newPrefix = prefix + character_set[i]
        possible_stringsRec(character_set, newPrefix, k, n - 1, list__)
    return list__

if __name__ =="__main__":

    lis_1 = [2,5,8,3,10,3]
    print(find_min(lis_1))

    lis_2 =[1,2,3,4,5]
    print(sum_all(lis_2))

    character_set = ['a','b','c']
    possible_strings = find_possible_strings(character_set, 3)
    print(possible_strings)


    


