import unittest
import super_algos

class MyTestCase(unittest.TestCase):
    def test_find_min(self):
        lis_1 = [2,5,8,3,10,3]
        self.assertTrue(type(super_algos.find_min(lis_1)), int)
        self.assertEqual(super_algos.find_min([]),-1)
        self.assertEqual(super_algos.find_min([2,5,8,3,10,3, '']),-1)
        self.assertEqual(super_algos.find_min([1]),1)

    
    def test_sum_all(self):
        lis_2 = [1,2,3,4,5]
        self.assertTrue(type(super_algos.sum_all(lis_2)), int)
        self.assertEqual(super_algos.sum_all([1]),1)
        self.assertEqual(super_algos.sum_all([1,2,3,4,5,'']),-1)
        self.assertEqual(super_algos.sum_all([]),-1)
       

       
    def test_find_possible_strings(self):
        character_set = ["a","b","c", 3]
        self.assertEqual(super_algos.find_possible_strings(character_set,2), [])
        

if __name__=='__main__':
    unittest.main()