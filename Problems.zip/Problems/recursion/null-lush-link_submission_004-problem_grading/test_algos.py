import unittest
import sys
import super_algos

class TestFunctions(unittest.TestCase):
   def test_find_min(self):
      # Tests if 'find_min' returns -1 when the 'element' parameter contains invalid elements.
      self.assertEqual(super_algos.find_min(['a',100,'b',4,-5]), -1)
      self.assertEqual(super_algos.find_min([]), -1)

      # Tests if 'find_min' returns the minimum element in a list of integers.
      self.assertEqual(super_algos.find_min([3,5,6,1,10]), min([3,5,6,1,10]))
      self.assertEqual(super_algos.find_min([3,100,-101,4,-5]), min([3,100,-101,4,-5]))
      self.assertEqual(super_algos.find_min([3]), min([3]))

   def test_sum_all(self):
      # Tests if 'sum_all' returns -1 when the 'element' parameter contains invalid elements.
      self.assertEqual(super_algos.sum_all(['a',100,'b',4,-5]), -1)
      self.assertEqual(super_algos.sum_all([]), -1)

      # Tests if 'sum_all' returns the sum of all elements in a list of integers.
      self.assertEqual(super_algos.sum_all([1,2,3,4,5]), sum([1,2,3,4,5]))
      self.assertEqual(super_algos.sum_all([-1,-2,-3]), sum([-1,-2,-3]))
      self.assertEqual(super_algos.sum_all([3]), sum([3]))

   def test_find_possible_strings(self):
      # Tests if 'find_possible_strings' returns all possible strings of length n that can be formed from a given set.
      result = super_algos.find_possible_strings(['a','b','c','d'], 1)
      self.assertEqual(['a','b','c','d'], result)

      result = super_algos.find_possible_strings(['a','b'], 3)
      self.assertEqual(['aaa', 'aab', 'aba', 'abb', 'baa', 'bab', 'bba', 'bbb'], result)

      # Tests if 'find_possible_strings' returns [] when the 'char_set' parameter contains invalid elements.
      result = super_algos.find_possible_strings([], 3)
      self.assertEqual([], result)

      result = super_algos.find_possible_strings([1,2,3,4], 3)
      self.assertEqual([], result)


if __name__ == '__main__':
    sys.stdout = StringIO()
    unittest.main()