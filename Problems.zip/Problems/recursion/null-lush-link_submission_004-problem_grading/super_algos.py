
def find_min(element):
    """
    Finds and returns the minimum element in a list of integers.

    Parameters
    ----------
    element : list
        list of integers
    """

    if not isinstance(element, list):
        element = list(element)
    
    for item in element:
        if not isinstance(item, int):
            return -1

    if len(element) == 0:
        return -1
    elif len(element) == 1:
        return element[0]
    else:
        min_num = find_min(element[1:])
        num = element[0]
        if num < min_num:
            min_num = num
        return min_num


def sum_all(element):
    """
    Calculates and returns the sum of all elements in a list of integers.

    Parameters
    ----------
    element : list
        list of integers
    """

    if not isinstance(element, list):
            element = list(element)
        
    for item in element:
        if not isinstance(item, int):
            return -1

    if len(element) == 0:
        return -1
    elif len(element) == 1:
        return element[0]
    else:
        total = sum_all(element[1:])
        num2 = element[0]
        total += num2
        return total


def find_possible_strings(char_set, n):
    """
    Checks for correctness and returns all possible strings of length n
    that can be formed from a given set.

    Parameters
    ----------
    char_set : list
        list of characters
    n : int
        length that each possible string should be
    """

    if not isinstance(char_set, list):
            char_set = list(char_set)

    if len(char_set) == 0:
        return []

    for element in char_set:
        if not isinstance(element, str):
            return []

    k = len(char_set)
    return possible_stringsRec(char_set, "", k, n, [])

def possible_stringsRec(char_set, prefix, k, n, possible_strings):
    """
    Returns all possible strings of length n that can be formed from a given set.

    Parameters
    ----------
    char_set : list
        list of characters
    prefix : str
        preceding character(s) of possible strings
    k : int
        length of char_set
    n : int
        length that each possible string should be
    possible_strings : list
        list of possible strings
    """

    if n == 0:
        possible_strings.append(prefix)
        return possible_strings

    for i in range(k):
        newPrefix = prefix + char_set[i]
        possible_stringsRec(char_set, newPrefix, k, n - 1, possible_strings)

    return possible_strings