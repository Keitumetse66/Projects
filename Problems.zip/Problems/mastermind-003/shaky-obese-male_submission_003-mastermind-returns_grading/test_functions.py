import unittest
from mastermind import *
from io import StringIO
from unittest.mock import patch
import sys

class TestFunctions(unittest.TestCase):
    def test_step2(self):
        for x in range(100):
            code = create_code()
            self.assertEqual(len(code),4)
        for y in code:
            self.assertIn(len(code),range(1,8))
    

    def test_step3(self):
        self.assertTrue(check_correctness(12,4))
        self.assertFalse(check_correctness(11,3))


    @patch("sys.stdin", StringIO("123\n1234\n"))
    def test_step4(self):
        input = get_answer_input()
        self.assertEqual(input,"1234")



    @patch("sys.stdin", StringIO("123\n5678\n"))
    def test_step5(self):
        code = [5, 6, 7 ,8]
        answer = '5678'
        self.assertEqual(take_turn(code,answer),(4,0))
     

sys.stdout= StringIO()
    
                                                                                                                                                                                                                                                                                                                                                                                      
if __name__ == '__main__':
    unittest.main()

