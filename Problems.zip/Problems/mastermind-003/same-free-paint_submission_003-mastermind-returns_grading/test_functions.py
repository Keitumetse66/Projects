
import unittest 
import mastermind as m_mind  
import io 
import sys
from unittest.mock import patch 
from io import StringIO  
from test_base import captured_io


class test_mastermind_functions(unittest.TestCase):
    def test_create_code(self): 
        suppress_text=io.StringIO()
        sys.stdout=suppress_text
        for i in range(100):
            self.assertTrue(len(m_mind.create_code())==4)
            self.assertTrue([i for i in m_mind.create_code()],range(1,9)) 

    sys.stdout=sys.__stdout__


    def test_check_correctness(self):
        suppress_text=io.StringIO()
        sys.stdout=suppress_text
        self.assertTrue(m_mind.check_correctness(4,2))
        self.assertFalse(m_mind.check_correctness(1,7))

    sys.stdout=sys.__stdout__  


    @patch("sys.stdin",StringIO("1234567\n123\n1234"))
    def test_get_answer_input(self): 
        suppress_text=io.StringIO()
        sys.stdout=suppress_text

        self.assertEqual(m_mind.get_answer_input(),"1234")
    sys.stdout=sys.__stdout__

    
    @patch("sys.stdin",StringIO("1875\n2685\n3542"))
    def test_take_turn(self): 
        suppress_text=io.StringIO()
        sys.stdout=suppress_text
        code=[3,5,4,2] 
        

        self.assertEqual(m_mind.take_turn(code),(0,1))
        self.assertEqual(m_mind.take_turn(code),(0,2)) 
        self.assertEqual(m_mind.take_turn(code),(4,0)) 
    sys.stdout=sys.__stdout__


    def test_show_instructions(self):
        
        with patch("sys.stdout",StringIO())  as out:
            m_mind.show_instructions() 
        text=out.getvalue().strip()
        self.assertEqual(text,'4-digit Code has been set. Digits in range 1 to 8. You have 12 turns to break it.') 


    def test_show_code(self):
        with patch("sys.stdout",StringIO())  as out:
            code=[2,5,4,7]
            m_mind.show_code(code) 
        text=out.getvalue().strip()
        self.assertEqual(text,'The code was: '+str(code))


if __name__=="__main__":
    unittest.main()