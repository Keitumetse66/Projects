

# TODO: Step 1 - get shape (it can't be blank and must be a valid shape!)

def get_shape():
    shape_param = input("Shape?: ").lower()
    shapes = ["pyramid" , "square" , "triangle", "x-men", "trap house", "medicross"]
    if shape_param in shapes:
        return shape_param
    else:
        while shape_param not in shapes:
            return get_shape()

    
    # if shape_param == "pyramid":
    #     return shape_param
    # elif shape_param == "square":
    #     return shape_param
    # elif shape_param == "triangle":
    #     return shape_param
    # return shape_param
    

# TODO: Step 1 - get height (it must be int!)
def get_height():
    
    # global height_input
    
    height_input = input("Height?: ")
    if height_input.isdigit() == True:
        height = int(height_input)
    else:
        return get_height()
    # except ValueError:
    #     return get_height()
    while height > 80:
        return get_height()
    if height <= 80:
        return height
    pass
#TODO: Step 2
def draw_pyramid(height, outline):
    if outline == True:
        for i in range(0,height):
            for j in range(height-i-1):
                print(" ", end = "")
            for j in range(i*2 +1):
                if j == 0 or i == height -1 or j == (i*2): #or i + 1 == j -1: # or j ==2* height: #or j == height - 1: #or i == j +1 and j -1 == i+1:
                    print("*", end="")
                else:
                    print(" ", end= "")
            print() 
    else:
        for i in range(0,height):
            for j in range(0,height-i-1): #why are we subtracting the outline and 1
                print(" ", end = "")
            for j in range(0, i*2 +1):
                print("*", end="")
            print() #print(end = "\n")
        return draw_pyramid

#TODO: Step 3
def draw_square(height, outline):
    if outline == True:
        for i in range(0, height):
            for j in range(0, height):
                if i == 0 or i==(height-1) or j == 0 or j ==(height-1):
                    print("*",end="")
                else:
                    print(" ", end="")
            print()
    else:
        for i in range(0, height):
            for j in range(0, height):
                print("*", end="")
            print()
        return draw_square

# TODO: Step 4
def draw_triangle(height, outline):
    if outline == True:
        for i in range(0, height):
            for j in range(0, i+1):
                if i==(height-1) or j == 0 or i == j:
                    print("*", end="")
                else:
                    print(" ", end="")
            print()
    else:
        for i in range(0, height):
            print((i+1)*"*")
        return draw_triangle

# TODO: Steps 2 to 4, 6 - add support for other shapes
def draw(shape, height, outline):
    if shape == "x-men":
        draw_xmen(height, outline)
    if shape == "trap house":
        draw_trap_house(height, outline)
    if shape == "medicross":
        draw_medicross(height, outline)
    if shape == "pyramid":
        draw_pyramid(height, outline)
    if shape == "square":
        draw_square(height, outline)
    if shape == "triangle":
        draw_triangle(height, outline)
        
    #x-men
def draw_xmen(height, outline):
    if shape_param == "x-men" and outline == True:
        for i in range(0, height):
            for j in range(0, height):
                if i+j != height-1 and i != j:
                    print("*", end = " ")
                else:
                    print(" ", end = " ")
            print()
        
    else:
        for i in range(0, height):
            for j in range(0, height):
                if i+j == height-1 or i == j:
                    print("*", end = " ")
                else:
                    print(" ", end = " ")
            print()
    #medicross

def draw_medicross(height, outline):
    if shape_param == "medicross" and outline == False:
        for i in range(0, height):
            for j in range(0, height):
                if i == height//2 or j == height//2:
                    print("*", end =" ")
                else:
                    print(" ", end = " ")
            print()
    else:
        for i in range(0, height):
            for j in range(0, height):
                if i != height//2 and j != height//2:
                    print("*", end =" ")
                else:
                    print(" ", end = " ")
            print()

    #trap house
def draw_trap_house(height, outline):
    if shape_param == "trap house" and outline == False:
        for i in range(0,height):
            for j in range(0,height-i-1): #why are we subtracting the outline and 1
                print(" ", end = "")
            for j in range(0, i*2 +1):
                print("*", end="")
            print()
        for a in range(0, height):
            for b in range(0, height//3-1):
                print(" ", end="")
            for b in range(0,i*2+1):
                print("*", end="")
            print()
        return draw_trap_house()
    #trap outline
    else:
        for i in range(0,height):
            for j in range(height-i-1):
                print(" ", end = "")
            for j in range(i*2 +1):
                if j == 0 or i == height -1 or j == (i*2): #or i + 1 == j -1: # or j ==2* height: #or j == height - 1: #or i == j +1 and j -1 == i+1:
                    print("*", end="")
                else:
                    print(" ", end= "")
            print()
    
        for a in range(0, height):
            for b in range(0, height//3):
                for b in range(0,i*2+1):
                    if a==(height-1) or b == 0 or b ==((height-1)*2):
                        print("*", end="")
                    else:
                        print(" ", end="")
            print()

# def outline(height, outline):
    
    #pyramid outline
    # if shape_param == "pyramid" and outline == True:
    #     for i in range(0,height):
    #         for j in range(height-i-1):
    #             print(" ", end = "")
    #         for j in range(i*2 +1):
    #             if j == 0 or i == height -1 or j == (i*2): #or i + 1 == j -1: # or j ==2* height: #or j == height - 1: #or i == j +1 and j -1 == i+1:
    #                 print(j, end="")
    #             else:
    #                 print(j, end= "")
    #     print() 
    #     return draw_pyramid()

    #square outline 
    # if shape_param == "sqaure" and outline == True:
    #     for i in range(0, height):
    #         for j in range(0, height):
    #             if i == 0 or i==(height-1) or j == 0 or j ==(height-1):
    #                 print("*",end="")
    #             else:
    #                 print(" ", end="")
    #         print()
    #     return draw_square()
    
    #triangle outline
    # if shape_param == "triangle" and outline == True:
    #     for i in range(0, height):
    #         for j in range(0, height):
    #             if (i == 0 and j == 0) or i==(height-1) or j == 0 or i == j:
    #                 print("*", end="")
    #         else:
    #             print(" ", end="")
    #     print()
    # return draw_triangle()
    # if shape_param == "square" print(draw_square)


# TODO: Step 5 - get input from user to draw outline or solid
def get_outline():
    outline = input("Outline only? (y/N): ").lower()
    if outline == "y":
        return True
    else:
        return False


if __name__ == "__main__":
    shape_param = get_shape()
    height_param = get_height()
    outline_param = get_outline()
    draw(shape_param, height_param, outline_param)

