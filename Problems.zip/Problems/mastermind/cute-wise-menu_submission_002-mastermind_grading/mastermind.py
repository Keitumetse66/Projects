import random


def run_game():
    """
    TODO: implement Mastermind code here
    """
    number_list = []
   
    while len(number_list) != 4:
        numbers = random.randint(1,8)
        if numbers in number_list:
            continue
        number_list.append(numbers)
            
    number_list = [str(i) for i in number_list]
        
    turns = 12
    print("4-digit Code has been set. Digits in range 1 to 8. You have 12 turns to break it.")
    
    while turns != 0:
        correct = 0
        incorrect = 0
        guess = input("Input 4 digit code: ")
        if not guess.isdigit() or len(guess) != 4 or "0" in guess or "9" in guess:
                print("Please enter exactly 4 digits.")
                continue
   
        for i in range(len(number_list)):
            for x in range(len(guess)):
                if guess[i] == number_list[x] and x == i:
                    correct += 1
                elif guess[i] == number_list[x] and x != i:
                    incorrect += 1
        if guess != number_list:
            turns -= 1

        print(f"Number of correct digits in correct place:     {correct}")
        print(f"Number of correct digits not in correct place: {incorrect}")
        
        if correct == 4:
            print(f"Congratulations! You are a codebreaker!")
            print(f"The code was: {guess}")
            break
        if correct != 4:
            print(f"Turns left: {turns}")
if __name__ == "__main__":
    run_game()
