import random
def run_game():
    guess_list1= set()
    
    while len(guess_list1) <4 :
        i = random.randint(1,8)
        if i not in guess_list1:
            guess_list1.add(i)
        
        guess_list=list(guess_list1)
        guess_list =[str(x) for x in guess_list1]
    print ("4-digit Code has been set. Digits in range 1 to 8. You have 12 turns to break it.")
    count = 12
    while count != 0:
        correct_position = 0
        incorrect_position = 0
        user_guess=input("Input 4 digit code: ")
        if user_guess.isdigit()== False or len(user_guess) !=4 or "0" in user_guess or "9" in user_guess:
            print("Please enter exactly 4 digits.")
        elif len(user_guess)== 4 and user_guess.isdigit()== True:
        

            user_guess=list(user_guess)
            x =[str(x) for x in user_guess]
         
            for i in range(len(user_guess)):
                if user_guess[i] in guess_list and user_guess[i] == guess_list[i]:
                    correct_position = correct_position +1
                elif user_guess[i] in guess_list and user_guess[i] != guess_list[i]:   
                    incorrect_position = incorrect_position +1


            print(f'Number of correct digits in correct place:     {correct_position}' )
            print(f'Number of correct digits not in correct place: {incorrect_position}')

            if user_guess == guess_list:
                 print("Congratulations! You are a codebreaker!")
                 print(f'The code was: {"".join(guess_list)}')
                 break

            
            count = count -1
            print(f"Turns left: {count}")
            if count == 0:
                break 
            


if __name__ == "__main__":
    run_game()
