import random


def run_game():
    number = 4
    number_code = "".join(["{}".format(random.randint(1, 8)) for num in range(number)])
    print("4-digit Code has been set. Digits in range 1 to 8. You have 12 turns to break it.")


    number_of_tries = 12        
    while number_of_tries != 0:
        count = 0
        number_code = str(number_code)
        count2 = 0

        guesses = input("Input 4 digit code: ")
        while len(guesses) != 4 or not guesses.isdigit():
           print("Please enter exactly 4 digits.")

           guesses = input("Input 4 digit code: ")

        for i in range(0, 4):
            if (guesses[i] == number_code[i]):
                count += 1   
                               
            elif guesses[i] in number_code and guesses[i] != number_code[i]:
                count2 += 1

            if i == 3:   
                number_of_tries -= 1


        if guesses == number_code:
            print(f"Number of correct digits in correct place:     {count}")
            print(f"Number of correct digits not in correct place: {count2}")
            print("Congratulations! You are a codebreaker!")
            print(f"The code was: {str(number_code)}")  
            break
          

        if (count < 4):
            print(f"Number of correct digits in correct place:     {count}")
            print(f"Number of correct digits not in correct place: {count2}")
            print("Turns left:", number_of_tries)        






if __name__ == "__main__":
    run_game()