

def position_tracking():
    y_pos, x_pos, degrees = 0, 0, 0

    return y_pos, x_pos, degrees

def name_the_robot():
    """Funtion get the robot name from the user"""

    robot_name = input('What do you want to name your robot? ')
    print(f'{robot_name}: Hello kiddo!')
    return robot_name

#----------------------------------------------------------------------------------------------

def valid_commands():
    """Function returns robot commands"""

    return ['OFF', 'HELP', 'FORWARD', 'BACK', 'RIGHT', 'LEFT', 'SPRINT']

#----------------------------------------------------------------------------------------------

def command_info():
    """Function returns -HELP- info"""

    help_info ='''I can understand these commands:
OFF  - Shut down robot
HELP - provide information about commands
FORWARD - Moves robot forward
BACK - Moves robot backward
RIGHT - Turns robot right
LEFT - Turns robot left
SPRINT - Sprints the robot'''

    return print(help_info)

#----------------------------------------------------------------------------------------------

def move_forward(robot_name, steps, y_pos, x_pos):
    """Function directs the robot to move forward"""
    # global y_pos,x_pos

    y_pos += int(steps)
    print(f' > {robot_name} moved forward by {steps} steps.')
    print(f' > {robot_name} now at position ({x_pos},{y_pos}).')

    return y_pos, x_pos

#----------------------------------------------------------------------------------------------

def move_back(robot_name, steps, y_pos, x_pos):
    """Function directs the robot to move backward"""

    y_pos -= int(steps)
    print(f' > {robot_name} moved back by {steps} steps.')
    print(f' > {robot_name} now at position ({x_pos},{y_pos}).')

    return y_pos, x_pos

#----------------------------------------------------------------------------------------------

def turn_right(robot_name, y_pos, x_pos):
    """Function directs the robot to turn right"""
    # global x_pos, y_pos

    print(f' > {robot_name} turned right.')
    print(f' > {robot_name} now at position ({x_pos},{y_pos}).')

    return y_pos, x_pos

#----------------------------------------------------------------------------------------------

def turn_left(robot_name, y_pos, x_pos):
    """Function directs the robot to turn left"""

    print(f' > {robot_name} turned left.')
    print(f' > {robot_name} now at position ({x_pos},{y_pos}).')

    return y_pos, x_pos

#----------------------------------------------------------------------------------------------

def forward_movement(robot_name, steps, y_pos, x_pos, degrees):
    """
        Function checks the direction in which the robot needs to move
        User - forward 45
        robot - moved 45 degrees forward
    """
    # global x_pos, y_pos,degrees

    if degrees == 0:
        # y - increment the Y-axis
        y_pos, x_pos = move_forward(robot_name, steps, y_pos, x_pos)
    elif degrees == 90:# or degrees == 270:
        # x - increment the X-axis
        x_pos += int(steps)
        print(f' > {robot_name} moved forward by {steps} steps.')
        print(f' > {robot_name} now at position ({x_pos},{y_pos}).')
    elif degrees == 180:# or degrees == 360:
        # y - decrement the Y-axis
        y_pos -= int(steps)
        print(f' > {robot_name} moved forward by {steps} steps.')
        print(f' > {robot_name} now at position ({x_pos},{y_pos}).')
    elif degrees == 270:
        # x - increment the X-axis
        x_pos -= int(steps)
        print(f' > {robot_name} moved back by {steps} steps.')
        print(f' > {robot_name} now at position ({x_pos},{y_pos}).')
    elif degrees >= 360:
        # y - decrement the Y-axis
        y_pos += int(steps)
        print(f' > {robot_name} moved back by {steps} steps.')
        print(f' > {robot_name} now at position ({x_pos},{y_pos}).')

    return y_pos, x_pos, degrees

#----------------------------------------------------------------------------------------------

def back_movement(robot_name, steps, y_pos, x_pos, degrees):
    """
        Function checks the direction in which the robot needs to move
        User - back 3
        robot - moved 3 degrees backward
    """

    if degrees== 0:
        # y - decrement the X-axis
        y_pos, x_pos = move_back(robot_name, steps, y_pos, x_pos)
    elif degrees == 90:
        # x - decrement the X-axis
        x_pos -= int(steps)
        print(f' > {robot_name} moved back by {steps} steps.')
        print(f' > {robot_name} now at position ({x_pos},{y_pos}).')
    elif degrees == 270:
        # x - increment the X-axis
        x_pos += int(steps)
        print(f' > {robot_name} moved back by {steps} steps.')
        print(f' > {robot_name} now at position ({x_pos},{y_pos}).')
    elif degrees == 180:# or degrees == 360:
        # y - increment the Y-axis
        y_pos += int(steps)

        print(f' > {robot_name} moved back by {steps} steps.')
        print(f' > {robot_name} now at position ({x_pos},{y_pos}).')
    elif degrees >= 360:
        # y - decrement the Y-axis
        y_pos -= int(steps)
        print(f' > {robot_name} moved back by {steps} steps.')
        print(f' > {robot_name} now at position ({x_pos},{y_pos}).')
    
    return y_pos, x_pos, degrees

#----------------------------------------------------------------------------------------------

def forward_inverse_movement(robot_name, steps, y_pos, x_pos, degrees):
    """
        Function checks the direction in which the robot needs to move
        User - left
             - forward 45
        robot - turned left
              - moved 45 degrees forward
    """

    if degrees == 0:
        # y - increment the X-axis
        y_pos, x_pos, degrees = move_forward(robot_name, steps, y_pos, x_pos)
    elif degrees == -90:# or degrees == -270:
        # x - decrement the X-axis
        x_pos -= int(steps)
        print(f' > {robot_name} moved forward by {steps} steps.')
        print(f' > {robot_name} now at position ({x_pos},{y_pos}).')
    elif degrees == -180:# or degrees == -360:
        # y - decrement the Y-axis
        y_pos -= int(steps)
        print(f' > {robot_name} moved forward by {steps} steps.')
        print(f' > {robot_name} now at position ({x_pos},{y_pos}).')
    elif degrees == -270:
        # x - decrement the X-axis
        x_pos -= int(steps)
        print(f' > {robot_name} moved back by {steps} steps.')
        print(f' > {robot_name} now at position ({x_pos},{y_pos}).')
    elif degrees >= -360:
        # y - decrement the Y-axis
        y_pos -= int(steps)
        print(f' > {robot_name} moved back by {steps} steps.')
        print(f' > {robot_name} now at position ({x_pos},{y_pos}).')
    
    return y_pos, x_pos, degrees

#----------------------------------------------------------------------------------------------

def back_inverse_movement(robot_name, steps, y_pos, x_pos, degrees):
    """
        Function checks the direction in which the robot needs to move
        User - right
             - back 25
        robot - turned right
              - moved 25 degrees forward
    """

    if degrees == 0:
        # y - decrement the Y-axis
        y_pos, x_pos, degrees = move_back(robot_name, steps, y_pos, x_pos)
    elif degrees == -90:
        # x - increment the X-axis
        x_pos += int(steps)
        print(f' > {robot_name} moved back by {steps} steps.')
        print(f' > {robot_name} now at position ({x_pos},{y_pos}).')
    elif degrees == -180:
        # y - increment the Y-axis
        y_pos += int(steps)
        print(f' > {robot_name} moved back by {steps} steps.')
        print(f' > {robot_name} now at position ({x_pos},{y_pos}).')
    elif degrees == -270:
        # x - decrement the X-axis
        x_pos -= int(steps)
        print(f' > {robot_name} moved back by {steps} steps.')
        print(f' > {robot_name} now at position ({x_pos},{y_pos}).')
    elif degrees >= -360:
        # y - decrement the Y-axis
        y_pos -= int(steps)
        print(f' > {robot_name} moved back by {steps} steps.')
        print(f' > {robot_name} now at position ({x_pos},{y_pos}).')
    
    return y_pos, x_pos, degrees

#----------------------------------------------------------------------------------------------

def sprint_robot(robot_name, steps):
    
    if steps <= 0:
        return 0
    else:
        print(f' > {robot_name} moved forward by {steps} steps.')
    return steps + sprint_robot(robot_name, steps - 1)

#----------------------------------------------------------------------------------------------

def get_command_input(robot_name, commands, y_pos, x_pos, degrees):
    """Function gets and validates the user input"""
    
    user_input = input(f'{robot_name}: What must I do next? ')
    user_command = user_input.upper().split()
    
    if user_command[0] in commands:
        if user_command[0] == 'OFF':

            switch_off = False
            print(f'{robot_name}: Shutting down..')
            return switch_off, switch_off, switch_off
        elif user_command[0] == 'HELP':
            command_info()
        elif user_command[0] == 'FORWARD':
            if degrees < (0):
                if int(user_command[1]) >= 100 or int(user_command[1]) <= -100:
                    print(f'{robot_name}: Sorry, I cannot go outside my safe zone.')
                    print(f' > {robot_name} now at position ({x_pos},{y_pos}).')
                    return get_command_input(robot_name, commands, y_pos, x_pos, degrees) 
                else:
                    y_pos, x_pos, degrees = forward_inverse_movement(robot_name, user_command[1], y_pos, x_pos, degrees)
            elif degrees >= (0):
                if int(user_command[1]) >= 200 or int(user_command[1]) <= -200:
                    print(f'{robot_name}: Sorry, I cannot go outside my safe zone.')
                    print(f' > {robot_name} now at position ({x_pos},{y_pos}).')
                    return get_command_input(robot_name, commands, y_pos, x_pos, degrees) 
                else:
                    y_pos, x_pos, degrees = forward_movement(robot_name, user_command[1], y_pos, x_pos, degrees)
                    return get_command_input(robot_name, commands, y_pos, x_pos, degrees)
        elif user_command[0] == 'BACK':
            if degrees < (0 ):
                if int(user_command[1]) >= 100 or int(user_command[1]) <= -100:
                    print(f'{robot_name}: Sorry, I cannot go outside my safe zone.')
                    print(f' > {robot_name} now at position ({x_pos},{y_pos}).')
                    return get_command_input(robot_name, commands, y_pos, x_pos, degrees) 
                else:
                    y_pos, x_pos, degrees = back_inverse_movement(robot_name, user_command[1], y_pos, x_pos, degrees)
            elif degrees >= (0):
                if int(user_command[1]) >= 200 or int(user_command[1]) <= -200:
                    print(f'{robot_name}: Sorry, I cannot go outside my safe zone.')
                    print(f' > {robot_name} now at position ({x_pos},{y_pos}).')
                    return get_command_input(robot_name, commands, y_pos, x_pos, degrees)          
                else:
                    y_pos, x_pos, degrees= back_movement(robot_name, user_command[1], y_pos, x_pos, degrees)
        elif user_command[0] == 'RIGHT':
            degrees += 90
            y_pos, x_pos = turn_right(robot_name, y_pos, x_pos)
        elif user_command[0] == 'LEFT':
            degrees -= 90
            y_pos, x_pos = turn_left(robot_name, y_pos, x_pos)
        elif user_command[0] == 'SPRINT':
            print(f' > {robot_name} now at position (0,{sprint_robot(robot_name, int(user_command[1]))}).')
            return get_command_input(robot_name, commands, y_pos, x_pos, degrees)
    else:
        print(f'{robot_name}: Sorry, I did not understand \'{user_input}\'.')
        return get_command_input(robot_name, commands, y_pos, x_pos, degrees)
    
    return y_pos, x_pos, degrees

#----------------------------------------------------------------------------------------------

def robot_start():
    """This is the entry function, do not change"""
    name = name_the_robot()
    actions = valid_commands()
    y_pos, x_pos, degrees = position_tracking()
    
    switch_off = True
    while switch_off:
        y_pos, x_pos, degrees = get_command_input(name, actions, y_pos, x_pos, degrees)
        
        if (y_pos, x_pos, degrees) == (False, False, False) :
            break


if __name__ == "__main__":
    robot_start() 
