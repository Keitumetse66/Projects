
from test_base import captured_io
import unittest
from unittest.mock import patch
from io import StringIO
from robot import *
import robot

class MyTestCase(unittest.TestCase):

    @patch("sys.stdin", StringIO("hal\nHAL\nHaL\n"))
    def test_name_the_robot(self):
        self.assertEqual(name_the_robot(), 'hal')

    def test_valid_commands(self):
        self.assertEqual(valid_commands(), ['OFF', 'HELP', 'FORWARD', 'BACK', 'RIGHT', 'LEFT', 'SPRINT'])
    
    def test_then_wrong_then_off(self):

        with captured_io(StringIO('HAL\nJump up\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? HAL: Hello kiddo!
HAL: What must I do next? HAL: Sorry, I did not understand 'Jump up'.
HAL: What must I do next? HAL: Shutting down..""", output)

    def test_off(self):
        with captured_io(StringIO('HAL\nOFF\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? HAL: Hello kiddo!
HAL: What must I do next? HAL: Shutting down..""", output)

if __name__ == '__main__':
    unittest.main(buffer=1)
