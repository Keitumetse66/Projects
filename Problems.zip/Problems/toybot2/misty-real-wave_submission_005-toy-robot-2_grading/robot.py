
#toy_robot 2    
    

def name_robot():
    name = input("What do you want to name your robot? ").upper()
    print(f"{name}: Hello kiddo!")

    return name

# name = name_robot()

def forward_comm(name_robot, steps,pos_x, pos_y):
    print(f" > {name_robot} moved forward by {steps} steps.")
    print(f" > {name_robot} now at position ({pos_x},{pos_y}).")



def back_comm(name_robot,num, steps,pos_x, pos_y):
    if len(num) > 1 and num[1].isdigit():
            number = int(num[1])

    if (pos_y - number < -200):
        print(f"{name_robot}: Sorry, I cannot go outside my safe zone.")
        print(f" > {name_robot} now at position ({pos_x},{pos_y}).")

    else:
        print(f" > {name_robot} moved back by {steps} steps.")
        print(f" > {name_robot} now at position ({pos_x},{pos_y}).")



def right_comm(name_robot,pos_x,pos_y):
    print(f" > {name_robot} turned right.")
    print(f" > {name_robot} now at position {pos_x,pos_y}.")


def left_comm(name_robot,pos_x,pos_y):
    print(f" > {name_robot} turned left.")
    print(f" > {name_robot} now at position {pos_x,pos_y}.")


def recursion_comm(name_robot,steps):
    if (steps == 0):        
        return 0

    else:
        print(f" > {name_robot} moved forward by {steps} steps.")
        
        return steps + recursion_comm(name_robot,steps-1)


def sprint_comm(name_robot,num, steps,pos_x, pos_y):
    if len(num) > 1 and num[1].isdigit():
            number = int(num[1])

            pos_y = recursion_comm(name_robot,number)
            print(f" > {name_robot} now at position ({pos_x},{pos_y}).")

            return pos_y
    

def robot_comm(name_robot):
    comms_list = ["OFF", "HELP", "FORWARD", "BACK", "RIGHT","LEFT","SPRINT"]

    pos_x = 0
    pos_y = 0
    direction = 0

    while True:
        user = input(f"{name_robot}: What must I do next? ").upper()
        num = user.split() 

        if direction > 3 or direction < -3:
            direction = 0

        if len(num) > 1 and num[1].isdigit():
            number = int(num[1])

            if direction == 0 or direction == 2 or direction == -2:
                if number >= 200:
                    print(f"{name_robot}: Sorry, I cannot go outside my safe zone.")
                    print(f" > {name_robot} now at position ({pos_x},{pos_y}).")
                    continue

            if direction == 1 or direction == 3 or direction == -1 or direction ==-3:
                if number >= 100:
                    print(f"{name_robot}: Sorry, I cannot go outside my safe zone.")
                    print(f" > {name_robot} now at position ({pos_x},{pos_y}).")
                    continue

            if (direction == 0):
                if "FORWARD" in num:
                    pos_y += number
                elif "BACK" in num:
                    pos_y -= number

            if (direction == 1 or direction == -3):
                if "FORWARD" in num:
                    pos_x += number
                elif "BACK" in num:
                    pos_x -= number

            elif (direction == 2 or direction == -2):
                if "FORWARD" in num:
                    pos_y -= number 
                elif "BACK" in num:
                    pos_y += number

            elif (direction == 3 or direction == -1):
                if "FORWARD" in num:
                    pos_x -= number
                elif "BACK" in num:
                    pos_x += number


        if user == "OFF":
            print(f"{name_robot}: Shutting down..") 
            break

        elif ("FORWARD" in num):
            forward_comm(name_robot, number ,pos_x, pos_y)

        elif ("BACK" in num):
            back_comm(name_robot,num, number,pos_x, pos_y)

        elif ("RIGHT" in num):
            direction += 1
            print(f" > {name_robot} turned right.")
            print(f" > {name_robot} now at position ({pos_x},{pos_y}).")

        elif ("LEFT" in num):
            direction -= 1
            print(f" > {name_robot} turned left.")
            print(f" > {name_robot} now at position ({pos_x},{pos_y}).")

        elif ("SPRINT" in num):
            sprint_comm(name_robot,num, number,pos_x, pos_y)


       



        
        elif (user == "HELP"):
            print("""I can understand these commands:
OFF  - Shut down robot
HELP - provide information about commands
FORWARD - it take a steps that was given by the user or player
BACK - it take a back staps that was given by the user
RIGHT - it turn into 90 degrees into a right hand side
BACK - it turn into 90 degrees on the left hand side
SPRINT - it give the robot speed or it increase or decrease the speed """)
        
        else:
            not_correct = user.capitalize()
            print(f"{name_robot}: Sorry, I did not understand '{not_correct}'.")

    return user

# user = robot_comm()


         


def robot_start():
    """This is the entry function, do not change"""
    name = name_robot()
    user = robot_comm(name)



if __name__ == "__main__":
    robot_start()
