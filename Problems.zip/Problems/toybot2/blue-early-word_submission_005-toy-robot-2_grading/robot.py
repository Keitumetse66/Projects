def give_name():
    name = input("What do you want to name your robot? ")
    print(f"{name}: Hello kiddo!")
    return name

def valid_commands():
    """ returns a dictionary of the valid commands that are permitable"""

    valid_commands = {"OFF":"Shutting down.." , 
    "HELP": """I can understand these commands:
OFF  - Shut down robot
HELP - provide information about commands
FORWARD    - Move foward facing the current direction
BACKWARD   - Move backward facing the current direction
TURN RIGHT - Turns to the right
TURN LEFT  - Turns degrees to the left.
SPRINT     - Recursively moving forward.""", 
    "FORWARD": " > {} moved forward by {} steps.",
    "BACK": " > {} moved back by {} steps.", 
    "TURN RIGHT" : " > {} turned right.",
    "TURN LEFT" : " > {} turned left."}

    return valid_commands 


def get_command_input(name, valid_commands, is_off):
    """Gets user input and checks if it is a valid command."""

    is_off = False
    
    command = input(f"{name}: What must I do next? ")
    command_c = command.upper()

    if command_c == "HELP":
        print(valid_commands["HELP"]) 
        return valid_commands["HELP"], is_off
    
    elif command_c == "OFF":
        print(f"{name}: {valid_commands['OFF']}")
        is_off = True
        return valid_commands["OFF"], is_off
    
    elif "FORWARD" in command_c:
        return command_c, is_off
        
    elif "BACK" in command_c:
        return command_c, is_off

    elif "SPRINT" in command_c:
        return command_c, is_off
        
    elif command_c == "TURN RIGHT" or "RIGHT" in command_c:
        return command_c, is_off
    
    elif command_c == "TURN LEFT" or "LEFT" in command_c:
        return command_c, is_off

    else:# command_c not in valid_commands:
        print(f"{name}: Sorry, I did not understand '{command}'.")
        return None, is_off            


def turn_right(name, valid_commands, directions, direction, pos, index, x, y):
    """Manages the turn command. Returns the direction"""

    if direction == "W":
        index = 0
        direction = directions[index]
    else:
        index += 1
        direction = directions[index]
    print(valid_commands["TURN RIGHT"].format(name))
    return direction, index


def turn_left(name, valid_commands, directions, direction, pos, index, x, y):
    """Manages the turn command. Returns the direction"""

    if direction == "N":
        index = 3
        direction = directions[index]
    else:
        index -= 1
        direction = directions[index]
    print(valid_commands["TURN LEFT"].format(name))
    return direction, index


def move_foward(name, command_c, valid_commands, direction, pos, x, y):
    """Manages the forward command. Returns the x and y coordinates"""

    steps = [int(i) for i in command_c.split() if i.isdigit()]
    if len(steps) > 0:
        steps = steps[0]
    
    if y + steps > 200 or y - steps < -200 or x + steps > 100 or x - steps < -100:
        print(f"{name}: Sorry, I cannot go outside my safe zone.")
    else:
        print(valid_commands["FORWARD"].format(name, steps))
        if  direction == "N":
            y += steps
        elif direction == "E":
            x += steps
        elif direction == "S":
            y -= steps
        elif direction == "W":
            x-= steps
    return x, y


def move_back(name, command_c, valid_commands, direction, pos, x, y):
    """Manages the back command. Returns the x and y coordinates"""

    steps = [int(i) for i in command_c.split() if i.isdigit()]
    if len(steps) > 0:
        steps = steps[0]

    if y + steps > 200 or y - steps < -200 or x + steps > 100 or x - steps < -100:
        print(f"{name}: Sorry, I cannot go outside my safe zone.")
    else:
        print(valid_commands["BACK"].format(name, steps))
        if  direction == "N":
            y -= steps
        elif direction == "E":
            x -= steps
        elif direction == "S":
            y += steps
        elif direction == "W":
            x+= steps
    return x, y


def sprint(name, command_c, valid_commands, direction, pos, x, y):
    """Manages the sprint command. Returns the x and y coordinates"""

    steps = [int(i) for i in command_c.split() if i.isdigit()]
    if len(steps) > 0:
        steps = steps[0]
    
    steps_range = sum(range(steps + 1))

    if y + steps_range > 200 or y - steps_range < -200 or x + steps_range > 100 or x - steps_range < -100:
        print(f"{name}: Sorry, I cannot go outside my safe zone.")
        return x, y
    else:
        if steps == 0:
            return x, y
        else:
            x,y = move_foward(name, command_c, valid_commands, direction, pos, x, y)

        steps = str(steps-1)
        return sprint(name, steps, valid_commands, direction, pos, x, y)


def robot_start():
    """Manages the operations of the robots and all of its functions."""

    is_off = False

    x = 0
    y = 0 

    pos = " > {} now at position ({},{})."

    directions = ["N", "E", "S", "W"]
    index = 0
    direction = directions[index]

    v_command = valid_commands()
    name = give_name()
    while is_off == False:

        command_c, is_off = get_command_input(name, v_command, is_off)
        if is_off == True or  command_c == v_command["HELP"] or command_c == None:
            pass
        else:
            if "FORWARD" in command_c:
                x, y = move_foward(name, command_c, v_command, direction, pos, x, y)
            elif "BACK" in command_c:
                x, y = move_back(name, command_c, v_command, direction, pos, x, y)
            elif command_c == "TURN RIGHT" or "RIGHT" in command_c:
                direction, index = turn_right(name, v_command, directions, direction, pos, index, x, y)
            elif command_c == "TURN LEFT" or "LEFT" in command_c:
                direction, index = turn_left(name, v_command, directions, direction, pos, index, x, y)
            elif "SPRINT" in command_c:
                x, y = sprint(name, command_c, v_command, direction, pos, x, y)
            print(pos.format(name, x, y))
         

if __name__ == "__main__":
    robot_start()
