import robot
import unittest
import sys
from io import StringIO
from unittest.mock import patch
from test_base import captured_io

class TestRobot(unittest.TestCase):

    def test_forward(self):
        with captured_io(StringIO('Nate\nforward 5\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        res = """What do you want to name your robot? Nate: Hello kiddo!
Nate: What must I do next?  > Nate moved forward by 5 steps.
 > Nate now at position (0,5).
Nate: What must I do next? Nate: Shutting down.."""
        self.assertEqual(res, output)

    
    def test_back(self):
        with captured_io(StringIO('Nate\nback 5\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        res = """What do you want to name your robot? Nate: Hello kiddo!
Nate: What must I do next?  > Nate moved back by 5 steps.
 > Nate now at position (0,-5).
Nate: What must I do next? Nate: Shutting down.."""
        self.assertEqual(res, output)

    
    def test_range_y(self):
        with captured_io(StringIO('Nate\nforward 201\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        res = """What do you want to name your robot? Nate: Hello kiddo!
Nate: What must I do next? Nate: Sorry, I cannot go outside my safe zone.
 > Nate now at position (0,0).
Nate: What must I do next? Nate: Shutting down.."""
        self.assertEqual(res, output)

    def test_range_x(self):
        with captured_io(StringIO('Nate\nturn left\nforward 101\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        res = """What do you want to name your robot? Nate: Hello kiddo!
Nate: What must I do next?  > Nate turned left.
 > Nate now at position (0,0).
Nate: What must I do next? Nate: Sorry, I cannot go outside my safe zone.
 > Nate now at position (0,0).
Nate: What must I do next? Nate: Shutting down.."""

        self.assertEqual(res, output)


    def test_sprint(self):
        with captured_io(StringIO('Nate\nsprint 7\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        res = """What do you want to name your robot? Nate: Hello kiddo!
Nate: What must I do next?  > Nate moved forward by 7 steps.
 > Nate moved forward by 6 steps.
 > Nate moved forward by 5 steps.
 > Nate moved forward by 4 steps.
 > Nate moved forward by 3 steps.
 > Nate moved forward by 2 steps.
 > Nate moved forward by 1 steps.
 > Nate now at position (0,28).
Nate: What must I do next? Nate: Shutting down.."""

        self.assertEqual(res, output)


    def test_sprint_range(self):
        with captured_io(StringIO('Nate\nsprint 100\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        res = """What do you want to name your robot? Nate: Hello kiddo!
Nate: What must I do next? Nate: Sorry, I cannot go outside my safe zone.
 > Nate now at position (0,0).
Nate: What must I do next? Nate: Shutting down.."""

        self.assertEqual(res, output)

if __name__ == "__main__":
    unittest.main()

