import unittest
import world.text.world as text
from world.obstacles import *


class Test_Text(unittest.TestCase):
    def test_my_forward_command(self):
        test = text.forward_command("robot",0,0,0,250,[],[],[])
        self.assertEqual(test,(0,0,0) )

    def test_my_back_command(self):
        test = text.forward_command("robot",0,0,0,250,[],[],[])
        self.assertEqual(test,(0,0,0) )


if __name__ == "__main__":
    unittest.main()