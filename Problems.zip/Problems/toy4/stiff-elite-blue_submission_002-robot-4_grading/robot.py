# Annelah Ngwenya
import sys

"""
TODO: You can either work from this skeleton, or you can build on your solution for Toy Robot 3 exercise.
"""

if "turtle" in sys.argv:
    import world.turtle.world as world
else:
    import world.text.world as world

def the_robot(robot): return f"{robot}: " 

def off(robot): return str(the_robot(robot)) + "Shutting down.." 

def help(): return \
"I can understand these commands:\n\
OFF  - Shut down robot\n\
HELP - provide information about commands\n\
FORWARD - moves the toy robot forward a certain number of steps\n\
BACK - moves the toy robot back a certain number of steps\n\
RIGHT - turn by 90 degrees to the right\n\
LEFT - turn by 90 degrees to the left.\n\
SPRINT - gives it a short burst of speed and some extra distance\n\
REPLAY - replays the movement commands (forward, back, left, right, sprint)\n\
REPLAY SILENT - replays the commands, but does not show the output of each command,\
just the number of commands replayed, and the resulting position.\n\
REPLAY REVERSED - plays back the commands, with full output, in reverse order to how it was invoked originally.\n\
REPLAY REVERSED SILENT - plays back the commands in reverse, and only output the number of commands and final position\
as per the silent flag.\n\
"""

# TOY ROBOT:
def get_command_input(robot):
    """all movements are prompted and performed by this function"""

    valid_commands = ["Off","Help","Forward","Back","Right","Left","Sprint","Replay"] # known commands
    prompted_command = "" 
    split = prompted_command.split(" ")
    in_command = split[0]

    replay_list = [] # STEP 1 OF 2  Keep a history
    y_steps_list,x_steps_list = [],[]
    
    direction = 0 # STEP 6 Keep Track of Position
    x_horizontal,y_vertical = 0,0 
    steps = 0 

    list_ = world.list_of_obstacles_generator()

    if list_ == []:
        pass
    else:
        print("There are some obstacles:")
        for i in list_:
            print(f"- At position {i[0]},{i[1]} (to {int(i[0])+4},{int(i[1])+4})")

    while True:
        the_command = input(str(the_robot(robot)) + "What must I do next? ") # user input as is
        prompted_command = the_command.capitalize()
        split = prompted_command.split(" ")
        in_command = split[0] 
        if len(split)>1:
            steps = split[1]
        while in_command not in valid_commands or prompted_command == "":
            print(f"{the_robot(robot)}Sorry, I did not understand \'{the_command}\'.")
            prompted_command = input(str(the_robot(robot)) + "What must I do next? ").capitalize()
            split = prompted_command.split(" ")
            in_command = split[0]
                
        if prompted_command == "Off": return off(robot)    
        elif prompted_command == "Help": return help()


    # STEP 5 Handle Forward Command:
        if in_command == "Forward":
            x_horizontal, y_vertical, direction = world.forward_command(robot, direction, y_vertical, x_horizontal, steps, replay_list, y_steps_list, x_steps_list)
            
    # STEP 7 Back Command
        elif in_command == "Back":
            x_horizontal, y_vertical, direction = world.back_command(robot, direction, y_vertical, x_horizontal, steps, replay_list, y_steps_list, x_steps_list)
        
    # STEP 8 Handle Turn Right Command
        elif in_command == "Right":
            direction = world.right_command(direction, robot, replay_list, x_horizontal, y_vertical)

    # STEP 9 Handle Turn Left Command
        elif in_command == "Left": 
            direction = world.left_command(direction, robot, replay_list, x_horizontal, y_vertical)

    # STEP 11 Sprint Command
        elif in_command == "Sprint":
            """Sprint gives it a short burst of speed and some extra distance, by using a simple recursive approach"""
            split = prompted_command.split(" ")
            in_command = split[0]
            steps = int(split[1])           

            def sprint(steps, my_l = []):
                y_vert = y_vertical
                if steps == 0:
                    y_vert += int(sum(my_l))
                    return f" > {robot} now at position ({x_horizontal},{y_vert})."  
                
                print(f" > {robot} moved forward by {steps} steps.")
                my_l.append(steps)
                steps -= 1
                return sprint(steps, my_l)
            print(sprint(steps, my_l= []))
            continue


    # STEP 2 OF 2  Add Replay command
        elif in_command == "Replay":
            if len(prompted_command.split())>1:
                steps = split[1]
                try:
                    num = int(steps)
                    is_int = True
                except:
                    is_int = False

                if steps == "silent" or steps == "reversed":
                    if len(prompted_command.split()) ==3:
                    # REPLAY REVERSE SILENT
                        if prompted_command == "Replay reversed silent":
                            for i in range(len(replay_list)):
                                x_horizontal += x_steps_list[i]
                                y_vertical += y_steps_list[i]
                            
                            print(f" > {robot} replayed {len(replay_list)} commands in reverse silently." )
                            print(f" > {robot} now at position ({x_horizontal},{y_vertical})." )
                            continue                       
                        
                    # REPLAY SILENT 2    
                        elif split[2].isdigit()== True:
                            new_replay_list = replay_list[-int(split[2]):]
                            new_x_steps_list = x_steps_list[-int(split[2]):]
                            new_y_steps_list = y_steps_list[-int(split[2]):]
                            for i in range(int(split[2])):
                                x_horizontal += new_x_steps_list[i]
                                y_vertical += new_y_steps_list[i]

                            print(f" > {robot} replayed {int(split[2])} commands silently." )
                            print(f" > {robot} now at position ({x_horizontal},{y_vertical})." )
                            continue

                    # ROBOT DOESN'T UNDERSTAND:
                        elif split[2] != "reversed" or split[2] != "silent":             
                            print(f"{the_robot(robot)}Sorry, I did not understand \'{the_command}\'.")
                            continue
            
            # # REPLAY 2 SILENT
                command = prompted_command.split()
                cmd_2 = ""
                try:
                    num = int(command[1]) 
                    cmd_2 = command[2]
                    is_int = True     
                except: pass

                if cmd_2 == "silent":
                    if num>len(replay_list):
                        print(f"Replay out of range, Cannot replay {num} times yet.")
                        continue
                    else:
                        new_replay_list = replay_list[-num:]
                        new_x_steps_list = x_steps_list[-num:]
                        new_y_steps_list = y_steps_list[-num:]
                        for i in range(num):
                            x_horizontal += new_x_steps_list[i]
                            y_vertical += new_y_steps_list[i]

                        print(f" > {robot} replayed {num} commands silently." )
                        print(f" > {robot} now at position ({x_horizontal},{y_vertical})." )
                        continue 
                    
                # REPLAY REVERSED 2  # REPLAY 2 REVERSED
                command = prompted_command.split()
                cmd_2 = ""
                try:
                    num = int(command[1]) 
                    cmd_2 = command[2]
                    is_int = True     
                except: pass
                try:
                    num = int(command[2]) 
                    cmd_2 = command[1] 
                    is_int = True 
                except: pass

                if cmd_2 == "reversed":
                    if num>len(replay_list):
                        print(f"Replay out of range, Cannot replay {num} times yet.")
                        continue

                    reversed_list = replay_list[::-1]
                    reversed_x_steps_list = x_steps_list[::-1]
                    reversed_y_steps_list = y_steps_list[::-1]

                    new_list = reversed_list[-num:]
                    new_x = reversed_x_steps_list[-num:]
                    new_y = reversed_y_steps_list[-num:]

                    for i in range(num):
                        x_horizontal += new_x[i]
                        y_vertical += new_y[i]
                        print(new_list[i])
                        print(f" > {robot} now at position ({x_horizontal},{y_vertical})." )
                    
                    print(f" > {robot} replayed {num} commands in reverse." )
                    print(f" > {robot} now at position ({x_horizontal},{y_vertical})." )
                    continue
                
            # REPLAY RANGE
                if "-" in steps:
                    steps.split()
                    start = steps[0] 
                    end = steps[2]      
                    try:
                        start = int(start)
                        end = int(end)
                        moves = int(start) - int(end)
                    except: pass
                        
                    if isinstance(start,int) and isinstance(end,int):
                        if int(start) < int(end):
                            print("n must be bigger than m!")
                            continue
                        new_replay_list = replay_list[-int(start):-int(end)]
                        new_x_steps_list = x_steps_list[-int(start):-int(end)]
                        new_y_steps_list = y_steps_list[-int(start):-int(end)]
                        
                        for i in range(moves): 
                            x_horizontal += new_x_steps_list[i]
                            y_vertical += new_y_steps_list[i]

                            print(new_replay_list[i])
                            print(f" > {robot} now at position ({x_horizontal},{y_vertical})." )
                        
                        print(f" > {robot} replayed {moves} commands." )
                        print(f" > {robot} now at position ({x_horizontal},{y_vertical})." )
                        continue
                
            # REPLAY NUM
                if is_int and len(prompted_command.split()) == 2:
                    if num>len(replay_list):
                        print(f"Replay out of range, Cannot replay {num} times yet.")
                        continue
                    else:
                        new_replay_list = replay_list[-num:]
                        new_x_steps_list = x_steps_list[-num:]
                        new_y_steps_list = y_steps_list[-num:]
                        for i in range(num):
                            x_horizontal += new_x_steps_list[i]
                            y_vertical += new_y_steps_list[i]

                            print(new_replay_list[i])
                            print(f" > {robot} now at position ({x_horizontal},{y_vertical})." )
                        
                        print(f" > {robot} replayed {num} commands." )
                        print(f" > {robot} now at position ({x_horizontal},{y_vertical})." )
                        continue

            # REPLAY REVERSED:
                if steps == "reversed":
                    reversed_list = replay_list[::-1]
                    reversed_x_steps_list = x_steps_list[::-1]
                    reversed_y_steps_list = y_steps_list[::-1]
                    for i in range(len(reversed_list)):
                        x_horizontal += reversed_x_steps_list[i]
                        y_vertical += reversed_y_steps_list[i]
                        print(reversed_list[i])
                        print(f" > {robot} now at position ({x_horizontal},{y_vertical})." )
                    
                    print(f" > {robot} replayed {len(replay_list)} commands in reverse." )
                    print(f" > {robot} now at position ({x_horizontal},{y_vertical})." )
                    continue
                            
        #  STEP 3 OF 2  Replay silent
            # REPLAY SILENTLY:
                if steps == "silent":
                    for i in range(len(replay_list)):
                        x_horizontal += x_steps_list[i]
                        y_vertical += y_steps_list[i]
                
                    print(f" > {robot} replayed {len(replay_list)} commands silently." )
                    print(f" > {robot} now at position ({x_horizontal},{y_vertical})." )

                else: print(f"{the_robot(robot)}Sorry, I did not understand \'{the_command}\'.")
              
        # REPLAY:
            else:
                for i in range(len(replay_list)):
                    x_horizontal += x_steps_list[i]
                    y_vertical += y_steps_list[i]
                    print(replay_list[i])
                    print(f" > {robot} now at position ({x_horizontal},{y_vertical})." )
                
                print(f" > {robot} replayed {len(replay_list)} commands." )
                print(f" > {robot} now at position ({x_horizontal},{y_vertical})." )
            continue


def robot_start():
    """This is the entry function, do not change"""
# STEP 1 Name The Robot
    robot = input("What do you want to name your robot? ") 
    while robot == "":
        robot = input("What do you want to name your robot? ")  
    print(f"{the_robot(robot)}Hello kiddo!")
    print(get_command_input(robot))

   
if __name__ == "__main__":
    robot_start()
