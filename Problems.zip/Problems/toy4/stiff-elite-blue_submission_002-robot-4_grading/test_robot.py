import unittest
import robot
from unittest.mock import patch
from io import StringIO
from world import obstacles

# STEP 4 Make Command Handling Testable
class Test_Robot(unittest.TestCase):
# STEP 1 Name The Robot
    @patch("sys.stdin",StringIO("Toy Robot\noFF"))
    def test_my_step1_name_the_robot(self):
        with patch("sys.stdout", StringIO()) as output:
            robot.robot_start()
            self.assertEqual("What do you want to name your robot? Toy Robot: Hello kiddo!",output.getvalue()[:60])

    def test_my_step1_name_the_robot_function(self):
        self.assertEqual("robot: ", robot.the_robot("robot"))

# STEP 2 Get Command Input - Off
    def test_my_step2_get_off(self):   
        self.assertEqual("robot: Shutting down..",robot.off("robot"))

    @patch("sys.stdin",StringIO("oFF\n"))
    def test_my_step1_off(self):
        self.assertEqual("robot: Shutting down..",robot.off("robot"))
    @patch("sys.stdin",StringIO("off\n"))
    def test_my_step1_off(self):
        self.assertEqual("robot: Shutting down..",robot.off("robot"))
    @patch("sys.stdin",StringIO("OFF\n"))
    def test_my_step1_off(self):
        self.assertEqual("robot: Shutting down..",robot.off("robot"))

# STEP 2 Get Command Input - invalid command
    @patch("sys.stdin",StringIO("Jump up\noff"))
    def test_my_step2_invalid_input(self):
        with patch("sys.stdout", StringIO()) as output:
            obstacles.random.randint= lambda a,b:0
            robot.get_command_input("robot")
            self.assertEqual("""robot: What must I do next? robot: Sorry, I did not understand 'Jump up'.
robot: What must I do next? """,output.getvalue())        

# STEP 3 Handle Help Command
    def test_my_step3_help(self):
        self.assertEqual("I can understand these commands:\n\
OFF  - Shut down robot\n\
HELP - provide information about commands\n\
FORWARD - moves the toy robot forward a certain number of steps\n\
BACK - moves the toy robot back a certain number of steps\n\
RIGHT - turn by 90 degrees to the right\n\
LEFT - turn by 90 degrees to the left.\n\
SPRINT - gives it a short burst of speed and some extra distance\n\
REPLAY - replays the movement commands (forward, back, left, right, sprint)\n\
REPLAY SILENT - replays the commands, but does not show the output of each command,\
just the number of commands replayed, and the resulting position.\n\
REPLAY REVERSED - plays back the commands, with full output, in reverse order to how it was invoked originally.\n\
REPLAY REVERSED SILENT - plays back the commands in reverse, and only output the number of commands and final position\
as per the silent flag.\n\
""",robot.help())

# STEP 5 Handle Forward Command
# STEP 6 Keep Track of Position
    @patch("sys.stdin",StringIO("forward 25\noff"))
    def test_my_step5_step6_foward_position(self):
        with patch("sys.stdout", StringIO()) as output:
            obstacles.random.randint= lambda a,b:0
            robot.get_command_input("robot")
            self.assertEqual("""robot: What must I do next?  > robot moved forward by 25 steps.\n > robot now at position (0,25).\nrobot: What must I do next? """,output.getvalue())        

# STEP 7 Back Command
    @patch("sys.stdin",StringIO("back 40\noff"))
    def test_my_step7_back(self):
        with patch("sys.stdout", StringIO()) as output:
            obstacles.random.randint= lambda a,b:0
            robot.get_command_input("robot")
            self.assertEqual("""robot: What must I do next?  > robot moved back by 40 steps.\n > robot now at position (0,-40).\nrobot: What must I do next? """,output.getvalue())        

# STEP 8 Handle Turn Right Command
    @patch("sys.stdin",StringIO("right\noff"))
    def test_my_step8_right(self):
        obstacles.random.randint= lambda a,b:0
        with patch("sys.stdout", StringIO()) as output:
            robot.get_command_input("robot")
            self.assertEqual("""robot: What must I do next?  > robot turned right.\n > robot now at position (0,0).\nrobot: What must I do next? """,output.getvalue())        

# STEP 10 Limit The Area
    @patch("sys.stdin",StringIO("forward 300\noff"))
    def test_my_step10_limit_area(self):
        with patch("sys.stdout", StringIO()) as output:
            obstacles.random.randint= lambda a,b:0
            robot.get_command_input("robot")
            self.assertEqual("""robot: What must I do next? robot: Sorry, I cannot go outside my safe zone.\n > robot now at position (0,0).\nrobot: What must I do next? """,output.getvalue())        

# STEP 11 Sprint Command
    @patch("sys.stdin",StringIO("sprint 5\noff\n"))
    def test_my_step11_Sprint(self):
        with patch("sys.stdout", StringIO()) as output:
            obstacles.random.randint= lambda a,b:0
            robot.get_command_input("robot")
            self.assertEqual("""robot: What must I do next?  > robot moved forward by 5 steps.
 > robot moved forward by 4 steps.
 > robot moved forward by 3 steps.
 > robot moved forward by 2 steps.
 > robot moved forward by 1 steps.
 > robot now at position (0,15).
robot: What must I do next? """,output.getvalue()) 


# TOY ROBOT 3:

    @patch("sys.stdin",StringIO("forward 10\nforward 5\nreplay\noff\n"))
    def test_my_step2_replay(self):
        with patch("sys.stdout",StringIO()) as output:
            obstacles.random.randint= lambda a,b:0
            robot.get_command_input("robot")
        self.assertEqual("""robot: What must I do next?  > robot moved forward by 10 steps.
 > robot now at position (0,10).
robot: What must I do next?  > robot moved forward by 5 steps.
 > robot now at position (0,15).
robot: What must I do next?  > robot moved forward by 10 steps.
 > robot now at position (0,25).
 > robot moved forward by 5 steps.
 > robot now at position (0,30).
 > robot replayed 2 commands.
 > robot now at position (0,30).
robot: What must I do next? """, output.getvalue())


    @patch("sys.stdin",StringIO("forward 10\nforward 5\nreplay\nreplay\noff\n"))
    def test_my_step2_replay(self):
        with patch("sys.stdout",StringIO()) as output: 
            obstacles.random.randint= lambda a,b:0
            robot.get_command_input("robot")
        self.assertEqual("""robot: What must I do next?  > robot moved forward by 10 steps.
 > robot now at position (0,10).
robot: What must I do next?  > robot moved forward by 5 steps.
 > robot now at position (0,15).
robot: What must I do next?  > robot moved forward by 10 steps.
 > robot now at position (0,25).
 > robot moved forward by 5 steps.
 > robot now at position (0,30).
 > robot replayed 2 commands.
 > robot now at position (0,30).
robot: What must I do next?  > robot moved forward by 10 steps.
 > robot now at position (0,40).
 > robot moved forward by 5 steps.
 > robot now at position (0,45).
 > robot replayed 2 commands.
 > robot now at position (0,45).
robot: What must I do next? """, output.getvalue())

    @patch("sys.stdin",StringIO("forward 10\nforward 5\nreplay silent\noff\n"))
    def test_my_step2_replay_silent(self):
        with patch("sys.stdout",StringIO()) as output: 
            obstacles.random.randint= lambda a,b:0
            robot.get_command_input("robot")
        self.assertEqual("""robot: What must I do next?  > robot moved forward by 10 steps.
 > robot now at position (0,10).
robot: What must I do next?  > robot moved forward by 5 steps.
 > robot now at position (0,15).
robot: What must I do next?  > robot replayed 2 commands silently.
 > robot now at position (0,30).
robot: What must I do next? """, output.getvalue())

    @patch("sys.stdin",StringIO("forward 10\nforward 5\nREPLAY SILENT\noff\n"))
    def test_my_step2_replay_silent(self):
        with patch("sys.stdout",StringIO()) as output:
            obstacles.random.randint= lambda a,b:0 
            robot.get_command_input("robot")
        self.assertEqual("""robot: What must I do next?  > robot moved forward by 10 steps.
 > robot now at position (0,10).
robot: What must I do next?  > robot moved forward by 5 steps.
 > robot now at position (0,15).
robot: What must I do next?  > robot replayed 2 commands silently.
 > robot now at position (0,30).
robot: What must I do next? """, output.getvalue())


    @patch("sys.stdin",StringIO("forward 10\nforward 5\nREPLAY SILENT abd\nreplay silent\noff\n"))
    def test_my_step2_replay_silent(self):
        with patch("sys.stdout",StringIO()) as output:
            obstacles.random.randint= lambda a,b:0 
            robot.get_command_input("robot")
        self.assertEqual("""robot: What must I do next?  > robot moved forward by 10 steps.
 > robot now at position (0,10).
robot: What must I do next?  > robot moved forward by 5 steps.
 > robot now at position (0,15).
robot: What must I do next? robot: Sorry, I did not understand 'REPLAY SILENT abd'.
robot: What must I do next?  > robot replayed 2 commands silently.
 > robot now at position (0,30).
robot: What must I do next? """, output.getvalue())


    @patch("sys.stdin",StringIO("forward 10\nforward 5\nreplay reversed\noff\n"))
    def test_my_step2_replay_reversed(self):
        with patch("sys.stdout",StringIO()) as output: 
            obstacles.random.randint= lambda a,b:0
            robot.get_command_input("robot")
        self.assertEqual("""robot: What must I do next?  > robot moved forward by 10 steps.
 > robot now at position (0,10).
robot: What must I do next?  > robot moved forward by 5 steps.
 > robot now at position (0,15).
robot: What must I do next?  > robot moved forward by 5 steps.
 > robot now at position (0,20).
 > robot moved forward by 10 steps.
 > robot now at position (0,30).
 > robot replayed 2 commands in reverse.
 > robot now at position (0,30).
robot: What must I do next? """, output.getvalue())


    @patch("sys.stdin",StringIO("robot\nforward 10\nforward 5\nreplay REVERSED\noff\n"))
    def test_my_step2_replay_reversed(self):
        with patch("sys.stdout",StringIO()) as output:
            obstacles.random.randint= lambda a,b:0 
            robot.get_command_input("robot")
        self.assertEqual("""robot: What must I do next?  > robot moved forward by 10 steps.
 > robot now at position (0,10).
robot: What must I do next?  > robot moved forward by 5 steps.
 > robot now at position (0,15).
robot: What must I do next?  > robot moved forward by 5 steps.
 > robot now at position (0,20).
 > robot moved forward by 10 steps.
 > robot now at position (0,30).
 > robot replayed 2 commands in reverse.
 > robot now at position (0,30).
robot: What must I do next? robot: """, output.getvalue())

    @patch("sys.stdin",StringIO("forward 10\nforward 5\nreplay REVERSE\noff\n"))
    def test_my_step2_replay_reversed(self):
        with patch("sys.stdout",StringIO()) as output: 
            obstacles.random.randint= lambda a,b:0
            robot.get_command_input("robot")
        self.assertEqual("""robot: What must I do next?  > robot moved forward by 10 steps.
 > robot now at position (0,10).
robot: What must I do next?  > robot moved forward by 5 steps.
 > robot now at position (0,15).
robot: What must I do next? robot: Sorry, I did not understand 'replay REVERSE'.
robot: What must I do next? """, output.getvalue())

    @patch("sys.stdin",StringIO("forward 10\nforward 5\nreplay reversed silent\noff\n"))
    def test_my_step2_replay_silent_reversed(self):
        with patch("sys.stdout",StringIO()) as output: 
            obstacles.random.randint= lambda a,b:0
            robot.get_command_input("robot")
        self.assertEqual("""robot: What must I do next?  > robot moved forward by 10 steps.
 > robot now at position (0,10).
robot: What must I do next?  > robot moved forward by 5 steps.
 > robot now at position (0,15).
robot: What must I do next?  > robot replayed 2 commands in reverse silently.
 > robot now at position (0,30).
robot: What must I do next? """, output.getvalue())

    @patch("sys.stdin",StringIO("forward 10\nforward 5\nreplay REVERSED SILENT\noff\n"))
    def test_my_step2_replay_silent_reversed(self):
        with patch("sys.stdout",StringIO()) as output: 
            obstacles.random.randint= lambda a,b:0
            robot.get_command_input("robot")
        self.assertEqual("""robot: What must I do next?  > robot moved forward by 10 steps.
 > robot now at position (0,10).
robot: What must I do next?  > robot moved forward by 5 steps.
 > robot now at position (0,15).
robot: What must I do next?  > robot replayed 2 commands in reverse silently.
 > robot now at position (0,30).
robot: What must I do next? """, output.getvalue())

    @patch("sys.stdin",StringIO("forward 10\nforward 5\nreplay REVERSED,SILENT\noff\n"))
    def test_my_step2_replay_silent_reversed(self):
        with patch("sys.stdout",StringIO()) as output: 
            obstacles.random.randint= lambda a,b:0
            robot.get_command_input("robot")
        self.assertEqual("""robot: What must I do next?  > robot moved forward by 10 steps.
 > robot now at position (0,10).
robot: What must I do next?  > robot moved forward by 5 steps.
 > robot now at position (0,15).
robot: What must I do next? robot: Sorry, I did not understand 'replay REVERSED,SILENT'.
robot: What must I do next? """, output.getvalue())

    @patch("sys.stdin",StringIO("forward 3\nforward 2\nforward 1\nreplay 2\noff\n"))
    def test_my_step2_replay_range(self):
        with patch("sys.stdout",StringIO()) as output: 
            obstacles.random.randint= lambda a,b:0
            robot.get_command_input("robot")
        self.assertEqual("""robot: What must I do next?  > robot moved forward by 3 steps.
 > robot now at position (0,3).
robot: What must I do next?  > robot moved forward by 2 steps.
 > robot now at position (0,5).
robot: What must I do next?  > robot moved forward by 1 steps.
 > robot now at position (0,6).
robot: What must I do next?  > robot moved forward by 2 steps.
 > robot now at position (0,8).
 > robot moved forward by 1 steps.
 > robot now at position (0,9).
 > robot replayed 2 commands.
 > robot now at position (0,9).
robot: What must I do next? """, output.getvalue())

    @patch("sys.stdin",StringIO("forward 3\nforward 2\nforward 1\nreplay 3-1\noff\n"))
    def test_my_step2_replay_range(self):
        with patch("sys.stdout",StringIO()) as output: 
            obstacles.random.randint= lambda a,b:0
            robot.get_command_input("robot")
        self.assertEqual("""robot: What must I do next?  > robot moved forward by 3 steps.
 > robot now at position (0,3).
robot: What must I do next?  > robot moved forward by 2 steps.
 > robot now at position (0,5).
robot: What must I do next?  > robot moved forward by 1 steps.
 > robot now at position (0,6).
robot: What must I do next?  > robot moved forward by 3 steps.
 > robot now at position (0,9).
 > robot moved forward by 2 steps.
 > robot now at position (0,11).
 > robot replayed 2 commands.
 > robot now at position (0,11).
robot: What must I do next? """, output.getvalue())

    @patch("sys.stdin",StringIO("forward 3\nforward 2\nforward 1\nreplay 3--a\noff\n"))
    def test_my_step2_replay_range(self):
        with patch("sys.stdout",StringIO()) as output: 
            obstacles.random.randint= lambda a,b:0
            robot.get_command_input("robot")
        self.assertEqual("""robot: What must I do next?  > robot moved forward by 3 steps.
 > robot now at position (0,3).
robot: What must I do next?  > robot moved forward by 2 steps.
 > robot now at position (0,5).
robot: What must I do next?  > robot moved forward by 1 steps.
 > robot now at position (0,6).
robot: What must I do next? robot: Sorry, I did not understand 'replay 3--a'.
robot: What must I do next? """, output.getvalue())

    @patch("sys.stdin",StringIO("forward 3\nforward 2\nforward 1\nreplay 2 silent\noff\n"))
    def test_my_step2_replay_silent(self):
        with patch("sys.stdout",StringIO()) as output: 
            obstacles.random.randint= lambda a,b:0
            robot.get_command_input("robot")
        self.assertEqual("""robot: What must I do next?  > robot moved forward by 3 steps.
 > robot now at position (0,3).
robot: What must I do next?  > robot moved forward by 2 steps.
 > robot now at position (0,5).
robot: What must I do next?  > robot moved forward by 1 steps.
 > robot now at position (0,6).
robot: What must I do next?  > robot replayed 2 commands silently.
 > robot now at position (0,9).
robot: What must I do next? """, output.getvalue())

    @patch("sys.stdin",StringIO("forward 3\nforward 2\nforward 1\nreplay 2 reversed\noff\n"))
    def test_my_step2_replay_range_reversed(self):
        with patch("sys.stdout",StringIO()) as output: 
            obstacles.random.randint= lambda a,b:0
            robot.get_command_input("robot")
        self.assertEqual("""robot: What must I do next?  > robot moved forward by 3 steps.
 > robot now at position (0,3).
robot: What must I do next?  > robot moved forward by 2 steps.
 > robot now at position (0,5).
robot: What must I do next?  > robot moved forward by 1 steps.
 > robot now at position (0,6).
robot: What must I do next?  > robot moved forward by 2 steps.
 > robot now at position (0,8).
 > robot moved forward by 3 steps.
 > robot now at position (0,11).
 > robot replayed 2 commands in reverse.
 > robot now at position (0,11).
robot: What must I do next? """, output.getvalue())


if __name__ == "__main__":
    unittest.main()