import unittest
import world.obstacles as obstacles


class Test_Obstacle(unittest.TestCase):
    def test_my_position_blocked(self):
        obstacles.list_of_obstacles = [(20, 5), (55, -69),(10,10),(-55,-111)]
        self.assertTrue(obstacles.is_position_blocked(55, -69), True)
        self.assertTrue(obstacles.is_position_blocked(20, 5), True)
        self.assertTrue(obstacles.is_position_blocked(10, 10), True)
        self.assertTrue(obstacles.is_position_blocked(-55, -111), True)

        self.assertFalse(obstacles.is_position_blocked(19, 5), False)
        self.assertFalse(obstacles.is_position_blocked(50, 10), False)
        self.assertFalse(obstacles.is_position_blocked(0, 0), False)
        self.assertFalse(obstacles.is_position_blocked(-40, -100), False)


    def test_my_is_path_blocked(self):
        obstacles.list_of_obstacles = [(20, 5), (55, -69),(10,10),(-55,-111)]
        self.assertTrue(obstacles.is_path_blocked(20, -7, 20, 20), True)
        self.assertTrue(obstacles.is_path_blocked(55, -80, 55, 20), True)
        self.assertTrue(obstacles.is_path_blocked(5, 10, 20, 10), True)

        self.assertFalse(obstacles.is_path_blocked(19, -7, 19, 20), False)
        self.assertFalse(obstacles.is_path_blocked(40, -7, 40, 20), False)
        self.assertFalse(obstacles.is_path_blocked(0, 0, 5, 5), False)


if __name__ == "__main__":
    unittest.main()

