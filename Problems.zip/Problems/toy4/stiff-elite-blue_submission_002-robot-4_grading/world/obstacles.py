import random
import turtle

blocks = []

def obstacles_in_the_way():
    """ generates obstacles at random positions"""
    global list_of_obstacles
    list_of_obstacles = []
    num = random.randint(0,10)
    if num == 0: 
        return []
    else:
        for i in range(num):
            x = random.randint(-95,95)
            y = random.randint(-195,195)
            coordinates = (x,y)
            list_of_obstacles.append(coordinates)
    return list_of_obstacles


def obstacles_in_the_way_turtle(obstacles):
    """ Draws the Turtle interface """
    bot = turtle.Turtle()  
    for i in obstacles:
        bot.penup()
        bot.goto(i[0], i[1])
        bot.begin_fill()
        bot.forward(5)
        bot.left(90)
        bot.forward(5)
        bot.left(90)
        bot.forward(5)
        bot.left(90)
        bot.forward(5)
        bot.end_fill()
    bot.hideturtle()
        

def is_position_blocked(x,y):
    " checks if destination position is blocked "
    global list_of_obstacles
    for obstacle in list_of_obstacles:
        x1, y1 = obstacle
        if  (x >= x1 and x <= x1 + 4) and (y >= y1 - 4 and y <= y1):
            return True
    return False


def is_path_blocked(x1,y1, x2,y2,list_of_obstacles = []):
    " checks if path to reaching destination position is blocked "
    if x1 != x2:
        for a in range(x1+1,x2+1):
            if is_position_blocked(a,y2):
                return True
    if y1 != y2:
        for b in range(y1+1,y2+1):
            if is_position_blocked(x1,b):
                return True
    return False




"""other attempts"""
# def is_position_blocked(x,y):
    # for i in list_of_obstacles:
    #     if x in range(i[0], i[0]+4) or y in range(i[1], i[1]+4):
    #         return True
    # return False

# def is_path_blocked(x1,y1, x2,y2,list_of_obstacles = []):
    # for i in list_of_obstacles:
    #     block_x = i[0] 
    #     block_y = i[1]

    #     if y1 == y2:
    #         if block_x in range(min(x1+1,x2+1) ,max(x1+1,x2+1)):
    #             return True
    #     if x1== x2:
    #         if block_y in range(min(x1+1,x2+1) ,max(x1+1,x2+1)):
    #             return True
    # return False

# def get_obstacles():
#     """ Find all the sides of the block """
#     for i in list_of_obstacles: # obstacles_in_the_way():
#         x = int(i[0])
#         y = int(i[1])
#         bottom_left = x,y
#         bottom_right = (x+4,y)
#         top_right = (x+4,y+4)
#         top_left = (x, y+4)
#         obstacle_position = (bottom_left, bottom_right, top_left, top_right) 
#         blocks.append(obstacle_position)
#     return blocks

# def is_path_blocked(x1,y1, x2,y2,list_of_obstacles = []):
    # if y1 == y2:
    #     return block_x in range(min(x1,x2) ,max(x1,x2))
    # if x1== x2:
    #     return block_y in range(min(y1,y2), max(y1,y2))

# def is_position_blocked(x,y):
#     """ returns True if position (x,y) falls inside an obstacle """
#     position_blocked = False
#     blocks = get_obstacles()
#     for block in blocks:
#         for position in block:
#             if position == (x, y):
#                 return True
#                 # position_blocked = True
#     return position_blocked
