from world.obstacles import *
import world.obstacles as squares


def list_of_obstacles_generator():
    """ generates obstacles at random positions"""
    obstacles = squares.obstacles_in_the_way()
    return obstacles


def saftey_zone(robot, x_horizontal, y_vertical):
    " prevents robot from going out of the saftey zone"
    print(f"{robot}: Sorry, I cannot go outside my safe zone.")
    print(f" > {robot} now at position ({x_horizontal},{y_vertical}).")


def within_boundary_forward(robot:str, replay_list:list, steps):
    " Forward movement print outs"
    save_for_replay_trace = f" > {robot} moved forward by {steps} steps."
    replay_list.append(save_for_replay_trace)
    print(save_for_replay_trace)
    return replay_list
  

def within_boundary_back(robot:str, replay_list:list, steps):
    " Back movement print outs"
    save_for_replay_trace = f" > {robot} moved back by {steps} steps."
    replay_list.append(save_for_replay_trace)
    print(save_for_replay_trace)
    return replay_list
  

def forward_command(robot:str, direction:int,y_vertical, x_horizontal, steps, replay_list:list, y_steps_list:list, x_steps_list:list):
    " forward movement in all directions"
    try:
        steps = (int(steps))
    except:
        print("Please enter a number Example: Forward 10")
        return x_horizontal, y_vertical, direction
  
    if direction == 0: 
        if (y_vertical + steps > 200):
            saftey_zone(robot, x_horizontal, y_vertical)
            return x_horizontal, y_vertical, direction

        elif squares.is_path_blocked(x_horizontal, y_vertical, x_horizontal, y_vertical + steps, squares.list_of_obstacles):
            print(f"{robot}: Sorry, there is an obstacle in the way.")

        else:
            y_vertical += steps
            replay_list = within_boundary_forward(robot, replay_list, steps)
            y_steps_list.append(steps)
            x_steps_list.append(0)

    elif direction == 1:
        if (x_horizontal +steps > 100):
            saftey_zone(robot, x_horizontal, y_vertical)
            return x_horizontal, y_vertical, direction

        elif squares.is_path_blocked(x_horizontal, y_vertical, x_horizontal + steps, y_vertical, squares.list_of_obstacles):
            print(f"{robot}: Sorry, there is an obstacle in the way.")

        else:
            x_horizontal += steps
            replay_list = within_boundary_forward(robot, replay_list, steps)
            x_steps_list.append(steps) 
            y_steps_list.append(0)

    elif direction == 2:
        if (y_vertical -steps < -200):
            saftey_zone(robot, x_horizontal, y_vertical)
            return x_horizontal, y_vertical, direction

        elif squares.is_path_blocked(x_horizontal, y_vertical, x_horizontal, y_vertical - steps, squares.list_of_obstacles):
            print(f"{robot}: Sorry, there is an obstacle in the way.")

        else:
            y_vertical -= steps
            replay_list = within_boundary_forward(robot, replay_list, steps)
            y_steps_list.append(-int(steps))
            x_steps_list.append(0)

    elif direction == 3:          
        if (x_horizontal -steps < -100):
            saftey_zone(robot, x_horizontal, y_vertical)
            return x_horizontal, y_vertical, direction

        elif squares.is_path_blocked(x_horizontal, y_vertical, x_horizontal - steps, y_vertical, squares.list_of_obstacles):
            print(f"{robot}: Sorry, there is an obstacle in the way.")

        else:
            x_horizontal -= steps 
            replay_list = within_boundary_forward(robot, replay_list, steps)
            x_steps_list.append(-int(steps))
            y_steps_list.append(0)

    print(f" > {robot} now at position ({x_horizontal},{y_vertical}).")
    return x_horizontal, y_vertical, direction


def back_command(robot:str, direction:int, y_vertical, x_horizontal, steps,  replay_list:list, y_steps_list:list, x_steps_list:list):
    " Back movement in all directions"
    try:
        steps = (int(steps))
    except:
        print("Please enter a number Example: Back 10")
        return x_horizontal, y_vertical, direction

    if direction == 0: 
        if (y_vertical -steps < -200): 
            saftey_zone(robot, x_horizontal, y_vertical)
            return x_horizontal, y_vertical, direction

        elif squares.is_path_blocked(x_horizontal, y_vertical, x_horizontal, y_vertical -steps, squares.list_of_obstacles):
            print(f"{robot}: Sorry, there is an obstacle in the way.")

        else:
            y_vertical -= steps
            replay_list = within_boundary_back(robot, replay_list, steps) 
            y_steps_list.append(steps)
            x_steps_list.append(0)

    elif direction == 1:             
        if (x_horizontal  -steps < -100):
            saftey_zone(robot, x_horizontal, y_vertical)
            return x_horizontal, y_vertical, direction
            
        elif squares.is_path_blocked(x_horizontal, y_vertical, x_horizontal - steps, y_vertical, squares.list_of_obstacles):
            print(f"{robot}: Sorry, there is an obstacle in the way.")

        else:
            x_horizontal -= steps
            replay_list = within_boundary_back(robot, replay_list, steps) 
            x_steps_list.append(steps) 
            y_steps_list.append(0)

    elif direction == 2:
        if (y_vertical +steps > 200):
            saftey_zone(robot, x_horizontal, y_vertical)
            return x_horizontal, y_vertical, direction

        elif squares.is_path_blocked(x_horizontal, y_vertical, x_horizontal, y_vertical + steps, squares.list_of_obstacles):
            print(f"{robot}: Sorry, there is an obstacle in the way.")

        else:
            y_vertical += steps
            replay_list = within_boundary_back(robot, replay_list, steps)
            y_steps_list.append(steps)
            x_steps_list.append(0)

    elif direction == 3:       
        if (x_horizontal +steps > 100):
            saftey_zone(robot, x_horizontal, y_vertical)
            return x_horizontal, y_vertical, direction

        elif squares.is_path_blocked(x_horizontal, y_vertical, x_horizontal  + steps, y_vertical, squares.list_of_obstacles):
            print(f"{robot}: Sorry, there is an obstacle in the way.")

        else:   
            x_horizontal += steps
            replay_list = within_boundary_back(robot, replay_list, steps)
            x_steps_list.append(steps)
            y_steps_list.append(0)  
            

    print(f" > {robot} now at position ({x_horizontal},{y_vertical}).")
    return x_horizontal, y_vertical, direction


def right_command(direction:int, robot:str, replay_list:list, x_horizontal:int, y_vertical:int):
    """ makes the robot turn Right """
    direction += 1
    save_for_replay_trace = f" > {robot} turned right."
    replay_list.append(save_for_replay_trace)
    print(save_for_replay_trace)
    print(f" > {robot} now at position ({x_horizontal},{y_vertical}).")
    if direction == 4:
        direction = 0
    return direction


def left_command(direction:int, robot:str, replay_list:list, x_horizontal:int, y_vertical:int):
    """ makes the robot turn Left"""
    direction -= 1
    save_for_replay_trace = f" > {robot} turned left."
    replay_list.append(save_for_replay_trace)
    print(save_for_replay_trace)
    print(f" > {robot} now at position ({x_horizontal},{y_vertical}).")
    if direction == -1:
        direction = 3
    return direction

