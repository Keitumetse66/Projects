import io
from robot import *

import unittest
from unittest.mock import patch
from io import StringIO
import sys

from test_base import captured_io


class TestRobot(unittest.TestCase):
    
    
    @patch("sys.stdin", StringIO("Oni"))
    def test_get_robot_name(self):
        self.assertEqual(get_robot_name(), "Oni")

#     @patch("sys.stdin", StringIO("Oni\nbanana\noff"))
#     def test_get_command(self):
#         self.assertEqual("What do you want to name your robot? oni Hello kiddo!
# There are some obstacles:
# - At position 51,-68 (to 55,-64)
# - At position -44,-25 (to -40,-21)
# oni: What must I do next? banana
# oni: Sorry, I did not understand 'banana'.
# oni: What must I do next? off
# oni: Shutting down..")

                
    def test_get_command(self):        
        """tests the instructions settings"""

        with captured_io(StringIO("ONI\nHELP")) as (out, err):
            robot_name ="Oni"
            robot.get_command(robot_name)
        output = out.getvalue().strip()
        self.assertEqual("""Oni: What must I do next? Oni: Sorry, I did not understand 'ONI'.
Oni: What must I do next?""", output)
        

sys.stdout = StringIO()

if __name__ == "__main__":
    unittest.main()