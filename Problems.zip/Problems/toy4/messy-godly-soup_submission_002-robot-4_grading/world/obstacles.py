import tkinter
import random
# obstacles = []
# def create_obstacles(obstacles):
#     """!
#     @brief [Description de la fonction]

#     Paramètres : 
#         @param obstacles => [description]

#     """
#     obstacles=[(random.randint(-100,100),random.randint(-200,200))\
#         for i in range(0,random.randint(1,10))]
#         # print(list_obs)
#     # print(obstacles)
#     return obstacles
    
# def is_position_blocked(x, y,obstacles):
#     """!
#     @brief [Description de la fonction]

#     Paramètres : 
#         @param x => [description]
#         @param y => [description]
#         @param obstacles => [description]

#     """
#     for obstacle in obstacles:
#         if x >= obstacle[0] and x <= obstacle[0]+4 and y >= obstacle[1] and y <= obstacle[1]+4:
#             return True
#     return False

# def is_path_blocked(list_obs, x1, y1, x2, y2):
#     """!
#     @brief [Description de la fonction]

#     Paramètres : 
#         @param list_obs => [description]
#         @param x1 => [description]
#         @param y1 => [description]
#         @param x2 => [description]
#         @param y2 => [description]

#     """
#     if x1 == x2:
#         # horizontal line
#         for obstacle in list_obs:
#             if x1 >= obstacle[0] and x1 <= obstacle[0]+4 and min(y1, y2) <= obstacle[1]+4 and max(y1, y2) >= obstacle[1]:
#                 return True
#         return False
#     elif y1 == y2:
#         # vertical line
#         for obstacle in list_obs.obstacles:
#             if y1 >= obstacle[1] and y1 <= obstacle[1]+4 and min(x1, x2) <= obstacle[0]+4 and max(x1, x2) >= obstacle[0]:
#                 return True
#         return False
#     else:
#         return False

# def get_obstacles():
#     return create_obstacles(obstacles)

def my_obstacles():
    obstacles=[]
    number= random.randint(1,10)
    if number != 0:
        for i in range(number):
            obstacles.append((random.randint(-100,100),random.randint(-200,200)))
        
        print("There are some obstacles:")
        for j in range(len(obstacles)):
            print(f"- At position {obstacles[j][0]},{obstacles[j][1]} (to {obstacles[j][0]+4},{obstacles[j][1]+4})")
    # print(obstacles)
    return obstacles
# if __name__ == "__main__":
#     create_obstacles(obstacles)
#     get_obstacles()
    # my_obstacles()