import unittest
from world.text import world
import robot


class MyTestCase(unittest.TestCase):


    def test_do_forward(self):
        """
        tests the forward movement.
        """
        robot.history = ["forward",10]
        forward = world.do_forward("spongebob",10)
        self.assertTrue( '> spongebob moved forward by 10 steps.')


    def test_move_back(self):
        """
        tests the back movement.
        """
        robot.history = ["back",10]
        back = world.do_back("spongebob",10)
        self.assertTrue( '> HAL moved back by 10 steps.' )


    def test_do_sprint(self):
        """
        tests the sprint movement.
        """
        robot.history = ["sprint",10]
        sprint = world.do_sprint("spongebob",5)
        self.assertTrue( """ > spongebob moved forward by 5 steps.  
        > spongebob moved forward by 4 steps.  
        > spongebob moved forward by 3 steps. 
        > spongebob moved forward by 2 steps.  
        > spongebob moved forward by 1 steps.""" )

    def test_right_turn(self):
        """
        tests the right turn.
        """
        robot.history = ["right"]
        right = world.do_right_turn("spongebob")
        self.assertTrue( '> spongebob turned right.')

    def test_left_turn(self):
        """
        tests the left turn.
        """
        robot.history =["left"]
        left = world.do_left_turn("spongebob")
        self.assertTrue( '> spongebob turned left.')




if __name__ == '__main__':
    unittest.main()




















































