import unittest
from io import StringIO
import sys
from unittest import result
from test_base import captured_output, run_unittests
from test_base import captured_io
import robot
from unittest.mock import patch




class MyTestCase(unittest.TestCase):

    @patch("sys.stdin", StringIO("ROBOT\n"))
    def test_get_robot_name(self):
        with captured_output():
            actual = robot.get_robot_name()
            result = "ROBOT"
            self.assertEqual(actual,result)


    @patch("sys.stdin", StringIO("forward 10\n"))
    def test_get_command(self):
        with captured_output():
            actual = robot.get_command('ROBOT')
            result = 'forward 10'
            self.assertEqual(actual,result)


    @patch("sys.stdin", StringIO("help\n"))
    def test_do_help(self):
        with captured_output():
            actual = robot.do_help()
            result = True,"""
I can understand these commands:
OFF  - Shut down robot
HELP - provide information about commands
FORWARD - move forward by specified number of steps, e.g. 'FORWARD 10'
BACK - move backward by specified number of steps, e.g. 'BACK 10'
RIGHT - turn right by 90 degrees
LEFT - turn left by 90 degrees
SPRINT - sprint forward according to a formula
REPLAY - replays all movement commands from history [FORWARD, BACK, RIGHT, LEFT, SPRINT"""




if __name__ == "__main__":
    unittest.main()