import random


num_of_obstacles = (random.randint(1, 10)) 
obstacles = []

def is_position_blocked(x,y):
    check = obstacles
    for i in check:
        if x in range(i[0],i[0] + 4) and y in range(i[1],i[1] + 4):
            return True

   
def is_path_blocked(x1,y1, x2, y2):
    check = obstacles
    for i in check: 
        if x1 == x2 and y1 != y2:
            if y1 > y2:
                y1,y2 = y2,y1
            if x1 in range(i[0],i[0]+4) and i[1] in range(y1,y2) and i[1]+1 in \
                range(y1,y2) and i[1]+2 in range(y1,y2) and i[1]+3 in range(y1,y2):
                return True

        elif x1 != x2 and y1 == y2:
                    if x1 > x2:
                        x1, x2 = x2, x1
                    if y1 in range(i[1],i[1]+4) and i[0] in range(x1,x2) and i[0]+1 in range\
                        (x1,x2) and i[0]+2 in range(x1,x2) and i[0]+3 in range(x1,x2):
                        return True



v = []
def get_obstacles():
    global v
    num = random.randint(1,10)
    v = []
    for i in range(0,num):
        y= random.randint(-200,200)
        x = random.randint(-100,100)
        tup = (x,y)
        if (x,y) != (0,0):
            v.append(tup)
    # return v


def display_obstacles_text():
    if len(obstacles) == 0:
        obstacles = get_obstacles()
        print('There are some obstacles:')
        for i in obstacles:
            print(f'- At position {i[0]},{i[1]} (to {i[0] + 4},{i[1] + 4})')
        add_obstacles(obstacles)


def draw_obstacles(spongebob):
    obstacles = get_obstacles()
    if len(obstacles)== 0:
        for i in obstacles:
            spongebob.color('blue')
            spongebob.penup()
            spongebob.goto(i[0],i[1])
            spongebob.pendown()
            spongebob.begin_fill()
            spongebob.rt(90)
            spongebob.goto(i[0]+4,i[1])
            spongebob.rt(90)
            spongebob.goto(i[0]+4,i[1]+4)
            spongebob.rt(90)
            spongebob.goto(i[0],i[1]+4)
            spongebob.rt(90)
            spongebob.goto(i[0],i[1])
            spongebob.end_fill()
            spongebob.penup()
            spongebob.goto(0,0)
            spongebob.pendown()
        add_obstacles(obstacles)

def add_obstacles(obstacles):
    for i in obstacles:
       obstacles.append(i)


def check_observation():
    display_obstacles_text()
