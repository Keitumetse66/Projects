#duvanhe022@student.wethinkcode.co.za


# TODO: Decompose into functions

def move():
    """
    To be more descriptive, I would have named the function robot_movements(): 
    it consists of other movement functions eg move_square
    """

    size = 10
    length = 20
    width = 10
    degrees = 90

    move_square(size,degrees)
    move_rectangle(length,width,degrees)
    move_circle(degrees=1,length=1)
    square_dancing(length,degrees,size=20)
    crop_circles(length)

def move_square(size,degrees):  
    """
    robot moves in a square
    size and degrees are used as parameters 
    """ 
    print("Moving in a square of size "+str(size))
    for i in range(4):
        print("* Move Forward "+str(size))
        print("* Turn Right "+str(degrees)+" degrees")


def move_rectangle(length,width,degrees):
    """
    robot moves in a rectangle
    length, width and degrees are used as parameters
    """
    print("Moving in a rectangle of "+str(length)+" by "+str(width))
    for i in range(2):
        print("* Move Forward "+str(length))
        print("* Turn Right "+str(degrees)+" degrees")
        print("* Move Forward "+str(width))
        print("* Turn Right "+str(degrees)+" degrees")


def move_circle(degrees=1,length=1):
    """
    robot moves in a circle
    degrees and length are used as parameters 
    setting degrees and length to 1
    """
    print("Moving in a circle")
    for i in range(360):
        print("* Move Forward "+str(length))
        print("* Turn Right "+str(degrees)+" degrees")


def square_dancing(length,degrees,size=20):
    """
    robot prints 3 squares
    length, degrees and size are used as parameters
    setting size to 20
    """
    print("Square dancing - 3 squares of size 20")
    for i in range(3):
        print("* Move Forward "+str(length))
        move_square(size,degrees)


def crop_circles(length):
    """
    robot prints 4 circles 
    length is used as a parameter
    """
    print("Crop circles - 4 circles")
    for i in range(4):
        print("* Move Forward "+str(length))
        move_circle(degrees=1,length=1)

    
def robot_start():
    move()


if __name__ == "__main__":
    robot_start()