
def move_square(size):

    '''Prompts toy robot to move in square shape at 90 degree angle(s).'''

    print("Moving in a square of size "+str(size))
    for i in range(4):
        degrees = 90
        print("* Move Forward "+str(size))
        print("* Turn Right "+str(degrees)+" degrees")


def move_rectangle(length, width):

    '''Prompts toy robot to move in rectangular shape at 90 degree angle(s) at a specified length and width.'''

    print("Moving in a rectangle of "+str(length)+" by "+str(width))

    for i in range(2):
        degrees = 90
        print("* Move Forward "+str(length))
        print("* Turn Right "+str(degrees)+" degrees")
        print("* Move Forward "+str(width))
        print("* Turn Right "+str(degrees)+" degrees")


def move_circle(degrees):

    '''Prompts toy robot to move in circles in a 360 degree angle.'''

    print("Moving in a circle")

    for i in range(360):
        length = 1
        print("* Move Forward "+str(length))
        print("* Turn Right "+str(degrees)+" degrees")


def move_square_dance(size):

    '''Prompts toy robot to dance in square shape 3 times with size 20 at 90 degree angle(s).'''

    print("Square dancing - 3 squares of size 20")
    for i in range(3):
        length = 20
        print("* Move Forward "+str(length))
        # print("Moving in a square of size 20")
        move_square(size)
            

def move_crop_circles(size):

    '''Prompts toy robot to move in circles 4 times at a 360 degree angle each time.'''

    print("Crop circles - 4 circles")
    for i in range(4):
        degrees = 1
        print("* Move Forward "+str(size))
        # print("Moving in a circle")
        move_circle(degrees)
        

def move():
    '''I would rename this move() function to move_robot() because it would become more readable and descriptive as to what the function does or has to do.'''
    length = 20
    size = 10
    width = 10
    degrees = 1
    move_square(size)
    move_rectangle(length, width)
    move_circle(degrees)
    size = 20
    move_square_dance(size)
    move_crop_circles(size)


def robot_start():
    move()

if __name__ == "__main__":
    robot_start()
