

def movement(forward, degrees):  #To avoid repeating Move Forward and Turn right
    print("* Move Forward "+str(forward))
    print("* Turn Right "+str(degrees)+" degrees")



def square(size, degrees):
    print("Moving in a square of size "+str(size))
    for i in range(4):
        movement(size, degrees)
       


def rectangle(length, degrees):
    width = 10
    print("Moving in a rectangle of "+str(length)+" by "+str(width))
    for i in range(2):
        movement(length, degrees)
        movement(width, degrees)


def circle(degrees, length):
    print("Moving in a circle")
    for i in range(360):
        movement(length, degrees)


def square_dancing(degrees, length):
    print("Square dancing - 3 squares of size "+ str(length))
    for i in range(3):
        print("* Move Forward "+str(length))
        square(length, degrees)


def crop_circles(degrees, length, size):
    print("Crop circles - 4 circles")
    for i in range(4):
        print("* Move Forward "+str(size))
        circle(degrees, length)
           
           
# TODO: Decompose into functions
def move():
    
    square(size = 10, degrees = 90)
    rectangle(length = 20, degrees = 90)
    circle(degrees=1, length=1)
    square_dancing(degrees = 90, length = 20)
    crop_circles(degrees=1, length=1, size=20)



def robot_start():
    move()


if __name__ == "__main__":
    robot_start()
