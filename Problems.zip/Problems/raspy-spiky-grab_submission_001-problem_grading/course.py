
import code
import random
from optparse import Values
from typing import Counter


def create_outline():
    """
    TODO: implement your code here
    """
    pass
    #step 1
    course_topics = set()                                                                                                  #im using set to add mulitple of data i a single variable
    print("Course Topics:")
    course_topics = ['* Introduction to Python','* Tools of the Trade','* How to make decisions','* How to repeat code','* How to structure data','* Functions','* Modules'] 
    courses =list(course_topics)                                                                                            #convert set to a list
    course_topics.sort()                                                                                                    #sort in alphabetical order
    for i in course_topics:
        print(i)

    #Step 2                                                         
    print("Problems:")
    courses = {                                                                                                             #im using a dictionary to add problems on every course
    '* Introduction to Python' : 'Problem 1, Problem 2, Problem 3',
    '* Tools of the Trade': 'Problem 1, Problem 2, Problem 3',
    '* How to make decisions':'Problem 1, Problem 2, Problem 3',
    '* How to repeat code':'Problem 1, Problem 2, Problem 3',
    '* How to structure data':'Problem 1, Problem 2, Problem 3',
    '* Functions':'Problem 1, Problem 2, Problem 3',
    '* Modules':'Problem 1, Problem 2, Problem 3'
    }
    for key, value in courses.items():                                                                                         #a dictionary uses a key and value pairs
        print(key+ " : "+value)                                                                                                #im retting the key and the value of each defind dictionary

        
    def sorter_override(item):
        return item[3]                                                                                                          #new function that indicates the return of indexed items

     #Step 3
    print("Student Progress: ")
    student_status= ["[GRADED]","[COMPLETED]","[STARTED]"]                                                                       #a list of student status 
    student_name = {"Aybuda","Melo","Jane"}                                                                                      #a set of given student names
    student_problem = ["Problem 1","Problem 2","Problem 3"]                                                                      #a list of problems available
    topics = [' Functions',' Introduction to Python',' Tools of the Trade',' How to make decisions',' How to repeat code',' How to structure data',' Modules']          #a list of student topics
    topics.sort()
    counting = 0    

    # Create a list of students
    student_list = []
    for i in student_name:                                                                                                         #student name
        students = (i,random.choice(topics),random.choice(student_problem),student_status[counting])                               #randomly pick any topic, any problem, any status for the picked student name
        student_list.append(students)                                                                                              #at the end of the student list please use random choice
        counting = counting+1                                                                                                      #start counting from one and ensure that the status is radomly picked and changed        
    sorted_students = sorted(student_list,key=sorter_override,reverse=True)                                                        #sort our students
    counting = 0
    
    for i in sorted_students:                                                                                                       #display your list of students
        print(f"{counting +1}. {i[0]} - {i[1]} - {i[2]} {i[3]}")                                                                    #display them accordingly and in order
        counting = counting+1

   

if __name__ == "__main__":
    create_outline()
