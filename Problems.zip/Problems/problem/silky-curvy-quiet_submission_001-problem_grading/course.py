


from pydoc_data.topics import topics
from unittest import result


def create_outline():
    
    print("Course Topics:")
    topics= set(["Introduction to Python","Tools of the Trade","How to make decisions", "How to repeat code","How to structure data", "Functions", "Modules"])
    topics=sorted(topics)
    for course in topics:
        print("*",course)
    

    print ('Problems:')
    lists= ["Problem 1", "Problem 2", "Problem 3"]
    courses= dict.fromkeys(topics,lists)
    for i in courses:
        print(f"* {i} : {courses[i][0]}, {courses[i][1]}, {courses[i][2]}")

    print ("Student Progress:")
    names= ["1. Ben", "2. Tom", "3. Ted", "4. khethu", "5. Tali", "6. Livhu", "7. Gabi"]
    status= ["STARTED", "GRADED", "COMPLETED"]
    top= list(topics)
    cou= list(courses)

    for i in range(len(status)):
        top.sort()
        status.sort(reverse=True)
        print(f"{names[i]} - {cou[i]} - {lists[i]} [{status[i]}]")

   
        
    
    # student0= (names[0], courses[i][0], status[0])
    # student1= (names[1], courses[i][1], status[1])
    # student2= (names[2], courses[i][2], status[2])
    # student3= (names[3], courses[i][3], status[3])
    # student4= (names[4], courses[i][4], status[4])
    # student5= (names[5], courses[i][5], status[5])
    # student6= (names[6], courses[i][6], status[6])
    # list_of_students= ()
    # for i in student:
    #     print("*",)

if __name__ == "__main__":
    create_outline()
