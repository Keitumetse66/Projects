

from pydoc_data.topics import topics


def create_outline():
    """
    TODO: implement your code here
    """
    #Step 1
    topics = {"* Introduction to Python", "* Tools of the Trade", "* How to make decisions", "* How to repeat code", "* How to structure data", "* Functions", "* Modules"}
    print("Course Topics:")
    topics = sorted(topics)
    for course in topics:
        print(course)

    
    #Step 2
    #Adding Problems
    
    problems ="Problem 1", "Problem 2", "Problem 3"
    print("Problems: ")
    add_problems = {}

    for course in topics:
        add_problems.update({course:problems})   

    for a in add_problems:
        print(a + " : Problem 1,", "Problem 2,", "Problem 3")

    #for a in problems:
        #print(a)

    #Step 3
    #keeping track
    print("Student Progress: ")


    student_1 = ("1. Opola - Introduction to Python - Problem 2 [STARTED]")
    student_2 = ("2. Sbu - How to make decisions - Problem 1 [GRADED]")
    student_3 = ("3. Landi - Tools of the trade - Problem 3 [COMPLETED]")
    
    print(student_1)
    print(student_2)
    print(student_3)




if __name__ == "__main__":
    create_outline()
