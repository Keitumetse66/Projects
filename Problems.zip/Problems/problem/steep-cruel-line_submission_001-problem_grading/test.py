import random
print("floating point triangular")
print(random.triangular(10.5, 25.5, 5.5))
# Output 16.114862085401924
