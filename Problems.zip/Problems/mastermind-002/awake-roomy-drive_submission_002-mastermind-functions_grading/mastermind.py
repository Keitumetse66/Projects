import random

# TODO: Decompose into functions
def four_digit_code():
    """ Generates a random four digit code between 1 and 8  

    Returns:
        code: our list which contains the 4 digit code 
    """
    
    code = [0,0,0,0]
    for i in range(4):
        value = random.randint(1, 8) # 8 possible digits
        while value in code:
            value = random.randint(1, 8)  # 8 possible digits
        code[i] = value

    #print(code)
    print('4-digit Code has been set. Digits in range 1 to 8. You have 12 turns to break it.')
    return code
    
def correct_place(code):
    """ If the random code and the answer have the same number at the same index it means the user 
    guessed correctly and the number of correct digits in the correct place increases by one each time
    
    Args:
        code (list): contains the random 4 digit code 
    """
    
    correct = False
    turns = 0
    while not correct and turns < 12:
        answer = input("Input 4 digit code: ")
        if len(answer) < 4 or len(answer) > 4:
            print("Please enter exactly 4 digits.")
            continue
        correct_digits_and_position = 0
        correct_digits_only = 0
        for i in range(len(answer)):
            if code[i] == int(answer[i]):
                correct_digits_and_position += 1
            elif int(answer[i]) in code:
                correct_digits_only += 1
        print('Number of correct digits in correct place:     '+str(correct_digits_and_position))
        print('Number of correct digits not in correct place: '+str(correct_digits_only))
        turns += 1

        if correct_digits_and_position == 4:
            correct = True
            print('Congratulations! You are a codebreaker!')
        else:
            print('Turns left: '+str(12 - turns))

    print('The code was: '+str(code))
    
def run_game():
    code = four_digit_code()
    correct_place(code)


if __name__ == "__main__":
    run_game()
    
