import random


# TODO: Decompose into functions
def computer_guesses():
    code = [0,0,0,0]
    for i in range(4):
        value = random.randint(1, 8) # 8 possible digits
        while value in code:
            value = random.randint(1, 8)  # 8 possible digits
        code[i] = value

    return code 

"""
User has to guess a value in which the answer has to be a digit and should not have 0 and 9 as a answer.
This has to be returned to the def game() as well.
"""

    #print(code)
def get_user_input():
    correct = False
    turns = 0
    while not correct and turns <12:

        answer = input("Input 4 digit code: ")
        if len (answer) < 4 or len (answer) > 4:
            print("Please enter exactly 4 digits.")
            continue
        else:
            if answer.isdigit() == False or "0" in answer or "9" in answer:
                continue
            else: 
                break 
    return answer 
"""
Checks the answer of what the user has inputted and counts the amount of correct and incorrect digit positions.
Parameters has to be provided to only use the variables (answer,code) when checking what the user
has inputted.This is also returned in run_game().
"""


def user_input(answer,code):
    correct_digits_and_position = 0
    correct_digits_only = 0

    for i in range(len(answer)):
        if code[i] == int(answer[i]):
             correct_digits_and_position += 1
        elif int(answer[i]) in code:
             correct_digits_only += 1

    print('Number of correct digits in correct place:     '+str(correct_digits_and_position))
    print('Number of correct digits not in correct place: '+str(correct_digits_only))
    return correct_digits_and_position

def run_game():
    print('4-digit Code has been set. Digits in range 1 to 8. You have 12 turns to break it.')
    code = computer_guesses()
    turns = 0
    correct_code = False
    while not correct_code and turns < 12:
        answer = get_user_input()

        correct_digits_and_position = user_input(answer, code)
        turns += 1
        if correct_digits_and_position == 4:
            print('Congratulations! You are a codebreaker!')
            correct_code = True
        else:
            print('Turns left: '+str(12 - turns))
    print('The code was: '+str(code))

if __name__ == "__main__":
    run_game()




# def if_answer_is_correct(turns,correct_digits_and_position):
      #             return turns,correct_digits_and_position

# correct_code = False
#         if len(answer) < 4 or len(answer) > 4:
#             print("Please enter exactly 4 digits.")
#             continue
#         correct_digits_and_position = 0
#         correct_digits_only = 0










        



   

      



