


# list of valid command names
valid_commands = ['off', 'help', 'forward', 'back', 'right', 'left', 'sprint','replay',[]]

# variables tracking position and direction
position_x = 0
position_y = 0
directions = ['forward', 'right', 'back', 'left']
current_direction_index = 0

# area limit vars
min_y, max_y = -200, 200
min_x, max_x = -100, 100


def get_robot_name():
    name = input("What do you want to name your robot? ")
    while len(name) == 0:
        name = input("What do you want to name your robot? ")
    return name


def get_command(robot_name):
    """
    Asks the user for a command, and validate it as well
    Only return a valid command
    """

    prompt = ''+robot_name+': What must I do next? '
    command = input(prompt)
    while len(command) == 0 or not valid_command(command):
        output(robot_name, "Sorry, I did not understand '"+command+"'.")
        command = input(prompt)
        
    return command.lower()


def split_command_input(command):
    """
    Splits the string at the first space character, to get the actual command, as well as the argument(s) for the command
    :return: (command, argument)
    """
    args = command.split(' ', 1)
    if len(args) > 1:
        return args[0], args[1]
    return args[0], ''


def is_int(value):
    """
    Tests if the string value is an int or not
    :param value: a string value to test
    :return: True if it is an int
    """
    try:
        int(value)
        return True
    except ValueError:
        return False


def valid_command(command):
    """
    Returns a boolean indicating if the robot can understand the command or not
    Also checks if there is an argument to the command, and if it a valid int
    """

    (command_name, arg1) = split_command_input(command)
    
    # valid = False
    # if command_name.lower() in  valid_commands:
    #     if (len(arg1)==0 or is_int(arg1)):
    #         valid = True
    #     elif arg1.lower() in ['silent','reversed','reversed silent']:
    #         valid = True
    #     elif is_int(arg1.split(' ')[0]) and arg1.split(' ')[1].lower() in ['silent','reversed','reversed silent']:
    #         valid = True

    # return valid
    # print(arg1.split()[1], "and", arg1.split()[0])
    # print(arg1.split()[1] in ['silent','reveresed'])
    return (command_name.lower() in valid_commands and 
        (len(arg1) == 0 or
        is_int(arg1) or
        arg1.lower() =='silent' or
        arg1.lower() == 'reversed' or
        arg1.lower() == 'reversed silent' or
    
        (len(arg1.split("-")) >1 and is_int(arg1.split("-")[0]) and is_int(arg1.split("-")[1])) or
        (len(arg1.split()) >1 and arg1.split()[0] in ['silent','reversed'] and len(arg1.split("-")) >1 and is_int(arg1.split()[1].split("-")[0]) and is_int(arg1.split()[1].split("-")[1])) or
        (len(arg1.split()) >1 and arg1.split()[0] in ['silent','reversed'] and  is_int(arg1.split()[1])) or
        (len(arg1.split()) >1 and arg1.split()[1] in ['silent','reversed'] and  is_int(arg1.split()[0])) or
        (len(arg1.split()) >2 and arg1.split()[0] in ['silent','reversed'] and arg1.split()[0] != arg1.split()[1] and arg1.split()[1] in ['silent','reversed'] and len(arg1.split()[2].split("-")) >1 and is_int(arg1.split()[2].split("-")[0]) and is_int(arg1.split()[2].split("-")[1])) or
        (len(arg1.split()) >2 and arg1.split()[0] in ['silent','reversed'] and arg1.split()[0] != arg1.split()[1] and arg1.split()[1] in ['silent','reversed']  and is_int(arg1.split()[2])))) or (is_int(arg1.split()[0]) and arg1.split()[0] in [['silent','reversed']])


def output(name, message):
    print(''+name+": "+message)


def do_help():
    """
    Provides help information to the user
    :return: (True, help text) to indicate robot can continue after this command was handled
    """
    return True, """I can understand these commands:
OFF  - Shut down robot
HELP - provide information about commands
FORWARD - move forward by specified number of steps, e.g. 'FORWARD 10'
BACK - move backward by specified number of steps, e.g. 'BACK 10'
RIGHT - turn right by 90 degrees
LEFT - turn left by 90 degrees
SPRINT - sprint forward according to a formula 
REPLAY - command that must filter out all non-movement commands 
REPLAY SILENT - we do not see all the commands being replayed
"""


def show_position(robot_name):
    print(' > '+robot_name+' now at position ('+str(position_x)+','+str(position_y)+').')


def is_position_allowed(new_x, new_y):
    """
    Checks if the new position will still fall within the max area limit
    :param new_x: the new/proposed x position
    :param new_y: the new/proposed y position
    :return: True if allowed, i.e. it falls in the allowed area, else False
    """

    return min_x <= new_x <= max_x and min_y <= new_y <= max_y


def update_position(steps):
    """
    Update the current x and y positions given the current direction, and specific nr of steps
    :param steps:
    :return: True if the position was updated, else False
    """

    global position_x, position_y
    new_x = position_x
    new_y = position_y

    if directions[current_direction_index] == 'forward':
        new_y = new_y + steps
    elif directions[current_direction_index] == 'right':
        new_x = new_x + steps
    elif directions[current_direction_index] == 'back':
        new_y = new_y - steps
    elif directions[current_direction_index] == 'left':
        new_x = new_x - steps

    if is_position_allowed(new_x, new_y):
        position_x = new_x
        position_y = new_y
        return True
    return False


def do_forward(robot_name, steps):
    """
    Moves the robot forward the number of steps
    :param robot_name:
    :param steps:
    :return: (True, forward output text)
    """
    if update_position(steps):
        return True, ' > '+robot_name+' moved forward by '+str(steps)+' steps.'
    else:
        return True, ''+robot_name+': Sorry, I cannot go outside my safe zone.'


def do_back(robot_name, steps):
    """
    Moves the robot forward the number of steps
    :param robot_name:
    :param steps:
    :return: (True, forward output text)
    """

    if update_position(-steps):
        return True, ' > '+robot_name+' moved back by '+str(steps)+' steps.'
    else:
        return True, ''+robot_name+': Sorry, I cannot go outside my safe zone.'


def do_right_turn(robot_name):
    """
    Do a 90 degree turn to the right
    :param robot_name:
    :return: (True, right turn output text)
    """
    global current_direction_index

    current_direction_index += 1
    if current_direction_index > 3:
        current_direction_index = 0

    return True, ' > '+robot_name+' turned right.'


def do_left_turn(robot_name):
    """
    Do a 90 degree turn to the left
    :param robot_name:
    :return: (True, left turn output text)
    """
    global current_direction_index

    current_direction_index -= 1
    if current_direction_index < 0:
        current_direction_index = 3

    return True, ' > '+robot_name+' turned left.'


def do_sprint(robot_name, steps):
    """
    Sprints the robot, i.e. let it go forward steps + (steps-1) + (steps-2) + .. + 1 number of steps, in iterations
    :param robot_name:
    :param steps:
    :return: (True, forward output)
    """

    if steps == 1:
        return do_forward(robot_name, 1)
    else:
        (do_next, command_output) = do_forward(robot_name, steps)
        print(command_output)
        return do_sprint(robot_name, steps - 1)


    


def handle_command(robot_name, command,silent):
    """
    Handles a command by asking different functions to handle each command.
    :param robot_name: the name given to robot
    :param command: the command entered by user
    :return: `True` if the robot must continue after the command, or else `False` if robot must shutdown
    """

    (command_name, arg) = split_command_input(command)


    # print(command_name)
    if command_name == 'off':
        return False
    elif command_name == 'help':
        (do_next, command_output) = do_help()
        
    elif command_name == 'forward':
        (do_next, command_output) = do_forward(robot_name, int(arg))
        
    elif command_name == 'back':
        (do_next, command_output) = do_back(robot_name, int(arg))

        
    elif command_name == 'right':
        (do_next, command_output) = do_right_turn(robot_name)
        
    elif command_name == 'left':
        (do_next, command_output) = do_left_turn(robot_name)
        
    elif command_name == 'sprint':
        (do_next, command_output) = do_sprint(robot_name, int(arg))
        arg == 'silent'
    elif command_name == 'replay':
        silent = False
        if 'silent' in arg:
            silent = True
            arg = arg.replace('silent', "").strip()

        reverse = False
        if 'reversed' in arg:
            reverse = True
            arg = arg.replace('reversed', "").strip()


        # print("arg", arg)

        if arg == "":
    
            (do_next, command_output, silent) = do_replay(robot_name,silent, reverse)
        elif is_int(arg):
            (do_next, command_output, silent) = do_replay_range(robot_name,arg,silent, reverse)

        elif len(arg.split("-")) >1 and is_int(arg.split("-")[0])and is_int(arg.split("-")[1]):
            (do_next, command_output, silent) = do_replay_range(robot_name,arg,silent, reverse)

        else:
            (do_next, command_output, silent) = do_replay(robot_name,silent, reverse)
    if not silent:

        print(command_output)
        show_position(robot_name)
    return do_next


def keep_history(command):
    global history

    if all(comm not in command for comm in ["off" , "help" , "replay", "replay silent"]):
        history.append(command)
    return history

def do_replay(robot_name,silent, reverse):
    comm_history = history.copy()

    if reverse:
        comm_history = comm_history[::-1]
    for command in comm_history:
        handle_command(robot_name, command,silent)

    if silent and reverse:
        return True, f" > {robot_name} replayed 2 commands in reverse silently.", False
    elif silent: 
        return True, f" > {robot_name} replayed 2 commands silently.", False

    elif reverse:
        return True, f" > {robot_name} replayed 2 commands in reverse.", False

    return True, f" > {robot_name} replayed 2 commands.", False

def do_replay_range(robot_name, range,silent,reverse):
    commands_replayed = 0
    # print("testing")
    # print(history)
    comm_history = history.copy()



    if reverse:
        comm_history = comm_history[::-1]

    # print(history)
    # print(comm_history)
    
    if is_int(range):
        range = int(range)
        # print("hello hi")
        # print(history[-range:])
        commands_replayed = len(comm_history[-range:])
        for command in comm_history[-range:]:
            handle_command(robot_name, command,silent)
    else:
        commands_replayed = len(comm_history[-int(range.split("-")[0]):-int(range.split("-")[1])])
        # print(history[-int(range.split("-")[0]):-int(range.split("-")[1])])
        # print("helloooo")
        # print(comm_history[-int(range.split("-")[0]):-int(range.split("-")[1])])
        for command in comm_history[-int(range.split("-")[0]):-int(range.split("-")[1])]:
            handle_command(robot_name, command,silent)
    if silent and reverse:
        return True, f" > {robot_name} replayed {commands_replayed} commands in reverse silently.", False
    elif silent: 
        return True, f" > {robot_name} replayed {commands_replayed} commands silently.", False

    elif reverse:
        return True, f" > {robot_name} replayed {commands_replayed} commands in reverse.", False

    return True, f" > {robot_name} replayed {commands_replayed} commands.", False

def robot_start():
    """This is the entry point for starting my robot"""

    global position_x, position_y, current_direction_index,history

    robot_name = get_robot_name()
    output(robot_name, "Hello kiddo!")
    history= []
    position_x = 0
    position_y = 0
    current_direction_index = 0

    command = get_command(robot_name)
    keep_history(command)

    while handle_command(robot_name, command, False):
        command = get_command(robot_name)
        keep_history(command)
        

    output(robot_name, "Shutting down..")



if __name__ == "__main__":
    robot_start()
