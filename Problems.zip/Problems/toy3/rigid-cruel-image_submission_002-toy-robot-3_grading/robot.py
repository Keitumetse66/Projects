def give_name():
    name = input("What do you want to name your robot? ")
    print(f"{name}: Hello kiddo!")
    return name

def valid_commands():
    """ returns a dictionary of the valid commands that are permitable"""

    valid_commands = {"OFF":"Shutting down.." , 
    "HELP": """I can understand these commands:
OFF  - Shut down robot
HELP - provide information about commands
FORWARD    - Move foward facing the current direction
BACKWARD   - Move backward facing the current direction
TURN RIGHT - Turns to the right
TURN LEFT  - Turns degrees to the left.
SPRINT     - Recursively moving forward.
REPLAY     - Replays commands""", 
    "FORWARD": " > {} moved forward by {} steps.",
    "BACK": " > {} moved back by {} steps.", 
    "TURN RIGHT" : " > {} turned right.",
    "TURN LEFT" : " > {} turned left.",
    "REPLAY" : " > {} replayed {} commands.",
    "REPLAY SILENT" : " > {} replayed {} commands silently.", 
    "REPLAY REVERSED" : " > {} replayed {} commands in reverse.",
    "REPLAY REVERSED SILENT" : " > {} replayed {} commands in reverse silently."}

    return valid_commands 


def get_command_input(name, valid_commands, is_off):
    """Gets user input and checks if it is a valid command."""

    is_off = False
    while True:
        command = input(f"{name}: What must I do next? ")
        command_c = command.upper()

        if command_c == "HELP":
            print(valid_commands["HELP"]) 
            return valid_commands["HELP"], is_off
        
        elif command_c == "OFF":
            print(f"{name}: {valid_commands['OFF']}")
            is_off = True
            return valid_commands["OFF"], is_off
        

        elif "FORWARD" in command_c or "BACK" in command_c or "SPRINT" in command_c:
            if any([True for i in command_c.split() if i.isdigit()]):
                return command_c, is_off
            else:
                print(f"{name}: Sorry, I did not understand '{command}'.")
            
        elif "LEFT" in command_c or "RIGHT" in command_c:
            return command_c, is_off
        
        elif any([True for i in ["REPLAY", "REPLAY SILENT", "REPLAY REVERSED", "REPLAY REVERSED SILENT"] if command_c == i]):
            return command_c, is_off
        
        elif "REPLAY" in command_c and "--" not in command_c and any([i.isdigit() for i in command_c]):
            return command_c, is_off
        
        else:# command_c not in valid_commands:
            print(f"{name}: Sorry, I did not understand '{command}'.")


def turn_right(name, valid_commands, directions, direction, pos, index, x, y, silent):
    """Manages the turn command. Returns the direction"""

    if direction == "W":
        index = 0
        direction = directions[index]
    else:
        index += 1
        direction = directions[index]

    if silent == False:
        print(valid_commands["TURN RIGHT"].format(name))

    return direction, index


def turn_left(name, valid_commands, directions, direction, pos, index, x, y, silent):
    """Manages the turn command. Returns the direction"""

    if direction == "N":
        index = 3
        direction = directions[index]
    else:
        index -= 1
        direction = directions[index]

    if silent == False:
        print(valid_commands["TURN LEFT"].format(name))

    return direction, index


def move_foward(name, command_c, valid_commands, direction, pos, x, y, silent):
    """Manages the forward command. Returns the x and y coordinates"""

    steps = [int(i) for i in command_c.split() if i.isdigit()]
    if len(steps) > 0:
        steps = steps[0]
    
    if y + steps > 200 or y - steps < -200 or x + steps > 100 or x - steps < -100:
        print(f"{name}: Sorry, I cannot go outside my safe zone.")
    else:
        if silent == False:
            print(valid_commands["FORWARD"].format(name, steps))
        if  direction == "N":
            y += steps
        elif direction == "E":
            x += steps
        elif direction == "S":
            y -= steps
        elif direction == "W":
            x-= steps
    return x, y


def move_back(name, command_c, valid_commands, direction, pos, x, y, silent):
    """Manages the back command. Returns the x and y coordinates"""

    steps = [int(i) for i in command_c.split() if i.isdigit()]
    if len(steps) > 0:
        steps = steps[0]

    if y + steps > 200 or y - steps < -200 or x + steps > 100 or x - steps < -100:
        print(f"{name}: Sorry, I cannot go outside my safe zone.")
    else:
        if silent == False:
            print(valid_commands["BACK"].format(name, steps))
        if  direction == "N":
            y -= steps
        elif direction == "E":
            x -= steps
        elif direction == "S":
            y += steps
        elif direction == "W":
            x+= steps
    return x, y


def sprint(name, command_c, valid_commands, direction, pos, x, y, silent):
    """Manages the sprint command. Returns the x and y coordinates"""

    steps = [int(i) for i in command_c.split() if i.isdigit()]
    if len(steps) > 0:
        steps = steps[0]
    
    steps_range = sum(range(steps + 1))

    if y + steps_range > 200 or y - steps_range < -200 or x + steps_range > 100 or x - steps_range < -100:
        print(f"{name}: Sorry, I cannot go outside my safe zone.")
        return x, y
    else:
        if steps == 0:
            return x, y
        else:
            x,y = move_foward(name, command_c, valid_commands, direction, pos, x, y, silent)

        steps = str(steps-1)
        return sprint(name, steps, valid_commands, direction, pos, x, y, silent)


def replay(name, command_c, valid_commands, directions, direction, pos, x, y, silent, history):
    """This function takes all of the f"""

    for i in history:
        if i == "TURN LEFT" or i == "LEFT":
            direction, index = turn_left(name, valid_commands, directions, direction, pos, index, x, y, silent)
        elif i == "TURN RIGHT" or i == "RIGHT":
            direction, index = turn_right(name, valid_commands, directions, direction, pos, index, x, y, silent)
        elif "FORWARD" in i:
            command_c = i
            x, y = move_foward(name, command_c, valid_commands, direction, pos, x, y, silent)
        elif "BACK" in i:
            command_c = i
            x, y = move_back(name, command_c, valid_commands, direction, pos, x, y, silent)

        if silent == False:    
            print(pos.format(name, x, y))
        
    silent = False

    return x, y, silent


def robot_start():
    """Manages the operations of the robots and all of its functions."""

    history = []
    silent = False
    is_off = False

    x = 0
    y = 0 

    pos = " > {} now at position ({},{})."

    directions = ["N", "E", "S", "W"]
    index = 0
    direction = directions[index]

    v_command = valid_commands()
    name = give_name()
    while is_off == False:

        command_c, is_off = get_command_input(name, v_command, is_off)
        if "REPLAY" not in command_c:
            history.append(command_c)

        if is_off == True or  command_c == v_command["HELP"] or command_c == None:
            pass

        elif command_c == "REPLAY":
            x, y, silent = replay(name, command_c, v_command, directions, direction, pos, x, y, silent, history)
            print(v_command["REPLAY"].format(name, len(history)))
            print(pos.format(name, x, y))

        elif command_c == "REPLAY SILENT":
            silent = True
            x, y, silent = replay(name, command_c, v_command, directions, direction, pos, x, y, silent, history)
            print(v_command["REPLAY SILENT"].format(name, len(history)))
            print(pos.format(name, x, y))
        
        elif command_c == "REPLAY REVERSED":
            rev_history = reversed(history)
            x, y, silent = replay(name, command_c, v_command, directions, direction, pos, x, y, silent, rev_history)
            print(v_command["REPLAY REVERSED"].format(name, len(history)))
            print(pos.format(name, x, y))

        elif command_c == "REPLAY REVERSED SILENT":
            silent = True
            rev_history = reversed(history)
            x, y, silent = replay(name, command_c, v_command, directions, direction, pos, x, y, silent, rev_history)
            print(v_command["REPLAY REVERSED SILENT"].format(name, len(history)))
            print(pos.format(name, x, y))
        
        elif all([i in command_c for i in  ["REPLAY", "SILENT"]]) and [i.isdigit() for i in command_c.split()].count(True) == 1:
            silent = True
            replay_num1 = [int(i) for i in command_c.split() if i.isdigit()]
            replay_num1 = replay_num1[0]
            replay_range_history = history[-(replay_num1):]
            x, y, silent = replay(name, command_c, v_command, directions, direction, pos, x, y, silent, replay_range_history)
            print(v_command["REPLAY SILENT"].format(name, replay_num1))
            print(pos.format(name, x, y))  

        elif all([i in command_c for i in  ["REPLAY", "REVERSED"]]) and [i.isdigit() for i in command_c.split()].count(True) == 1:
            rev_history = history[::-1]
            replay_num1 = [int(i) for i in command_c.split() if i.isdigit()]
            replay_num1 = replay_num1[0]
            replay_range_history = rev_history[-(replay_num1):]
            x, y, silent = replay(name, command_c, v_command, directions, direction, pos, x, y, silent, replay_range_history)
            print(v_command["REPLAY REVERSED"].format(name, replay_num1))
            print(pos.format(name, x, y)) 

        elif "REPLAY" in command_c and [i.isdigit() for i in command_c.split()].count(True) == 1:
            split_command = command_c.split()
            replay_num1 = int(split_command[1])
            replay_range_history = history[-(replay_num1):]
            x, y, silent = replay(name, command_c, v_command, directions, direction, pos, x, y, silent, replay_range_history)
            print(v_command["REPLAY"].format(name, replay_num1))
            print(pos.format(name, x, y))  

        elif "REPLAY" in command_c and [i.isdigit() for i in command_c].count(True) == 2:
            split_command = (command_c.replace("-", " ")).split()
            replay_num1 = int(split_command[1])
            replay_num2 = int(split_command[2])
            replay_range_history = history[-(replay_num1):-(replay_num2)]
            x, y, silent = replay(name, command_c, v_command, directions, direction, pos, x, y, silent, replay_range_history)
            print(v_command["REPLAY"].format(name, (replay_num1 - replay_num2)))
            print(pos.format(name, x, y))                        
            
        else:
            if "FORWARD" in command_c:
                x, y = move_foward(name, command_c, v_command, direction, pos, x, y, silent)
            elif "BACK" in command_c:
                x, y = move_back(name, command_c, v_command, direction, pos, x, y, silent)
            elif command_c == "TURN RIGHT" or "RIGHT" in command_c:
                direction, index = turn_right(name, v_command, directions, direction, pos, index, x, y, silent)
            elif command_c == "TURN LEFT" or "LEFT" in command_c:
                direction, index = turn_left(name, v_command, directions, direction, pos, index, x, y, silent)
            elif "SPRINT" in command_c:
                x, y = sprint(name, command_c, v_command, direction, pos, x, y, silent)
            print(pos.format(name, x, y))
        
         
if __name__ == "__main__":
    robot_start()
