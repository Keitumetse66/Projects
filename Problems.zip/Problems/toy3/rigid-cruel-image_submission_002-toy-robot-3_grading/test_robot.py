import unittest
import robot
from test_base import captured_io
from io import StringIO


class NatesRobotTest(unittest.TestCase):
    
    def test_simple_replay(self):
        with captured_io(StringIO('Nate\nforward 15\nback 5\nreplay\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()
        self.assertEqual("""What do you want to name your robot? Nate: Hello kiddo!
Nate: What must I do next?  > Nate moved forward by 15 steps.
 > Nate now at position (0,15).
Nate: What must I do next?  > Nate moved back by 5 steps.
 > Nate now at position (0,10).
Nate: What must I do next?  > Nate moved forward by 15 steps.
 > Nate now at position (0,25).
 > Nate moved back by 5 steps.
 > Nate now at position (0,20).
 > Nate replayed 2 commands.
 > Nate now at position (0,20).
Nate: What must I do next? Nate: Shutting down..""", output)


    def test_replay_silent(self):
        with captured_io(StringIO('Nate\nforward 15\nforward 5\nreplay silent\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()
        self.assertEqual("""What do you want to name your robot? Nate: Hello kiddo!
Nate: What must I do next?  > Nate moved forward by 15 steps.
 > Nate now at position (0,15).
Nate: What must I do next?  > Nate moved forward by 5 steps.
 > Nate now at position (0,20).
Nate: What must I do next?  > Nate replayed 2 commands silently.
 > Nate now at position (0,40).
Nate: What must I do next? Nate: Shutting down..""", output)
    
    
    def test_replay_reversed(self):
        with captured_io(StringIO('Nate\nforward 15\nforward 5\nreplay REVERSED\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()
        self.assertEqual("""What do you want to name your robot? Nate: Hello kiddo!
Nate: What must I do next?  > Nate moved forward by 15 steps.
 > Nate now at position (0,15).
Nate: What must I do next?  > Nate moved forward by 5 steps.
 > Nate now at position (0,20).
Nate: What must I do next?  > Nate moved forward by 5 steps.
 > Nate now at position (0,25).
 > Nate moved forward by 15 steps.
 > Nate now at position (0,40).
 > Nate replayed 2 commands in reverse.
 > Nate now at position (0,40).
Nate: What must I do next? Nate: Shutting down..""", output)
    
    
    def test_replay_reversed_silent(self):
        with captured_io(StringIO('Nate\nforward 15\nforward 5\nreplay reversed silent\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()
        self.assertEqual("""What do you want to name your robot? Nate: Hello kiddo!
Nate: What must I do next?  > Nate moved forward by 15 steps.
 > Nate now at position (0,15).
Nate: What must I do next?  > Nate moved forward by 5 steps.
 > Nate now at position (0,20).
Nate: What must I do next?  > Nate replayed 2 commands in reverse silently.
 > Nate now at position (0,40).
Nate: What must I do next? Nate: Shutting down..""", output)
    
    
    def test_replay_range(self):
        with captured_io(StringIO('Nate\nforward 15\nforward 5\nforward 1\nreplay 3-1\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()
        self.assertEqual("""What do you want to name your robot? Nate: Hello kiddo!
Nate: What must I do next?  > Nate moved forward by 15 steps.
 > Nate now at position (0,15).
Nate: What must I do next?  > Nate moved forward by 5 steps.
 > Nate now at position (0,20).
Nate: What must I do next?  > Nate moved forward by 1 steps.
 > Nate now at position (0,21).
Nate: What must I do next?  > Nate moved forward by 15 steps.
 > Nate now at position (0,36).
 > Nate moved forward by 5 steps.
 > Nate now at position (0,41).
 > Nate replayed 2 commands.
 > Nate now at position (0,41).
Nate: What must I do next? Nate: Shutting down..""", output)
    


if __name__ == "__main__":
    unittest.main()