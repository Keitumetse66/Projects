

# TODO: Step 1 - get shape (it can't be blank and must be a valid shape!)
from ssl import ALERT_DESCRIPTION_HANDSHAKE_FAILURE


def get_shape():
    shapes=['square','triangle','pyramid','diamond','hourglass','rhombus']
    shape = input("Shape?: ").lower()
    while True:
        if shape not in shapes:
            shape = input("Shape?: ").lower()
        else:
            return shape


# TODO: Step 1 - get height (it must be int!)
def get_height():
    while True:
        height= input("Height?: ")
        if height.isdigit() and int(height) <= 80:
            return int(height)


# TODO: Step 2
def draw_pyramid(height, outline):
    if outline == False:
        for i in range(height):
            for m in range(height -i - 1):
                print(" ", end="")
            for p in range(2 * i + 1):
                print("*", end="")
            print()
    elif outline == True:   #Hollow Pyramid
        for i in range(height):
            for m in range(height - i - 1):
                print(" ", end="")
            for o in range(2 * i + 1):
                if o == 0 or o == 2 * i:
                    print("*", end="")
                else:
                    if i == height - 1:
                        print("*", end = "")
                    else:
                        print(" ", end = "")
            print()

# TODO: Step 3
def draw_square(height, outline):
    if outline == False:
        for i in range(0, height):
            for k in range(0, height):
                print("*", end='')
            print()
    elif outline == True:       #Hollow Square
        for i in range(height):
            for k in range(height):
                if i == 0 or i == height - 1 or k == 0 or k == height - 1:
                    print('*', end = '')
                else:
                    print(' ', end = '')
            print()


# TODO: Step 4
def draw_triangle(height, outline):
    if outline == False:
        for i in range(1, height + 1):
            for k in range(1, i + 1):
                print("*", end="")
            print()
    elif outline == True:       #Hollow triangle
        for i in range(1, height + 1):
            for k in range(i):
                if k == 0 or k == i - 1:
                    print("*", end ="")
                else:
                    if i != height:
                        print(" ", end="")
                    else:
                        print("*", end="")
            print()

def draw_diamond(height, outline):
    if outline == False:
        for i in range(1, height+1):
                for j in range(1,height-i+1):
                    print(" ", end="")
                for j in range(1, 2*i):
                    print("*", end="")
                print()
        for i in range(height-1,0, -1):
                for j in range(1,height-i+1):
                    print(" ", end="")
                for j in range(1, 2*i):
                    print("*", end="")
                print()
    if outline == True:
        for i in range(1, height+1):
                for j in range(1,height-i+1):
                    print(" ", end="")
                for j in range(1, 2*i):
                    if j==1 or j==2*i-1:
                        print("*", end="")
                    else:
                        print(" ", end="")
                print()
        for i in range(height-1,0, -1):
                for j in range(1,height-i+1):
                    print(" ", end="")
                for j in range(1, 2*i):
                    if j==1 or j==2*i-1:
                     print("*", end="")
                    else:
                        print(" ", end="")
                print()

def draw_hourglass(height, outline):
    if outline == False:
        for i in range(height, 0, -1):
            for j in range(height-i):
                print(" ", end="")
            for j in range(1, 2*i):
                print("*", end="")
            print()
        for i in range(2, height+1):
            for j in range(height-i):
                print(" ", end="")
            for j in range(1, 2*i):
                print("*", end="")
            print()
    if outline == True:
        for i in range(height, 0, -1):
            for j in range(height-i):
                print(" ", end="")
            for j in range(1, 2*i):
                if i==1 or i==height or j==1 or j==2*i-1:
                    print("*", end="")
                else:
                    print(" ", end="")
            print()
        for i in range(2, height+1):
            for j in range(height-i):
                print(" ", end="")
            for j in range(1, 2*i):
                if i==1 or i==height or j==1 or j==2*i-1:
                    print("*", end="")
                else:
                    print(" ", end="")
            print()
        
def draw_rhombus(height, outline):
    if outline == False:
        for i in range(height, 0, -1):
            for j in range(1, i):
                print(' ', end = '')
            for k in range(0, height):
                print('*', end = '')
            print()
    if outline == True:
        for i in range(height, 0, -1):
            for j in range(1, i):
                print(' ', end = '')
            for k in range(0, height):
                if(i == 1 or i == height or k == 0 or k == height - 1):
                    print('*', end = '')
                else:
                    print(' ', end = '')
            print()

# TODO: Steps 2 to 4, 6 - add support for other shapes
def draw(shape, height, outline):
    if shape == "pyramid":
        draw_pyramid(height, outline)
    elif shape == "square":
        draw_square(height, outline)
    elif shape == "triangle":
        draw_triangle(height, outline)
    elif shape == "diamond":
        draw_diamond(height, outline)
    elif shape == "hourglass":
        draw_hourglass(height, outline)
    elif shape == "rhombus":
        draw_rhombus(height, outline)

# TODO: Step 5 - get input from user to draw outline or solid
def get_outline():
    outline = input("Outline only? (Y/N):")
    if outline == "y":
        return True
    else:
        return False


if __name__ == "__main__":
    shape_param = get_shape()
    height_param = get_height()
    outline_param = get_outline()
    draw(shape_param, height_param, outline_param)

