

# TODO: Step 1 - get shape (it can't be blank and must be a valid shape!)

def get_shape():
     shapes = ['triangle','square','pyramid',"opposite triangle","opposite pyramid","diamond"]
  
     while True:
       user_input = input('Shape?: ').lower()
       if user_input not in shapes and user_input != '':
            return None
       elif user_input in shapes:
            break
       else:
            continue

     return user_input

# TODO: Step 1 - get height (it must be int!)
def get_height():

    while True:
     height = input("Height?: ")
     if  height.isnumeric() and 0 < int(height) <= 80:
       break
     else:
        continue
    return int(height)


# TODO: Step 2
def draw_pyramid(height, outline):
    if not outline:
        for rows in range(height):
            for columns in range(height-rows-1):
                print(" ",end="")
            for columns in range(2*rows+1):
                print("*",end="")
            print("")
    else:
        for rows in range(height):
            for columns in range(height-rows-1):
                print(" ",end="")
            for columns in range(2*rows+1):
                if columns == 0 or columns == 2*rows  :
                    print("*",end="")
                else:
                    if rows == height-1:
                        print("*",end ="")
                    else:
                        print(" ",end="")
            print()

# TODO: Step 3
def draw_square(height, outline):

    if not outline:
      for rows in range(1,height+1):
        for columns in range(1,height+1):
            print("*",end ="")
        print()

    else:
     for rows in range(height):
        for columns in range(height):
          if rows == 0 or columns == 0 or rows == height-1 or columns == height -1:
            print("*",end="")
          else:
            print("",end=" ")
        print()


# TODO: Step 4
def draw_triangle(height, outline):
    if not outline:
        for i in range(1,height+1):
            print("*"*i)

    else:
        for rows in range(height):
          for columns in range(rows+1):
             if rows == height-1 or columns== 0 or columns ==rows:
               print("*",end="")
             else:
               print(" ",end="")
          print()

def opposite_triangle(height): 
    for i  in range(1,height+1):
       print(" "*(height-i)+"*"*i) 

def opposite_pyramid(height):
    for i in range (height,0,-1):
        print(" "*(height-i)+"* "*i)
def diamond(height):
    for i in range (1,height+1):
        print(" "*(height-i)+"* "*i)

    for i in range (height-1,0,-1):
        print(" "*(height-i)+"* "*i)

# TODO: Steps 2 to 4, 6 - add support for other shapes
def draw(shape, height, outline):
    
    if shape == "triangle":
        draw_triangle(height, outline)
    if shape == "square":
       draw_square(height, outline)
    if shape == "pyramid":
        draw_pyramid(height, outline)
    if shape == "opposite triangle":
        opposite_triangle(height)
    if shape == "opposite pyramid":
        opposite_pyramid(height)
    if shape == "diamond":
        diamond(height)

# TODO: Step 5 - get input from user to draw outline or solid
def get_outline():
    outline = input("Outline only? (y/N):").upper()

    if outline == "Y":
        return True
    else:
        return False 
           
if __name__ == "__main__":
    shape_param = get_shape()
    height_param = get_height()
    outline_param = get_outline()
    draw(shape_param, height_param, outline_param)

